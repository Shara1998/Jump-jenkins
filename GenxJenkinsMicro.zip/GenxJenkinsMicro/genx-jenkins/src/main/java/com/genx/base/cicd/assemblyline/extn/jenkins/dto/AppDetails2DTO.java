package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.Date;
import java.util.List;

public class AppDetails2DTO {
	private String jobName;
	private long jobId;
	private long count;
	private String title;
	private String type;
	private boolean flag;
	private String buildStatus;
	private Date lastBuildDate;
	private boolean firstTime;
	List<SeriesDTO> seriesDTOs;
	private boolean profileFlag;
	private boolean otpDeployed;
	private boolean exceptionFlag;
	private long profileId;
	private String jobStyle;
	private String benchMark;
	
	public boolean isExceptionFlag() {
		return exceptionFlag;
	}

	public void setExceptionFlag(boolean exceptionFlag) {
		this.exceptionFlag = exceptionFlag;
	}

	public boolean isProfileFlag() {
		return profileFlag;
	}

	public void setProfileFlag(boolean profileFlag) {
		this.profileFlag = profileFlag;
	}

	public boolean isFirstTime() {
		return firstTime;
	}

	public void setFirstTime(boolean firstTime) {
		this.firstTime = firstTime;
	}

	public Date getLastBuildDate() {
		return lastBuildDate;
	}

	public void setLastBuildDate(Date lastBuildDate) {
		this.lastBuildDate = lastBuildDate;
	}

	public List<SeriesDTO> getSeriesDTOs() {
		return seriesDTOs;
	}

	public void setSeriesDTOs(List<SeriesDTO> seriesDTOs) {
		this.seriesDTOs = seriesDTOs;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getBuildStatus() {
		return buildStatus;
	}

	public void setBuildStatus(String buildStatus) {
		this.buildStatus = buildStatus;
	}

	public boolean isOtpDeployed() {
		return otpDeployed;
	}

	public void setOtpDeployed(boolean otpDeployed) {
		this.otpDeployed = otpDeployed;
	}

	public long getProfileId() {
		return profileId;
	}

	

	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}

	public String getJobStyle() {
		return jobStyle;
	}

	public void setJobStyle(String jobStyle) {
		this.jobStyle = jobStyle;
	}
	public String getBenchMark() {
		return benchMark;
	}

	public void setBenchMark(String benchMark) {
		this.benchMark = benchMark;
	}

}
