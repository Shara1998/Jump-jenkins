package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class PerformanceInformationDTO {
	
	private String jmxFile;
	private RepositoryDTO repositoryDTO;
    private JobDTO jobDTO;
	
	public JobDTO getJobDTO() {
		return jobDTO;
	}
	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}
	public String getJmxFile() {
		return jmxFile;
	}
	public void setJmxFile(String jmxFile) {
		this.jmxFile = jmxFile;
	}
	public RepositoryDTO getRepositoryDTO() {
		return repositoryDTO;
	}
	public void setRepositoryDTO(RepositoryDTO repositoryDTO) {
		this.repositoryDTO = repositoryDTO;
	}

}
