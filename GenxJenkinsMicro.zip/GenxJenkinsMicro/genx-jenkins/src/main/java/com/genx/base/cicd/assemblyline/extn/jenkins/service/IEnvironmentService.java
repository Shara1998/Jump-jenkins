package com.genx.base.cicd.assemblyline.extn.jenkins.service;

public interface IEnvironmentService {

	String getEnvProperties(String urlKey);

	String getPwdOnEnv(String urlKey);
	
	String getUserOnEnv(String urlKey);
	
	String getUrlOnEnv(String urlKey);

}
