package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class SonarDTO {
	
	private ProjectDTO projectDTO; 
	private JobDTO jobDTO;
	private ApplicationDTO applicationDTO;
	private RepositoryDTO repositoryDTO;
	private String deployType;
	private LoginDTO loginDTO; 
	private SVNCredentialsDTO svnCredentialsDTO;
	private String profileName;
	private String groupID;
	private String artifactID;
		private String scriptType;
		private String streamName;
public String getScriptType() {
		return scriptType;
	}
	public void setScriptType(String scriptType) {
		this.scriptType = scriptType;
	}
	public LoginDTO getLoginDTO() {
		return loginDTO;
	}
	public void setLoginDTO(LoginDTO loginDTO) {
		this.loginDTO = loginDTO;
	}
	public String getDeployType() {
		return deployType;
	}
	public void setDeployType(String deployType) {
		this.deployType = deployType;
	}
	public ProjectDTO getProjectDTO() {
		return projectDTO;
	}
	public void setProjectDTO(ProjectDTO projectDTO) {
		this.projectDTO = projectDTO;
	}
	
	public JobDTO getJobDTO() {
		return jobDTO;
	}
	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}
	public ApplicationDTO getApplicationDTO() {
		return applicationDTO;
	}
	public void setApplicationDTO(ApplicationDTO applicationDTO) {
		this.applicationDTO = applicationDTO;
	}
	public RepositoryDTO getRepositoryDTO() {
		return repositoryDTO;
	}
	public void setRepositoryDTO(RepositoryDTO repositoryDTO) {
		this.repositoryDTO = repositoryDTO;
	}
	public SVNCredentialsDTO getSvnCredentialsDTO() {
		return svnCredentialsDTO;
	}
	public void setSvnCredentialsDTO(SVNCredentialsDTO svnCredentialsDTO) {
		this.svnCredentialsDTO = svnCredentialsDTO;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	public String getArtifactID() {
		return artifactID;
	}
	public void setArtifactID(String artifactID) {
		this.artifactID = artifactID;
	}
	public String getGroupID() {
		return groupID;
	}
	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}
	public String getStreamName() {
		return streamName;
	}
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
    
}
