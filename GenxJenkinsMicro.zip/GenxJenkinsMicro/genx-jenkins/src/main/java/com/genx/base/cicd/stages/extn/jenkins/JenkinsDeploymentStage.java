package com.genx.base.cicd.stages.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;

import java.io.StringWriter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.DeployJobEntity;
import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsDeployJobRepo;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IStageClassNamesRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.AgentAttribute;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DbScriptUtility;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsDTOMapUtil;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.DeploymentStage;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;

@Service("Deployment")
public class JenkinsDeploymentStage extends DeploymentStage {

	private static final Logger logger = LoggerFactory.getLogger(JenkinsDeploymentStage.class);

	@Autowired
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	@Autowired
	ToolFactory toolFactory;
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	IJenkinsDeployJobRepo ijenkinsdeployJobRepo;

	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;
	@Autowired
	FetchBuldnumberByStage fetchBuldnumberByStage;
	
	String env;
	
	StringWriter attributes;
	
	@Autowired
	JenkinsDTOMapUtil jenkinsDtoMapUtil;
	
	@Autowired
	DbScriptUtility dbScriptUtility;
	

	@Autowired
	IStageClassNamesRepository iStageClassNamesRepository;
	
	@Autowired
	AgentAttribute agentAttribute;
	
	@Autowired
	IJenkinsProfileGroupNameRepository  iJenkinsProfileGroupNameRepository;
	

	@Override
	public Boolean saveStageMetrics(JSONObject metrics, String jobNameBuildStatus, Long buildNum, Long platformTypeId,
			Long stageId, Long toolId, Long avgHelth) throws GenxCICDException {
		ITool iTool = toolFactory.create(platformTypeId, toolId);

		return iTool.saveMetrics(metrics, platformTypeId, toolId);

	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean compareMetricsWithThreshold(String jobName, Long buildNum, String buildStatus, Long platformTypeId,
			Long toolId) {
		Boolean statusFlag = false;
		JSONObject metrics = new JSONObject();
		metrics.put("jobName", jobName);
		metrics.put("buildNum", buildNum);
		metrics.put("buildStatus", buildStatus);

		try {

			statusFlag = saveStageMetrics(metrics, jobName, buildNum, platformTypeId, 3l, toolId, null);

		} catch (GenxCICDException e1) {
			logger.info("message--", e1.getMessage());
		}

		return statusFlag;
	}

	@Override
	public Boolean buildStage() {

		JobDTO jobDto = getJobDTO();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobDto.getJobName());
		DeployJobEntity deployJobEntity = ijenkinsdeployJobRepo
				.getDeployJobEntityByJobId(jobInformationEntity.getJobId());
		if (Objects.isNull(deployJobEntity)) {
			deployJobEntity = new DeployJobEntity();
		}
		deployJobEntity.setJobEntity(jobInformationEntity);
		deployJobEntity.setLastBuild(new Date());
		deployJobEntity.setSuccess("in progress");
		FlagEntity fEntity = new FlagEntity();
		fEntity.setFlag(false);

		ijenkinsdeployJobRepo.save(deployJobEntity);
		return jenkinsBuildStageUtil.buildIndividualStage(jobDto, "Deployment");
	}

	@Override
	public List<String> getStageLogs(long jobId, long stageId) {
		
		return fetchBuldnumberByStage.fetchStageLogs(jobId,"Deployment");
	}
	
	@Override
	public String generateJobConfig() throws GenxCICDException {

		String tempJobConfig = super.generateJobConfig();
		StringBuilder jobConfigBuilder = new StringBuilder();

		jobConfigBuilder.append(tempJobConfig);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		return jobConfigBuilder.toString();

	}

	@Override
	public String generateStageConfig() {

		String tempJobConfig = super.generateStageConfig();

		ObjectMapper mapper = new ObjectMapper();

		StringBuilder jobConfigBuilder = new StringBuilder();

		long id = getStageDTO().getId();

		System.out.println(getStageDTO());
		getStageDTO().getToolList().forEach(list -> {
			env = list.getEnv();
			System.out.println(list);
			Map<String, Object> toolMap = jenkinsDtoMapUtil.dtoMapConversion(list);
			System.out.println(toolMap);

			String data = iStageClassNamesRepository.fetchAttributes(id);
			if (!iStageClassNamesRepository.fetchAttributes(id).isEmpty()) {
				String param = iStageClassNamesRepository.fetchAttributes(id);

				attributes = dbScriptUtility.updatePlaceholders(param, list, getJobDTO());
			}

		});

		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append("stage('");
		jobConfigBuilder.append(getStageDTO().getName());
		jobConfigBuilder.append("'){\n");
		jobConfigBuilder.append(NEWLINE);
		/*if (iStageClassNamesRepository.fetchAgentRequire("Deployment")) {
			jobConfigBuilder.append("environment {\n");
			jobConfigBuilder.append(" nodeLabel = " + "\" RemoteSlave_" + env + "\"");
			jobConfigBuilder.append("\n" + attributes + "\n");
			jobConfigBuilder.append("}\n");
		}*/
		
		if (iJenkinsProfileGroupNameRepository.findByAgentRequire(getJobDTO().getProfileName())) {
			String name = agentAttribute.attributeAtLevel(getJobDTO().getApplicationDTO().getApplicationName());
			if(name != null) {
				jobConfigBuilder.append("environment {\n");
				jobConfigBuilder.append(" nodeLabel = " + "\" RemoteSlave_" + name + env + "\"");
				jobConfigBuilder.append("\n" + attributes + "\n");
				jobConfigBuilder.append("}\n");
			}
		}

		jobConfigBuilder.append("steps{\n");
		return jobConfigBuilder.toString();
	}



}
