package com.genx.base.cicd.stages.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.GOOD;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEED_TO_BE_RESOLVED;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.RISK;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.dashboard.reusable.entity.RegressionInformationEntity;
import com.capgemini.dashboard.reusable.entity.RegressionThresholdEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionThresholdRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.RegressionStage;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;

@Service("Regression")
public class JenkinsRegressionStage extends RegressionStage {
	private static final Logger logger = LoggerFactory.getLogger(JenkinsRegressionStage.class);

	@Autowired
	ToolFactory toolFactory;

	@Autowired
	IJenkinsRegressionInformationRepository iJenkinsRegressionInformationRepository;

	@Autowired
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Autowired
	IJenkinsRegressionThresholdRepository iJenkinsRegressionThresholdRepository;

	@Autowired
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;
	@Autowired
	FetchBuldnumberByStage fetchBuldnumberByStage;

	@SuppressWarnings("unchecked")
	@Override
	public Boolean saveStageMetrics(JSONObject metrics, String jobNameBuildStatus, Long buildNum, Long platformTypeId,
			Long stageId, Long toolId, Long avgHelth) throws GenxCICDException {
		String[] jobNameBuildStatusarr = jobNameBuildStatus.split(":");
		metrics.put("jobName", jobNameBuildStatusarr[0]);
		metrics.put("buildNum", buildNum);
		metrics.put("buildStatus", jobNameBuildStatusarr[1]);
		metrics.put("avgHelth", avgHelth);

		ITool iTool = toolFactory.create(platformTypeId, toolId);

		return iTool.saveMetrics(metrics, platformTypeId, toolId);
	}

	@Override
	public Boolean buildStage() {

		JobDTO jobDto = getJobDTO();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobDto.getJobName());
		RegressionInformationEntity regressionentity = iJenkinsRegressionInformationRepository
				.getRegressionEntityByJobId(jobInformationEntity.getJobId());
		if (Objects.isNull(regressionentity)) {
			regressionentity = new RegressionInformationEntity();
		}
		FlagEntity fEntity = new FlagEntity();
		fEntity.setFlag(false);
		regressionentity.setJobInformationEntity(jobInformationEntity);
		regressionentity.setRegressionBuildStatus("in progress");
		regressionentity.setRegressionLastBuild(new Date());
		regressionentity.setRegressionFlagEntity(fEntity);
		regressionentity.setRegAvgHealth(0l);
		iJenkinsRegressionInformationRepository.save(regressionentity);
		return jenkinsBuildStageUtil.buildIndividualStage(jobDto, "Functional%20Testing");
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean compareMetricsWithThreshold(String jobName, Long buildNum, String buildStatus, Long platformTypeId,
			Long toolId) {
		Boolean statusRegFlag = false;
		JSONObject regMetrics = new JSONObject();
		regMetrics.put("jobName", jobName);
		regMetrics.put("buildNum", buildNum);
		regMetrics.put("buildStatus", buildStatus);
		String jobNameBuildStatus = jobName + ":" + buildStatus;
		try {
			saveStageMetrics(regMetrics, jobNameBuildStatus, buildNum, platformTypeId, 4l, toolId, null);
		} catch (GenxCICDException e1) {
			logger.info("messgae ::" + e1.getMessage());
		}

		FlagEntity flagEntity = new FlagEntity();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobName);
		RegressionInformationEntity regressionInformationEntity = iJenkinsRegressionInformationRepository
				.getRegressionEntityByJobId(jobInformationEntity.getJobId());
		double totalTestCases;
		long noOfPassTestCases;
		String appHealth = null;
		double avgHealth = 0;

		if (Objects.nonNull(regressionInformationEntity)) {
			ProfileGroupNameEntity profileGroupNameEntity = iJenkinsProfileGroupNameRepository
					.findByProfileName(jobInformationEntity.getGroupId());
			RegressionThresholdEntity regressionThresholdEntity = iJenkinsRegressionThresholdRepository
					.fetchregthreshold(profileGroupNameEntity.getProfileGroupNameId(), toolId);
			if ("SUCCESS".equalsIgnoreCase(buildStatus)) {
				totalTestCases = regressionInformationEntity.getTotalTestcases();
				noOfPassTestCases = (regressionInformationEntity.getRegressionPassCount());
				avgHealth = ((noOfPassTestCases / totalTestCases) * 100);
				double goodLevelPercentage = regressionThresholdEntity.getRegGoodLevelPercentage();
				double riskLevelPercentage = regressionThresholdEntity.getRegRiskLevelPercentage();
				if (avgHealth >= goodLevelPercentage) {
					appHealth = GOOD;
					statusRegFlag = true;
				} else if (avgHealth > riskLevelPercentage) {
					appHealth = NEED_TO_BE_RESOLVED;
				} else {

					appHealth = RISK;
				}
				regressionInformationEntity.setRegAvgHealth((long) avgHealth);

				regressionInformationEntity.setAppHealth(appHealth);
				flagEntity.setFlag(true);
				regressionInformationEntity.setRegressionFlagEntity(flagEntity);
				regressionInformationEntity.setRegressionLastBuild(new Date());
				iJenkinsRegressionInformationRepository.save(regressionInformationEntity);
			} else {
				regressionInformationEntity.setRegAvgHealth((long) avgHealth);
				flagEntity.setFlag(false);
				regressionInformationEntity.setRegressionFlagEntity(flagEntity);
				regressionInformationEntity.setRegressionLastBuild(new Date());
				iJenkinsRegressionInformationRepository.save(regressionInformationEntity);
			}
		}

		return statusRegFlag;
	}

	@Override
	public List<String> getStageLogs(long jobId, long stageId) {
		
		return fetchBuldnumberByStage.fetchStageLogs(jobId,"Regression");
	}
	
	@Override
	public String generateJobConfig() throws GenxCICDException {

		String tempJobConfig = super.generateJobConfig();
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		
		jobConfigBuilder.append(tempJobConfig);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		return jobConfigBuilder.toString();
		
	}
	
	
	@Override
	public String generateStageConfig() {
		
		String tempJobConfig = super.generateStageConfig();
		
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append("stage('");
		jobConfigBuilder.append("Regression");
		jobConfigBuilder.append("'){\n");
		jobConfigBuilder.append(NEWLINE);
		
		
		jobConfigBuilder.append("steps{\n");
		return jobConfigBuilder.toString();
	}
	

}
