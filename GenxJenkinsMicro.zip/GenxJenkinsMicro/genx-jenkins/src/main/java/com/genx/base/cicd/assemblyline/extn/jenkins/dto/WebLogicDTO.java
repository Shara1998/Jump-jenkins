package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class WebLogicDTO {
	private Long webLogicId;
	private String warFileName;
	/**private String serverEnvironment;
	private String targets;
	private String buildResource;*/
	private String serverUrl;
	private String weblogicPass;
	private String weblogicUserName;
	/**private String nexusUsername;
	private String nexusPass;
	private String nexusUrl;*/
	
	/**public String getNexusUsername() {
		return nexusUsername;
	}
	public void setNexusUsername(String nexusUsername) {
		this.nexusUsername = nexusUsername;
	}
	public String getNexusPass() {
		return nexusPass;
	}
	public void setNexusPass(String nexusPass) {
		this.nexusPass= nexusPass;
	}
	public String getNexusUrl() {
		return nexusUrl;
	}
	public void setNexusUrl(String nexusUrl) {
		this.nexusUrl = nexusUrl;
	}*/
	public String getServerUrl() {
		return serverUrl;
	}
	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}
	
	public String getWeblogicPass() {
		return weblogicPass;
	}
	public void setWeblogicPass(String weblogicPass) {
		this.weblogicPass = weblogicPass;
	}
	public String getWeblogicUserName() {
		return weblogicUserName;
	}
	public void setWeblogicUserName(String weblogicUserName) {
		this.weblogicUserName = weblogicUserName;
	}
	public Long getWebLogicId() {
		return webLogicId;
	}
	public String getWarFileName() {
		return warFileName;
	}
	public void setWarFileName(String warFileName) {
		this.warFileName = warFileName;
	}
	public void setWebLogicId(Long webLogicId) {
		this.webLogicId = webLogicId;
	}
	/**public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getServerEnvironment() {
		return serverEnvironment;
	}
	public void setServerEnvironment(String serverEnvironment) {
		this.serverEnvironment = serverEnvironment;
	}
	public String getTargets() {
		return targets;
	}
	public void setTargets(String targets) {
		this.targets = targets;
	}
	public String getBuildResource() {
		return buildResource;
	}
	public void setBuildResource(String buildResource) {
		this.buildResource = buildResource;
	}
	*/
}
