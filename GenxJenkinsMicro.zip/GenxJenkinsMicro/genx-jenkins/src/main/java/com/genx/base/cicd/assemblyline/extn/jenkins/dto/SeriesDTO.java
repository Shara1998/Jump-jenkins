package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class SeriesDTO {

	private String name;
	private long y;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getY() {
		return y;
	}
	public void setY(long y) {
		this.y = y;
	}
	
	
}
