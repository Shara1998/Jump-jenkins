package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class DotNetDTO {
	
	private String deploymentType;
	private String serverName;
	private String port;
	private String solutionFileName;
	private String hostName;
	private String userName;
	private String pass;
	private String deployable;
	/**private String pathtoDockerFile;*/
	public String getDeploymentType() {
		return deploymentType;
	}
	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getSolutionFileName() {
		return solutionFileName;
	}
	public void setSolutionFileName(String solutionFileName) {
		this.solutionFileName = solutionFileName;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getDeployable() {
		return deployable;
	}
	public void setDeployable(String deployable) {
		this.deployable = deployable;
	}
	/**public String getPathtoDockerFile() {
		return pathtoDockerFile;
	}
	public void setPathtoDockerFile(String pathtoDockerFile) {
		this.pathtoDockerFile = pathtoDockerFile;
	}
	*/

}
