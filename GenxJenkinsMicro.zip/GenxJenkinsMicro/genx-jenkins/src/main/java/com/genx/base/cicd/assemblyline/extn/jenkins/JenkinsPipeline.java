package com.genx.base.cicd.assemblyline.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.JENKINSURL;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.PARAMETERDEFINITIONS;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.PROJECTNAME;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.SCRIPTENDTAG;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.SCRIPTSTARTTAG;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.SCRIPTTAGREPLACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.XMLCONFIGBATCHPIPELINE;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsApplicationInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsGroupHierarchyRepository;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;

import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.CommonUtils;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.Constants;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DbScriptUtility;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FileParsingUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.UpdateConfigXml;
import com.genx.base.cicd.assemblyline.pipeline.AbstractPipeline;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.FargateDTO;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.PipelineDTO;
import com.genx.base.cicd.dto.QualityGateDTO;
import com.genx.base.cicd.dto.ToolsDTO;
import com.genx.base.cicd.exception.GenxCICDException;
import com.genx.base.hierarchy.serviceimpl.GroupHierarchyServiceImpl;
import com.genx.base.profile.exception.GenxException;
import com.google.gson.JsonObject;





@Service("jenkinsPipeline")
public class JenkinsPipeline extends AbstractPipeline {

	private static final Logger logger = LoggerFactory.getLogger(JenkinsPipeline.class);

	//private static final String STRING20 = null;
	private static final String STRING20="Content-Type";
	//private static final String STRING19 = null;
	private static final String STRING19 ="application/json";

	@Autowired
	IJenkinsApplicationInformationRepository iApplicationInformationRepository;

	@Autowired
	FlagEntity flagEntity;

	@Autowired
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;

	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;

	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	UpdateConfigXml updateConfigXml;
	@Autowired
	IJenkinsGroupHierarchyRepository iJenkinsgroupHierarchyRepository;
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	Environment environment;

	@Override
	public Boolean createJob(String jobConfig, JobDTO jobDTO) {

		String staticXmlfile = staticXml(XMLCONFIGBATCHPIPELINE);
		String dynamicString = null;
		boolean jobCreationFlag = false;
		try {

			dynamicString = super.generateAdditionalJobConfig();

		} catch (GenxCICDException e1) {

			logger.error("exception::" + e1);
		}

		StringBuilder paramvalue = new StringBuilder();
		paramvalue.append(PARAMETERDEFINITIONS);
		paramvalue.append(NEWLINE);
		paramvalue.append(dynamicString);

		String commonScript = DbScriptUtility.getCommonScript();

		staticXmlfile = staticXmlfile.replace(PARAMETERDEFINITIONS, paramvalue);

		StringBuilder finalScript = new StringBuilder();
		finalScript.append(SCRIPTSTARTTAG);
		finalScript.append(NEWLINE);
		finalScript.append(commonScript);
		finalScript.append(jobConfig);
		finalScript.append(NEWLINE);
		finalScript.append(ENDBRACE);
		finalScript.append(NEWLINE);
		finalScript.append(ENDBRACE);
		finalScript.append(NEWLINE);
		finalScript.append(SCRIPTENDTAG);

		staticXmlfile = staticXmlfile.replace(SCRIPTTAGREPLACE, finalScript);
		String jenkinsUserName = propertyUtil.getEnvProperties("jenkinsUserName");
		String jenkinsPass = propertyUtil.getEnvProperties("jenkinsPass");

		devOpsWorkFlowUtil.setJenkinsPassword(jenkinsPass);
		devOpsWorkFlowUtil.setJenkinsUsername(jenkinsUserName);

		String jenkinsUrl = propertyUtil.getEnvProperties(JENKINSURL);

		jenkinsUrl = jenkinsUrl.concat(jobDTO.getJobName());
		/**
		 * if(("MultiBranch").equalsIgnoreCase(jobDTO.getProfileType())) { String
		 * jenkinsUrlMulti = propertyUtil.getEnvProperties(JENKINSURL); String
		 * multiBranchPattern=jobDTO.getJobName().concat("_MultiBranch");
		 * jenkinsUrlMulti = jenkinsUrlMulti.concat(multiBranchPattern); String
		 * staticXmlfileMulti=staticXml(XMLCONFIGMULTIBRANCH); jobCreationFlag =
		 * devOpsWorkFlowUtil.postXML(jenkinsUrlMulti, staticXmlfileMulti); }
		 */

		try {
			jobCreationFlag = devOpsWorkFlowUtil.postXML(jenkinsUrl, staticXmlfile);
		} catch (Exception e) {

			logger.error("exception::" + e);
		}

		return jobCreationFlag;

	}

	private String staticXml(String propname) {

		String strXMLFilename = propertyUtil.getEnvProperties(propname);
		File xmlFile = new File(strXMLFilename);
		Document doc = null;
		try {
			doc = FileParsingUtilNew.fileParsing(xmlFile);
		} catch (ParserConfigurationException | SAXException | IOException e) {

			logger.error("exception" + e);
		}

		return UpdateConfigXml.convertDocumentToString(doc);
	}

	public int callCreateLevel(com.genx.base.cicd.dto.JobDTO jobDTO, RestTemplate restTemplate)
			throws IOException, GenxException {
		String urlEnv = getEnvUrl();
		int levelIdInt = -1;

		String updateUrl = urlEnv + Constants.GENX_CREATE_LEVEL;
		String urlParameters = "levelName=" + jobDTO.getJobName() + "&parentLevelId="+jobDTO.getApplicationDTO().getApplicationId()+"&levelType=Job";
		
	//	String urlParameters = "levelName=" + jobDTO.getJobName() + "&parentLevelId=4&levelType=Job";
		byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);
		int postDataLength = postData.length;

		URL url = new URL(updateUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty(STRING20, "application/x-www-form-urlencoded");
		con.setRequestProperty("charset", "utf-8");
		con.setRequestProperty("Accept", STRING19);
		con.setRequestProperty("Content-Length", Integer.toString(postDataLength));
		con.setRequestProperty(Constants.AUTHORIZATION, CommonUtils.getJwtToken());
		// "Bearer
		// eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhc2hhcm1hIiwiZXhwIjoxNjIzMzUzNzI4LCJpYXQiOjE2MjMzMzU3Mjh9.u4geA_JMGktCZQwF-NCEV0x-GaLDgtMJgSo-MIm1BiLBJq3mTvqQ2sHGmoJGEAQl3ERX3Ql7s5-dpEiH6cWCoA");
		con.setDoOutput(true);
		con.setUseCaches(false);

		try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
			wr.write(postData);
		}

		try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {

			StringBuilder response = new StringBuilder();
			String line;

			while ((line = in.readLine()) != null) {
				response.append(line);
			}

			// print result.
			String stringToParse = response.toString();
			System.out.println(response.toString());

			String levelIdString = "";
			JsonObject convertedObject = new Gson().fromJson(stringToParse, JsonObject.class);

			levelIdString = convertedObject.get("data").getAsJsonObject().get("groupId").toString();
			logger.info("The level id from response: " + levelIdString);

			levelIdInt = Integer.valueOf(levelIdString);
		}

		int status = con.getResponseCode();
		logger.info("status---", status);
		con.disconnect();
		logger.info("LevelId from return:  ---", levelIdInt);
		return levelIdInt;

	}

	public String getEnvUrl() {
		return getEnvProperties(Constants.ENV_URL);
	}
	public String getEnvProperties(String key) {

		Properties prop = new Properties();
		String env = getProfile();
		String propFileName = "location-";
		propFileName = propFileName.concat(env + ".properties");

		InputStream inputStream;
		try {
			
			
			inputStream = GroupHierarchyServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);

		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return prop.getProperty(key);
	}
	
	public String getProfile() {
		String[] activeProfiles = environment.getActiveProfiles();
		return activeProfiles[0];
	}

	@Override
	public Boolean run(JobDTO jobDTO) throws IOException {
		String jobName = jobDTO.getJobName();

		String jenkinsUserName = propertyUtil.getEnvProperties("jenkinsUserName");
		String jenkinsPass = propertyUtil.getEnvProperties("jenkinsPass");

		devOpsWorkFlowUtil.setJenkinsPassword(jenkinsPass);
		devOpsWorkFlowUtil.setJenkinsUsername(jenkinsUserName);
		JobInformationEntity jobInformationEntity = iJenkinsJobInformationRepository.findByAppName(jobName);
		if (Objects.nonNull(jobInformationEntity)) {

			String jenkinsUrlBuildWithParameters = propertyUtil.getEnvProperties("jenkinsUrlbuildPipelineJob");
			jenkinsUrlBuildWithParameters = jenkinsUrlBuildWithParameters.replace(PROJECTNAME, jobName);
			jenkinsUrlBuildWithParameters = jenkinsUrlBuildWithParameters.replace("[stage]", "ALL");
			logger.info("jenkinsUrlBuildWithParameters {}", jenkinsUrlBuildWithParameters);

			String statusString = null;
			try {

				statusString = devOpsWorkFlowUtil.postURL(jenkinsUrlBuildWithParameters);

			} catch (IOException e) {

				logger.error(e.getMessage(), e);
			}
			logger.info(" Status : {}", statusString);
		}

		return true;
	}

	@Override
	public Boolean save(JobDTO jobDTO) throws GenxCICDException {
		int levelId = -1;

		JobInformationEntity jobInformationEntity = new JobInformationEntity();
		GroupHierarchyEntity groupHierarchyEntity = null;
		/*
		 * groupHierarchyEntity = iApplicationInformationRepository
		 * .fetchApplicationEntity(jobDTO.getApplicationDTO().getApplicationName());
		 */
		jobInformationEntity.setJobName(jobDTO.getJobName());
		flagEntity.setFlag(true);
		jobInformationEntity.setFlagEntity(flagEntity);
		jobInformationEntity.setJobType(jobDTO.getJobStyle());
		jobInformationEntity.setJenkinsUsername(jobDTO.getDevopsUserName());
		jobInformationEntity.setJenkinsPass(jobDTO.getDevopsPassword());
		jobInformationEntity.setComments(jobDTO.getComments());
		jobInformationEntity.setBuildTools(jobDTO.getBuildTools());
		jobInformationEntity.setCodeBase(jobDTO.getApplicationDTO().getCodeBase());
		jobInformationEntity.setCodeBaseVersion(jobDTO.getApplicationDTO().getCodeBaseVersion());
		jobInformationEntity.setApplicationType(jobDTO.getApplicationDTO().getApplicationType());
		jobInformationEntity.setReleaseDate(jobDTO.getApplicationDTO().getReleaseDate());
		jobInformationEntity.setGroupId(jobDTO.getProfileName());
		jobInformationEntity.setQualityGateId(jobDTO.getQualityGateId());
		// jobInformationEntity.setParentId(groupHierarchyEntity.getLevelId());
		/**
		 * jobInformationEntity.setEmployeeInformationEntity(employeeInformationEntity);
		 */
		jobInformationEntity.setGroupHierarchyEntity(groupHierarchyEntity);
		jobInformationEntity.setJobStatus("Non-Compliant");
		jobInformationEntity.setProfileType(jobDTO.getProfileType());
		jobInformationEntity.setJobActive(true);

		try {

			levelId = callCreateLevel(jobDTO, restTemplate);
			System.out.println("In Create Level ID: " + levelId);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (GenxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		GroupHierarchyEntity groupHierarchyEntity1 = iJenkinsgroupHierarchyRepository.getGrpHierarchy(levelId);
		jobInformationEntity.setGroupHierarchyEntity(groupHierarchyEntity1);
		// jobInformationEntity.setEmployeeInformationEntity(employeeInformationEntity);
		// jobInformationEntity.setParentId(applicationInformationEntity.getApplicationId());

		jobInformationEntity = iJenkinsJobInformationRepository.save(jobInformationEntity);
		super.save(jobDTO);
		logger.info("jobInformationEntity ::" + jobInformationEntity);
	
		return true;

	}

	@Override
	public PipelineDTO view(JobDTO jobDTO) throws GenxCICDException {
		PipelineDTO pipelineDto = null;
		StringBuilder sb = new StringBuilder();
		try {
			List<String> filePath = devOpsWorkFlowUtil.fetchPipelineConfig(jobDTO.getJobName());
			for (String xmlFile : filePath) {
				sb.append(xmlFile);
				sb.append("\n");
			}
			super.saveJobConfig(sb.toString(), jobDTO.getJobId());
			Document doc = FileParsingUtilNew.convertStringToDocument(sb.toString());
			pipelineDto = updateConfigXml.updateMapper(jobDTO, doc);

		} catch (IOException | XPathExpressionException e) {
			logger.info(e.getMessage());
		}
		return pipelineDto;
	}

	@Override
	public Boolean updateJob(Object jobConfig, JobDTO jobDTO) throws GenxCICDException {

		Boolean updateStatus = false;

		try {
			updateStatus = devOpsWorkFlowUtil.updatePipelineconfig(jobConfig.toString(), jobDTO.getJobName());
			updateConfigXml.updateJobInformation(jobDTO);
		} catch (IOException e) {
			logger.info(e.getMessage());
		}

		return updateStatus;
	}

	@Override
	public List<ITool> createTools(List<ToolsDTO> toolsDTOs, String platformType) throws GenxCICDException {

		return new ArrayList<>();
	}

	@Override
	public String generateAdditionalJobConfig() {

		return null;
	}

	@Override
	public PipelineDTO getBuildLogs(Long jobId) throws IOException {
		return null;
	}

	@Override
	public List<QualityGateDTO> fetchQualityGates() throws IOException {
		List<QualityGateDTO> qualityGateDTOs = new ArrayList<>();
		devOpsWorkFlowUtil.setJenkinsPassword("genx");
		devOpsWorkFlowUtil.setJenkinsUsername("genx@123");

		String content = devOpsWorkFlowUtil.postURL(propertyUtil.getEnvProperties("sonarUrlTollGate"));

		logger.info("content :" + content);
		org.json.JSONObject jsonObject = new org.json.JSONObject(content);
		JSONArray jsonArray = (JSONArray) jsonObject.get("qualitygates");
		org.json.JSONObject jsonObj = null;

		for (int i = 0; i < jsonArray.length(); i++) {
			jsonObj = (org.json.JSONObject) jsonArray.get(i);
			QualityGateDTO qualityGateDTO = new QualityGateDTO();
			qualityGateDTO.setQualityGateId(Long.parseLong(jsonObj.get("id").toString()));
			qualityGateDTO.setGateName(jsonObj.get("name").toString());
			qualityGateDTOs.add(qualityGateDTO);
		}
		return qualityGateDTOs;

	}

	@Override
	public FargateDTO fetchFargateTaskDefinitions() {

		return null;
	}

	@Override
	public FargateDTO fetchFargateClusterList() {

		return null;
	}

	@Override
	public String createPlatformUrl(String jobName, Long pipelineId) {

		return null;
	}

}
