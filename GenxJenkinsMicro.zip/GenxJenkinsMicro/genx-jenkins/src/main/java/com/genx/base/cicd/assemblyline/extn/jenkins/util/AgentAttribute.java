package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;
import com.capgemini.genx.core.repository.IJenkinsGroupHierarchyRepository;




@Service
public class AgentAttribute {

	@Autowired
	IJenkinsGroupHierarchyRepository iJenkinsGroupHierarchyRepository;
	
	public String attributeAtLevel(String applicationName) {
	
		GroupHierarchyEntity applicationLevel = iJenkinsGroupHierarchyRepository.getGrpHierarchyByLevelName(applicationName, "Application");
		
		GroupHierarchyEntity projectLevel = iJenkinsGroupHierarchyRepository.getGrpHierarchy(applicationLevel.getParentLevelId());
		
		GroupHierarchyEntity subAccountLevel = iJenkinsGroupHierarchyRepository.getGrpHierarchy(projectLevel.getParentLevelId());
		
		GroupHierarchyEntity accountLevel = iJenkinsGroupHierarchyRepository.getGrpHierarchy(subAccountLevel.getParentLevelId());
		
		if(applicationLevel.getAgentRequire()) {
			return applicationLevel.getLevelName();
		}
		else if(projectLevel.getAgentRequire()) {
			return projectLevel.getLevelName();
		}
		else if(subAccountLevel.getAgentRequire()) {
			return subAccountLevel.getLevelName();
		}
		else if(accountLevel.getAgentRequire()) {
			return accountLevel.getLevelName();
		}
		
		
			return "";
	}
}
