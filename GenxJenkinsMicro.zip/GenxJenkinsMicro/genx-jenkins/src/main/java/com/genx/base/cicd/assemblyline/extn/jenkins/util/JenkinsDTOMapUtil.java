package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class JenkinsDTOMapUtil {
	
	public Map<String, Object> dtoMapConversion(Object obj){
		ObjectMapper mapper = new ObjectMapper();	
		
		return mapper.convertValue(obj, new TypeReference<Map<String, Object>>() {});
	}

}
