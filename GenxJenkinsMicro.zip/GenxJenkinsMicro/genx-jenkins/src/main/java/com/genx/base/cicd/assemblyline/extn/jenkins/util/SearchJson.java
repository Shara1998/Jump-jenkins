package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


public class SearchJson {
	private static final Logger logger = LoggerFactory.getLogger(SearchJson.class);
	public SearchJson() {
		/*
		 * 
		 inside SearchJson 
		 * 
		 */
	
	}
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	public static void main(String[] args) {
		/*
		 * to avoid sonar codesmells
		 */
		
	}

	public static String searchJson(String testKey, JSONObject rootJsonDTO){
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayList<JSONObject> list = (ArrayList) ((HashMap) rootJsonDTO.get("component")).get("measures");
		for( JSONObject obj :list){
			
			logger.info("inside Search JSON {}" , obj);
				if(obj.get("metric").equals(testKey)){
					
					return ""+obj.get("value");
							
				}
			
		}
		
		
		return "ok";
	}

}
