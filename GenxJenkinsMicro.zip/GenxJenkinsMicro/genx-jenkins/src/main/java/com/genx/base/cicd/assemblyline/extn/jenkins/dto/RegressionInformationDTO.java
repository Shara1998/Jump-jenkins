package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class RegressionInformationDTO {
	private String testCasesXmlPath;
	RepositoryDTO repositoryDTO=new RepositoryDTO();
	JobDTO jobDTO=new JobDTO();
	public RepositoryDTO getRepositoryDTO() {
		return repositoryDTO;
	}
	private String regressionType;
	public void setRepositoryDTO(RepositoryDTO repositoryDTO) {
		this.repositoryDTO = repositoryDTO;
	}
	public JobDTO getJobDTO() {
		return jobDTO;
	}
	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}
	public String getRegressionType() {
		return regressionType;
	}
	public void setRegressionType(String regressionType) {
		this.regressionType = regressionType;
	}
	public String getTestCasesXmlPath() {
		return testCasesXmlPath;
	}
	public void setTestCasesXmlPath(String testCasesXmlPath) {
		this.testCasesXmlPath = testCasesXmlPath;
	}
}
