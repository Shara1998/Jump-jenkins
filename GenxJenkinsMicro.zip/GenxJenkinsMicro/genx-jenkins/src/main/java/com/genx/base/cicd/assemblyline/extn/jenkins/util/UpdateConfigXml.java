package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.KubernetesInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupEntity;

import com.capgemini.dashboard.reusable.entity.RepositoryDetailsEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsKubernetesRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupRepository;
import com.capgemini.genx.core.repository.IJenkinsProjectInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRepositoryDetailsRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genx.base.cicd.assemblyline.extn.jenkins.dto.KubernetesDTO;
import com.genx.base.cicd.dto.ApplicationDTO;
import com.genx.base.cicd.dto.IPipelineDTO;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.PipelineDTO;
import com.genx.base.cicd.dto.RepositoryDTO;
import com.genx.base.cicd.dto.StageDTO;
import com.genx.base.cicd.dto.ToolsDTO;

@Service
public class UpdateConfigXml{	
	
	private static final Logger logger = LoggerFactory.getLogger(UpdateConfigXml.class);
	
	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Autowired
	IJenkinsPerformanceInformationRepository iJenkinsPerformanceInformationRepository;
	
	@Autowired
	IJenkinsRepositoryDetailsRepository iJenkinsRepositoryDetailsRepository;
	
	@Autowired
	IJenkinsProfileGroupRepository iJenkinsProfileGroupRepository;
	
	@Autowired
	IJenkinsProjectInformationRepository jenkinsProjectInformationRepository;
	
	@Autowired
	IJenkinsKubernetesRepository iJenkinsKubernetesRepository;
	
	@Autowired
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;
	
	
	
	public String getUpdatedXmlString(IPipelineDTO pipelineDTO,Document doc) {
		 
		NodeList nodeList = doc.getElementsByTagName("hudson.model.StringParameterDefinition");
		for (int parameter = 0; parameter < nodeList.getLength(); parameter++) {
            Node node = nodeList.item(parameter);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) node;
                String name = eElement.getElementsByTagName("name").item(0).getTextContent();
                if("technology".equalsIgnoreCase(name)) {
                eElement.getElementsByTagName("defaultValue").item(0).setTextContent(pipelineDTO.getJobDTO().getApplicationDTO().getCodeBase());
                }
               
				            }
        }
		
		return convertDocumentToString(doc);
	}
	
	
	public static String convertDocumentToString(Document doc) {
		TransformerFactory tf = TransformerFactory.newInstance();

		Transformer transformer;
		StringWriter writer = new StringWriter();
		try {
			tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			transformer = tf.newTransformer();

			transformer.transform(new DOMSource(doc), new StreamResult(writer));

			return writer.getBuffer().toString();
		} catch (TransformerException e) {

			return writer.getBuffer().toString();

		}
	}
	
	public  PipelineDTO updateMapper(JobDTO jobDto,Document doc) throws XPathExpressionException {
		
		
		JobInformationEntity jobInformationEntity=iJobInformationRepository.findByAppNameLike(jobDto.getJobName());
	//	GroupHierarchyEntity groupHierarchyEntity=jenkinsProjectInformationRepository.fetchProjectByProjId(String.valueOf(jobInformationEntity.getGroupHierarchyEntity().getParentLevelId()));
		JobDTO jobDTO = new JobDTO();
		jobDTO.setJobName(jobInformationEntity.getJobName());
		jobDTO.setDevopsUserName(jobInformationEntity.getJenkinsUsername());
		jobDTO.setDevopsPassword(jobInformationEntity.getJenkinsPass());
		jobDTO.setComments(jobInformationEntity.getComments());
		jobDTO.setBuildTools(jobInformationEntity.getBuildTools());
	
		
		ApplicationDTO appDto=new ApplicationDTO();
		appDto.setCodeBase(jobInformationEntity.getCodeBase());
		appDto.setCodeBaseVersion(jobInformationEntity.getCodeBaseVersion());
		appDto.setReleaseDate(jobInformationEntity.getReleaseDate());
		appDto.setApplicationName(jobInformationEntity.getGroupHierarchyEntity().getLevelName());	
		appDto.setProjectId(String.valueOf(jobInformationEntity.getGroupHierarchyEntity().getParentLevelId()));
	//	appDto.setProjectName(groupHierarchyEntity.getLevelName());
		appDto.setApplicationType(jobInformationEntity.getApplicationType());
		
		List<StageDTO> stageDtoList=new ArrayList<>();
		
		jobDTO.setApplicationDTO(appDto);
		PipelineDTO pipelineDto=new PipelineDTO();
		StageDTO regStageDto=new StageDTO();
		StageDTO kuberStageDto=new StageDTO();
		StageDTO perfStageDto=new StageDTO();
		StageDTO cqStageDto=new StageDTO();
		Map<String,Long> stageToolMap=generateToolList(jobDTO);
		
		logger.info("stageToolMap::"+stageToolMap);
		
		if(stageToolMap.containsKey("sonar")) {
			cqStageDto=getCodequalityDetails(jobInformationEntity);
    } 
		if(stageToolMap.containsKey("kubernetes")) {
			kuberStageDto=getDeployDetails(jobDto,doc);
    } 
		 if(stageToolMap.containsKey("SoapUi")) {
    	regStageDto=getsoapUiFilePath(doc);
    }
		 if(stageToolMap.containsKey("ApacheJMeter")) {
    	perfStageDto=getPerfDetails(jobDTO);
    } 
		 if(stageToolMap.containsKey("Selenium")) {
    	regStageDto=getsoapUiFilePath(doc);
    }   
    stageDtoList.add(cqStageDto);
    stageDtoList.add(kuberStageDto);
    stageDtoList.add(regStageDto);
    stageDtoList.add(perfStageDto);
		pipelineDto.setJobDTO(jobDTO);
		pipelineDto.setStagesList(stageDtoList);
		return pipelineDto;
	}
	
	
	
	private StageDTO getsoapUiFilePath(Document doc) throws XPathExpressionException {
		XPathFactory xpathfactory = XPathFactory.newInstance();
		XPath xpath = xpathfactory.newXPath();
		StageDTO regStageDto=new StageDTO();
		List<ToolsDTO> regToolsDtoList=new ArrayList<>();
		ToolsDTO regToolsDto=new ToolsDTO();
		regStageDto.setId(4l);		
		regToolsDto.setToolId(7l);
		XPathExpression expr = xpath.compile("//hudson.model.StringParameterDefinition[contains(name,'SoapUI_Filepath')]");
        Object result = expr.evaluate(doc, XPathConstants.NODESET);
        NodeList nodes = (NodeList) result;
        for (int i = 0; i < nodes.getLength(); i++) {
        	
        	String s1=nodes.item(i)
            .getChildNodes()
            .item(5)                
            .getTextContent();
        	regToolsDto.setFolderPath(s1);     	

        		}
        regToolsDtoList.add(regToolsDto);
		regStageDto.setToolList(regToolsDtoList);
		return regStageDto;
		
	}
	
	private Map<String, Long> generateToolList(JobDTO jobDto) {
		
		Map<String, Long> stageAndTools=new CaseInsensitiveKeyMap<>();
		JobInformationEntity jobInformationEntity=iJobInformationRepository.findByAppNameLike(jobDto.getJobName());
		String profileName=jobInformationEntity.getGroupId();
		List<ProfileGroupEntity> profileGroupEntityList=iJenkinsProfileGroupRepository.fetchStageList(profileName);
		logger.info("profileName::"+profileName);
		logger.info("profileGroupEntityList::"+profileGroupEntityList.size());
		for(ProfileGroupEntity profileGroupEntity:profileGroupEntityList ) {
			stageAndTools.put(profileGroupEntity.getToolMasterEntity().getToolName(), profileGroupEntity.getToolMasterEntity().getToolId());
					}
		logger.info("mapsize" +stageAndTools);
		return stageAndTools;
	}
	
	
	private StageDTO getDeployDetails(JobDTO jobDto,Document doc) {
		String ecrurl = null;
		NodeList nodeList = doc.getElementsByTagName("hudson.model.StringParameterDefinition");
		for (int parameter = 0; parameter < nodeList.getLength(); parameter++) {
			Node node = nodeList.item(parameter);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) node;
				String name = eElement.getElementsByTagName("name").item(0).getTextContent();
				if ("ecr".equalsIgnoreCase(name)) {
					 ecrurl=eElement.getElementsByTagName("defaultValue").item(0).getTextContent();
				}
				
			}
		}
		
		KubernetesInformationEntity kuberInfo=iJenkinsKubernetesRepository.getDetailsByJobId(jobDto.getJobId());
		StageDTO kuberStageDto=new StageDTO();
		List<ToolsDTO> kuberToolsDtoList=new ArrayList<>();
		KubernetesDTO kuberDto=new KubernetesDTO();
		ToolsDTO kuberToolsDto=new ToolsDTO();
		kuberStageDto.setId(3l);		
		kuberToolsDto.setToolId(12l);
		
		kuberDto.setImageName(kuberInfo.getKubImageName());
		kuberDto.setEnv(kuberInfo.getKubEnvironment());
		kuberDto.setPort(kuberInfo.getKubPort());
		kuberDto.setEcrAwsUrl(ecrurl);
		kuberDto.setRegistryType(kuberInfo.getKubregistryType());
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = mapper.convertValue(kuberDto, JsonNode.class);
		kuberToolsDto.setToolSpecificAttributes(node);
		kuberToolsDtoList.add(kuberToolsDto);
		kuberStageDto.setToolList(kuberToolsDtoList);
		return kuberStageDto;
	}
	private StageDTO getPerfDetails(JobDTO jobDto) {
		StageDTO perfStageDto=new StageDTO();
		perfStageDto.setId(5l);
		ToolsDTO perfToolsDto=new ToolsDTO();
		List<ToolsDTO> perfToolList=new ArrayList<>();
		perfToolsDto.setToolId(9l);		
		PerformanceInformationEntity perfEntity=iJenkinsPerformanceInformationRepository.getDetailsByAppName(jobDto.getJobName());
		perfToolsDto.setFolderPath(perfEntity.getJmxFile());
		
		RepositoryDetailsEntity repositoryDetailsEntity=iJenkinsRepositoryDetailsRepository.getRepoByJobId(jobDto.getJobId());
		String gitUrl=repositoryDetailsEntity.getGitUrl();
		String gitBranch=repositoryDetailsEntity.getBranchName();
		
		RepositoryDTO repoDto=new RepositoryDTO();
		repoDto.setUrl(gitUrl);
		repoDto.setBranch(gitBranch);
		
		perfToolsDto.setRepositoryDTO(repoDto);
		perfToolList.add(perfToolsDto);
		perfStageDto.setToolList(perfToolList);
		return perfStageDto;
	}
	
	private StageDTO getCodequalityDetails(JobInformationEntity jobInformationEntity) {
		 RepositoryDetailsEntity repositoryDetailsEntity=iJenkinsRepositoryDetailsRepository.getRepoByJobId(jobInformationEntity.getJobId());
		String gitUrl=repositoryDetailsEntity.getGitUrl();
		String gitBranch=repositoryDetailsEntity.getBranchName();
		
		StageDTO cqStageDto=new StageDTO();
		cqStageDto.setId(1l);
		
		RepositoryDTO repoDto=new RepositoryDTO();
		repoDto.setUrl(gitUrl);
		repoDto.setBranch(gitBranch);
		
		ToolsDTO cqToolsDto=new ToolsDTO();
		cqToolsDto.setRepositoryDTO(repoDto);
		List<ToolsDTO> cqToolList=new ArrayList<>();
		cqToolsDto.setToolId(1l);
		cqToolList.add(cqToolsDto);
		cqStageDto.setToolList(cqToolList);
		return cqStageDto;
	}
	
	public void updateJobInformation(JobDTO jobDTO) {
		
		JobInformationEntity jobInformationEntity=iJobInformationRepository.findByAppNameLike(jobDTO.getJobName());
		
		jobInformationEntity.setReleaseDate(jobDTO.getApplicationDTO().getReleaseDate());
		jobInformationEntity.setJenkinsPass(jobDTO.getDevopsPassword());
		jobInformationEntity.setJenkinsUsername(jobDTO.getDevopsUserName());
		iJenkinsJobInformationRepository.save(jobInformationEntity);
	}
	
	
	
}
