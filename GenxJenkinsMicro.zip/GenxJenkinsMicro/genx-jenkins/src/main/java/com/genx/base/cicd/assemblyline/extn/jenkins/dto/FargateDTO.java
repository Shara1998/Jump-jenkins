package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.List;
import java.util.Map;

public class FargateDTO {
	
	private List<String> taskDefList;
	private Map<String,String> clusterList;
	private Map<String,String> serviceList;
	private MessageDTO messageDTO;
	private String name;
	private String image;
	private String containerPort;
	private String hostPort;
	private String cpu;
	private String memory;
	private String taskName;
	private String taskVersion;
	private String clusterName;
	private String serviceName;
	private String baseImage;
	private String target;
	public List<String> getTaskDefList() {
		return taskDefList;
	}

	public void setTaskDefList(List<String> taskDefList) {
		this.taskDefList = taskDefList;
	}

	public MessageDTO getMessageDTO() {
		return messageDTO;
	}

	public void setMessageDTO(MessageDTO messageDTO) {
		this.messageDTO = messageDTO;
	}	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getContainerPort() {
		return containerPort;
	}

	public void setContainerPort(String containerPort) {
		this.containerPort = containerPort;
	}

	public String getHostPort() {
		return hostPort;
	}

	public void setHostPort(String hostPort) {
		this.hostPort = hostPort;
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public String getMemory() {
		return memory;
	}

	public void setMemory(String memory) {
		this.memory = memory;
	}

	public Map<String, String> getClusterList() {
		return clusterList;
	}

	public void setClusterList(Map<String, String> clusterList) {
		this.clusterList = clusterList;
	}

	public Map<String, String> getServiceList() {
		return serviceList;
	}

	public void setServiceList(Map<String, String> serviceList) {
		this.serviceList = serviceList;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskVersion() {
		return taskVersion;
	}

	public String getBaseImage() {
		return baseImage;
	}

	public void setBaseImage(String baseImage) {
		this.baseImage = baseImage;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public void setTaskVersion(String taskVersion) {
		this.taskVersion = taskVersion;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
