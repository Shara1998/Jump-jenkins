package com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.capgemini.genx.core.repository.IJenkinsEnvUrlRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.service.IEnvironmentService;


@Service
public class EnvironmentServiceImplNew implements IEnvironmentService{

	private static final Logger logger = LoggerFactory.getLogger(EnvironmentServiceImplNew.class);

	@Autowired
	IJenkinsEnvUrlRepository envUrlRepository;

	@Autowired
	Environment environment;

	public EnvironmentServiceImplNew() {
		/**
		 * 
		 * inside PropertyUtil
		 * 
		 */

	}

	
	public static String getPropValue(String key) {

		Properties prop = new Properties();
		String credentialsPropFileName = "credentials.properties";

		InputStream inputStream;
		try {
			inputStream = EnvironmentServiceImplNew.class.getClassLoader().getResourceAsStream(credentialsPropFileName);
			prop.load(inputStream);
		} catch (IOException e) {
			/**com.capgemini.dashboard.util.ExceptionUtil.stackTraceToString(e);*/
		}

		String emailContentPropFileName = "emailcontent.properties";

		try {
			inputStream = EnvironmentServiceImplNew.class.getClassLoader().getResourceAsStream(emailContentPropFileName);
			prop.load(inputStream);

		} catch (IOException e) {
			/**com.capgemini.dashboard.util.ExceptionUtil.stackTraceToString(e);*/
		}
		return prop.getProperty(key);
	}

	public String getEnvProperties(String key) {

		Properties prop = new Properties();
		/*** String propFileName = "location-prod.properties"; **/
		/*** String env = "prod"; **/
		String env = getProfile();
		logger.info("env--" + env);

		String propFileName = "location-";
		propFileName = propFileName.concat(env + ".properties");

		InputStream inputStream;
		try {
			inputStream = EnvironmentServiceImplNew.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);

		} catch (IOException e) {
			logger.info("message--",e.getMessage());
		}
		logger.info("prop.getProperty(key) %s", prop.getProperty(key));

		return appendUrl(key, env).concat(prop.getProperty(key));
	}

	String appendUrl(String keyNew, String env) {
		if (keyNew.contains("jenkinsUrlwindows")) {
			return envUrlRepository.getUrlOnEnvAndType(env, "jenkinsWindows");
		} else if (keyNew.contains("jenkinsUrl")) {
			return envUrlRepository.getUrlOnEnvAndType(env, "jenkins");
		} else if (keyNew.contains("sonarUrl")) {
			return envUrlRepository.getUrlOnEnvAndType(env, "sonar");
		} else if (keyNew.contains("githubUrl")) {
			return envUrlRepository.getUrlOnEnvAndType(env, "github");
		}else {
			return "";
		}
	}

	public String getProfile() {
		String[] activeProfiles = environment.getActiveProfiles();
		for (String profile : activeProfiles) {
			logger.info("in for " + profile);
		}
		return activeProfiles[0];
	}
	@Override
	public String getUserOnEnv(String urlType) {
		String env = getProfile();
		return envUrlRepository.getUserOnEnvAndType(env, urlType);
	}
	@Override
	public String getPwdOnEnv(String urlType) {
		String env = getProfile();
		return envUrlRepository.getPwdOnEnvAndType(env, urlType);
	}


	@Override
	public String getUrlOnEnv(String urlKey) {
		String env = getProfile();
		return envUrlRepository.getUrlOnEnvAndType(env, urlKey);
	}
}