package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ProjectDTO {

	private String projectId;
	private String status;
	private String errorCode;
	private String groupId;
	private String projectName;
	private List<GroupDTO> groupDTOs;
	private List<ApplicationDTO> applicantList;
	
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	
	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<ApplicationDTO> getApplicantList() {
		return applicantList;
	}

	public void setApplicantList(Collection<ApplicationDTO> applicantList) {
		this.applicantList = new ArrayList<>(applicantList);
	}

	@Override
	public String toString() {
		return "ProjectDTO [projectId=" + projectId + ", status=" + status + ", errorCode=" + errorCode
				+ ", projectName=" + projectName + ", applicantList=" + applicantList + "]";
	}

	public List<GroupDTO> getGroupDTOs() {
		return groupDTOs;
	}

	public void setGroupDTOs(List<GroupDTO> groupDTOs) {
		this.groupDTOs = groupDTOs;
	}
	
	
	
}
