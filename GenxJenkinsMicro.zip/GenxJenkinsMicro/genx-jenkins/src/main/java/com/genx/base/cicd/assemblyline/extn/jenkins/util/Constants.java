package com.genx.base.cicd.assemblyline.extn.jenkins.util;

public final class Constants {
private Constants() {
		
	}
	
	
	public static final String CONTENTTYPE = "Content-Type";
	
	public static final String APPLICATIONJSON = "application/json";
	public static final String AUTHORIZATION = "authorization";
	public static final String GENX_CREATE_LEVEL = "/genx/createLevel";
	public static final String ENV_URL = "envUrl";

}


