
package com.genx.base.cicd.stages.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.GOOD;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEED_TO_BE_RESOLVED;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.RISK;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.capgemini.dashboard.reusable.entity.YascaThresholdEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaJobRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaThresholdRepository;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.SecurityStage;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;

@Service("SAST")
public class JenkinsSecurityStage extends SecurityStage {

	private static final Logger logger = LoggerFactory.getLogger(JenkinsSecurityStage.class);

	@Autowired
	ToolFactory toolFactory;

	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	DevOpsWorkFlowUtilNew workFlowUtil;

	@Autowired
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Autowired
	IJenkinsYascaJobRepository iYascaInformationRepository;

	@Autowired
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;

	@Autowired
	IJenkinsYascaThresholdRepository iJenkinsYascaThresholdRepository;
	@Autowired
	FetchBuldnumberByStage fetchBuldnumberByStage;

	FlagEntity flagEntity = new FlagEntity();

	@SuppressWarnings("unchecked")
	@Override
	public Boolean compareMetricsWithThreshold(String jobName, Long buildNum, String buildStatus, Long platformTypeId,
			Long toolId) {
		Boolean statusSastFlag = false;
		JSONObject sastMetrics = new JSONObject();
		sastMetrics.put("jobName", jobName);
		sastMetrics.put("buildNum", buildNum);
		sastMetrics.put("buildStatus", buildStatus);
		try {
			saveStageMetrics(sastMetrics, jobName, buildNum, platformTypeId, 2l, toolId, null);

		} catch (GenxCICDException e1) {
			logger.info("securitystgae::" + e1.getMessage());
		}

		YascaInformationEntity yascaInformationEntity = new YascaInformationEntity();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobName);
		try {
			yascaInformationEntity = iYascaInformationRepository.getYascaEntityByJobId(jobInformationEntity.getJobId());

			if (Objects.nonNull(yascaInformationEntity)) {
				if ("SUCCESS".equalsIgnoreCase(yascaInformationEntity.getYascaBuildStatus())) {

					statusSastFlag = yascaThresholdCalculation(yascaInformationEntity, toolId, jobInformationEntity);

				} else {
					yascaInformationEntity.setYascaAvgHealth(0);
					flagEntity.setFlag(false);
					yascaInformationEntity.setYascaFlagEntity(flagEntity);
					iYascaInformationRepository.save(yascaInformationEntity);
				}
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		return statusSastFlag;
	}

	private Boolean yascaThresholdCalculation(YascaInformationEntity yascaInformationEntity, Long toolId,
			JobInformationEntity jobInformationEntity) {

		ProfileGroupNameEntity profileGroupNameEntity = iJenkinsProfileGroupNameRepository
				.findByProfileName(jobInformationEntity.getGroupId());

		YascaThresholdEntity yascaThresholdEntity = iJenkinsYascaThresholdRepository
				.fetchThesholdValues(profileGroupNameEntity.getProfileGroupNameId(), toolId);

		final double highThresold = yascaThresholdEntity.getHighThresold();
		final double lowThresold = yascaThresholdEntity.getLowThresold();

		long critical = 0;
		long high = 0;
		long low = 0;
		String appHealth = null;
		double avgHealth = 0;
		Boolean statusFlag = false;
		flagEntity.setFlag(statusFlag);
		critical = (yascaInformationEntity.getSeverityCritical());

		high = (yascaInformationEntity.getSeverityHigh());

		low = (yascaInformationEntity.getSeverityLow());

		if (critical != 0) {
			appHealth = RISK;

		} else {
			double highThresoldPer = (((highThresold - high) / highThresold) * 100);

			double lowThresoldPer = (((lowThresold - low) / lowThresold) * 100);

			avgHealth = ((highThresoldPer + lowThresoldPer) / 2);
			double goodLevelPercentage = yascaThresholdEntity.getYascaGoodLevelPercentage();
			double riskLevelPercentage = yascaThresholdEntity.getYascaRiskLevelPercentage();
			if (avgHealth >= goodLevelPercentage) {
				appHealth = GOOD;
				statusFlag = true;
				flagEntity.setFlag(true);
			} else if (avgHealth > riskLevelPercentage) {
				appHealth = NEED_TO_BE_RESOLVED;
			} else if (avgHealth < riskLevelPercentage) {
				appHealth = RISK;
			}

		}

		long finalAvgHealth = (long) ((avgHealth < 0) ? 0 : avgHealth);

		yascaInformationEntity.setYascaAvgHealth(finalAvgHealth);
		yascaInformationEntity.setAppHealth(appHealth);

		yascaInformationEntity.setYascaFlagEntity(flagEntity);
		iYascaInformationRepository.save(yascaInformationEntity);
		return statusFlag;

	}

	@Override
	public Boolean saveStageMetrics(JSONObject metrics, String jobNameBuildStatus, Long buildNum, Long platformTypeId,
			Long stageId, Long toolId, Long avgHelth) throws GenxCICDException {
		ITool iTool = toolFactory.create(platformTypeId, toolId);
		return iTool.saveMetrics(metrics, platformTypeId, toolId);

	}

	@Override
	public Boolean buildStage() {

		JobDTO jobDto = getJobDTO();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobDto.getJobName());
		YascaInformationEntity newyasca2 = iYascaInformationRepository
				.getYascaEntityByJobId(jobInformationEntity.getJobId());
		if (Objects.isNull(newyasca2)) {
			newyasca2 = new YascaInformationEntity();
		}
		newyasca2.setJobInformationEntity(jobInformationEntity);
		newyasca2.setYascaBuildStatus("in progress");
		newyasca2.setYascaLastBuild(new Date());
		flagEntity.setFlag(false);
		newyasca2.setYascaFlagEntity(flagEntity);
		newyasca2.setYascaAvgHealth(0l);
		iYascaInformationRepository.save(newyasca2);
		return jenkinsBuildStageUtil.buildIndividualStage(jobDto, "SAST");
	}

	@Override
	public List<String> getStageLogs(long jobId, long stageId) {
		return fetchBuldnumberByStage.fetchStageLogs(jobId,"SAST");
	}
	
	@Override
	public String generateJobConfig() throws GenxCICDException {
		String tempJobConfig = super.generateJobConfig();
		StringBuilder jobConfigBuilder = new StringBuilder(); 
	
		jobConfigBuilder.append(tempJobConfig);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		return jobConfigBuilder.toString();
		
	}
	
	@Override
	public String generateStageConfig() {
		
		String tempJobConfig = super.generateStageConfig();
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append("stage('");
		jobConfigBuilder.append("SAST");
		jobConfigBuilder.append("'){\n");
		jobConfigBuilder.append(NEWLINE);
		
		jobConfigBuilder.append("steps{\n");
		return jobConfigBuilder.toString();
	}
	

}