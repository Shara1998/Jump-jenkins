package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class BuildStatusDTO {
	String buildStatus;

	public String getBuildStatus() {
		return buildStatus;
	}

	public void setBuildStatus(String buildStatus) {
		this.buildStatus = buildStatus;
	}
	

}
