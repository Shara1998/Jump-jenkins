package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.TaskEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeBaseMasterEntity;
import com.capgemini.genx.core.repository.IJenkinsPipelineScriptsRepository;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.ToolsDTO;





@Service
public class DbScriptUtility {

	@Autowired
	IJenkinsPipelineScriptsRepository iPipelineScriptsRepository;

	@Autowired
	IJenkinsCodeBaseMasterEntity iJenkinsCodeBaseMasterEntity;

	@Autowired
	JenkinsDTOMapUtil jenkinsDtoMapUtil;

	public String pipelineDetailsByTool(ToolsDTO toolDto, JobDTO jobDto, String jenkinsType) {
		long toolId = (long) toolDto.getToolId();

		long codebaseId = iJenkinsCodeBaseMasterEntity.getCodebaseId(jobDto.getApplicationDTO().getCodeBase());

		List<TaskEntity> pipelineScriptsEntity = iPipelineScriptsRepository.getDetailsByTool(toolId, codebaseId,
				jenkinsType);
		StringBuilder dbScript = new StringBuilder();

		for (TaskEntity t1 : pipelineScriptsEntity) {
			dbScript.append(formScriptString(t1, toolDto, jobDto));
		}

		return dbScript.toString();

	}

	public String formScriptString(TaskEntity taskEntity, ToolsDTO toolDto, JobDTO jobDto) {
		String[] pipScript = null;
		StringBuilder dbScript = new StringBuilder();
		if (taskEntity.getTaskName() != null) {
			dbScript.append(NEWLINE);
			//dbScript.append("stage('");
			//dbScript.append(taskEntity.getTaskName());
			//dbScript.append("'){\n");
			//dbScript.append("steps{\n");
		}

		String script = taskEntity.getInputs();
		pipScript = script.split("\n");
		for (String s1 : pipScript) {
			dbScript.append(s1 + "\n");
		}
		//dbScript.append(NEWLINE);
		//dbScript.append(ENDBRACE);
		//dbScript.append(NEWLINE);
		//dbScript.append(ENDBRACE);
		return (!(taskEntity.getJenkinsScriotType().equalsIgnoreCase("GroovyScript"))?updatePlaceholders(dbScript.toString(), toolDto, jobDto).toString():dbScript.toString());

	}

	public StringWriter updatePlaceholders(String dbScript, ToolsDTO toolDto, JobDTO jobDto) {

		Velocity.init();
		VelocityContext context = new VelocityContext();
		

		Map<String, Object> toolMap = jenkinsDtoMapUtil.dtoMapConversion(toolDto);
		Map<String, Object> jobDtoMap = jenkinsDtoMapUtil.dtoMapConversion(jobDto);
		Map<String, Object> repoDto = jenkinsDtoMapUtil.dtoMapConversion(toolDto.getRepositoryDTO());
		Map<String, Object> appDto = jenkinsDtoMapUtil.dtoMapConversion(jobDto.getApplicationDTO());

		StringWriter writer = new StringWriter();		
		
		if(toolMap != null) {
		toolMap.entrySet().stream().filter(Objects::nonNull)
		.forEach(e -> context.put(e.getKey(), e.getValue()));
		}
		
		if(jobDtoMap != null) {
		jobDtoMap.entrySet().stream().filter(Objects::nonNull)
		.forEach(e -> context.put(e.getKey(), e.getValue()));		
		}
		if(repoDto != null) {
		repoDto.entrySet().stream().filter(Objects::nonNull)
		.forEach(e -> context.put(e.getKey(), e.getValue()));
		}
		if(appDto != null) {
			appDto.entrySet().stream().filter(Objects::nonNull)
			.forEach(e -> context.put(e.getKey(), e.getValue()));
			}

		Velocity.evaluate(context, writer, "Exception while velocity", dbScript);
		return writer;

	}
	
	
	public static String getCommonScript() {
		StringBuilder commonScript = new StringBuilder();
		/** we will remove after shared lib */
		commonScript.append("def remote = [:]\n");
		commonScript.append("def nextstage = \"true\"\n");
		commonScript.append("Long Average=0;\n");		
		commonScript.append("def jsonObject=\"\"\n");
		commonScript.append("Long regAvgHealth=0\n");
		commonScript.append("import static java.lang.Integer.parseInt as asInteger\n");
		commonScript.append("import groovy.json.JsonSlurper\n");
		commonScript.append("import org.kohsuke.stapler.DataBoundConstructor;\n");
		commonScript.append(
				"@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.5.2')\n");
		commonScript.append(
				"@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7' )\n");
		commonScript.append("import groovyx.net.http.*\n");
		commonScript.append("import groovyx.net.http.ContentType.*\n");
		commonScript.append("import groovyx.net.http.Method.*\n");
		commonScript.append("import net.sf.json.*\n");
		commonScript.append("import static groovy.json.JsonOutput.toJson\n");
		commonScript.append("import groovy.json.JsonBuilder\n");
		commonScript.append("import groovy.json.JsonOutput\n");
		commonScript.append("import groovy.io.FileType\n");
		commonScript.append("remote.name = \"git\"\n");
		commonScript.append("remote.host = \"172.31.0.110\"\n");
		commonScript.append("remote.allowAnyHosts = true\n");
		commonScript.append("echo \"$JOB_NAME\"\n");
		commonScript.append("import java.math.BigDecimal\n");

		/** we will remove after shared lib */
		commonScript.append("pipeline {\n");
		commonScript.append("agent any\n");
		commonScript.append("tools {\n");
		commonScript.append("jdk 'JAVA_HOME'\n");
		commonScript.append("maven 'M2_HOME'\n");//
		commonScript.append("nodejs 'Nodejs1'\n");
		commonScript.append("}\n");
		commonScript.append("stages {");

		return commonScript.toString();

	}

}
