package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class LoginDTO {

	private String username;
	private String pass;
	private String validationFlag;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getValidationFlag() {
		return validationFlag;
	}
	public void setValidationFlag(String validationFlag) {
		this.validationFlag = validationFlag;
	}
	
}
