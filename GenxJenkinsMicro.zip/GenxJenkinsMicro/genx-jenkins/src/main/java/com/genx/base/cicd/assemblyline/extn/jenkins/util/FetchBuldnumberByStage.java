package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;
import com.capgemini.dashboard.reusable.entity.DeployJobEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;
import com.capgemini.dashboard.reusable.entity.RegressionInformationEntity;
import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeQualityInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsDeployJobRepo;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaJobRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;

@Service
public class FetchBuldnumberByStage {

	@Autowired
	IJenkinsCodeQualityInformationRepository iCodeQualityInformationRepository;

	@Autowired
	IJenkinsYascaJobRepository iYascaInformationRepository;

	@Autowired
	IJenkinsPerformanceInformationRepository iPerformanceInformationRepository;

	@Autowired
	IJenkinsRegressionInformationRepository iRegressionInformationRepository;

	@Autowired
	IJenkinsDeployJobRepo deployJobRepo;
	
	@Autowired
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;
	
	@Autowired
	EnvironmentServiceImplNew propertyUtil;
	
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	
	public List<String> fetchStageLogs(long jobId,String stageName) {
		
		JobInformationEntity jobEntity = iJenkinsJobInformationRepository.getJobsByJobId(jobId);

		String jenkinsUserName = propertyUtil.getEnvProperties("jenkinsUserName");
		String jenkinsPass = propertyUtil.getEnvProperties("jenkinsPass");
		devOpsWorkFlowUtil.setJenkinsPassword(jenkinsPass);
		devOpsWorkFlowUtil.setJenkinsUsername(jenkinsUserName);
		String jobName = jobEntity.getJobName();

		long buildnum = getLatestBuildNumber(jobId, stageName);

		String pipelineConsole = propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole");
		String renamePipelineConsole = pipelineConsole.replace("[project_name]", jobName);
		String finalPipelineConsoleUrl = renamePipelineConsole.replace("[build_number]", String.valueOf(buildnum));
		return devOpsWorkFlowUtil.postURLConsole(finalPipelineConsoleUrl);
		
	}

	private long getLatestBuildNumber(long jobid, String stage) {
		long buildnumber = 0;
		if ("CodeQuality".equalsIgnoreCase(stage)) {

			CodeQualityInformationEntity codeQualityInformationEntity = iCodeQualityInformationRepository
					.getCodeQualEntityByJobId(jobid);
			buildnumber = codeQualityInformationEntity.getBuildNumber();
		} else if ("SAST".equalsIgnoreCase(stage)) {
			YascaInformationEntity yascaInformationEntity = iYascaInformationRepository.getYascaEntityByJobId(jobid);
			buildnumber = yascaInformationEntity.getBuildNumberYasca();
		} else if ("Performance".equalsIgnoreCase(stage)) {
			PerformanceInformationEntity performanceInformationEntity = iPerformanceInformationRepository
					.getPerformanceEntityByJobId(jobid);
			buildnumber = performanceInformationEntity.getBuildNumber();
		}

		else if ("Regression".equalsIgnoreCase(stage)) {
			RegressionInformationEntity regressionInformationEntity = iRegressionInformationRepository
					.getRegressionEntityByJobId(jobid);
			buildnumber = regressionInformationEntity.getBuildNumberRegression();
		}

		else if ("Deployment".equalsIgnoreCase(stage)) {
			DeployJobEntity deployJobEntity = deployJobRepo.getDeployJobEntityByJobId(jobid);
			buildnumber = deployJobEntity.getBuildNumberDeploy();
		}
		return buildnumber;
	}

}
