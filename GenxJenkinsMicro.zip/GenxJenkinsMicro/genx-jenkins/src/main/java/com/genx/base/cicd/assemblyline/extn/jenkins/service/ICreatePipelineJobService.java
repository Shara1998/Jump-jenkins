package com.genx.base.cicd.assemblyline.extn.jenkins.service;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.parser.ParseException;
import org.xml.sax.SAXException;

import com.genx.base.cicd.assemblyline.extn.jenkins.dto.MessageDTO;
import com.genx.base.cicd.assemblyline.extn.jenkins.dto.PipelineDTO;
import com.genx.base.cicd.assemblyline.extn.jenkins.exception.DevOpsEnhancementException;

public interface ICreatePipelineJobService {
	
	public MessageDTO createPipelineJob(PipelineDTO pipelineDTO) throws InterruptedException, ParserConfigurationException, SAXException, IOException,NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, ParseException, DevOpsEnhancementException;
	public void downloadFeatueBranchScript(String jobName,HttpServletResponse httpresponse) throws IOException;

}
