package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class PipelineDTO {

	private SonarDTO sonarDTO;
	private DeployDTO deployDTO;
	private RegressionInformationDTO regressionInformationDTO;
	private PerformanceInformationDTO performanceInformationDTO;
	private String[] stageNames;
	private String profileType;

	public SonarDTO getSonarDTO() {
		return sonarDTO;
	}

	public void setSonarDTO(SonarDTO sonarDTO) {
		this.sonarDTO = sonarDTO;
	}

	public DeployDTO getDeployDTO() {
		return deployDTO;
	}

	public void setDeployDTO(DeployDTO deployDTO) {
		this.deployDTO = deployDTO;
	}

	public RegressionInformationDTO getRegressionInformationDTO() {
		return regressionInformationDTO;
	}

	public void setRegressionInformationDTO(RegressionInformationDTO regressionInformationDTO) {
		this.regressionInformationDTO = regressionInformationDTO;
	}

	public PerformanceInformationDTO getPerformanceInformationDTO() {
		return performanceInformationDTO;
	}

	public void setPerformanceInformationDTO(PerformanceInformationDTO performanceInformationDTO) {
		this.performanceInformationDTO = performanceInformationDTO;
	}

	public String[] getStageNames() {
		return stageNames;
	}

	public void setStageNames(String[] stageNames) {
		this.stageNames = stageNames;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

}
