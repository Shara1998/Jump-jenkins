package com.genx.base.cicd.assemblyline.extn.jenkins;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genx.base.cicd.assemblyline.factory.AbstractDevOpsFactory;
import com.genx.base.cicd.assemblyline.pipeline.IPipeline;
import com.genx.base.cicd.util.BeanFactoryDynamicAutowireService;


@Service("jenkinsFactory")
public class JenkinsFactory implements AbstractDevOpsFactory {
	@Autowired
	BeanFactoryDynamicAutowireService beanFactoryDynamicAutowireService;
	
	@Override
	public IPipeline createPipeline() throws IOException {
		return (JenkinsPipeline)beanFactoryDynamicAutowireService.createAndWire("jenkinsPipeline", JenkinsPipeline.class);
	}

	

}
