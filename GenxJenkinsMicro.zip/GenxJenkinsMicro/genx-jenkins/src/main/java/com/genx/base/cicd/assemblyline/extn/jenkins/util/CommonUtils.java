package com.genx.base.cicd.assemblyline.extn.jenkins.util;

public class CommonUtils {

	private static String jwtToken;

	public static String getJwtToken() {
		return jwtToken;
	}

	public static void setJwtToken(String jwtToken1) {
		jwtToken = jwtToken1;
	}

	CommonUtils() {
	}

}
