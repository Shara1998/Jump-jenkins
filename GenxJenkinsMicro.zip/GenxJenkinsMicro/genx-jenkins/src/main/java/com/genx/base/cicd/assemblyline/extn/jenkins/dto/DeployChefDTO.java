package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class DeployChefDTO {

	private String chefUserName;
	private String chefPass;
	private String chefWAREARFiles;
	private String chefContextPath;
	public String getChefUserName() {
		return chefUserName;
	}
	public void setChefUserName(String chefUserName) {
		this.chefUserName = chefUserName;
	}
	
	public String getChefWAREARFiles() {
		return chefWAREARFiles;
	}
	public void setChefWAREARFiles(String chefWAREARFiles) {
		this.chefWAREARFiles = chefWAREARFiles;
	}
	public String getChefContextPath() {
		return chefContextPath;
	}
	public void setChefContextPath(String chefContextPath) {
		this.chefContextPath = chefContextPath;
	}
	public String getChefPass() {
		return chefPass;
	}
	public void setChefPass(String chefPass) {
		this.chefPass = chefPass;
	}
	
}
