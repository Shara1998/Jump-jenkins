package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class NexusDetailsDTO {
	private String nexusUsername;
	private String nexusPass;
	private String nexusUrl;
	public String getNexusUsername() {
		return nexusUsername;
	}
	public void setNexusUsername(String nexusUsername) {
		this.nexusUsername = nexusUsername;
	}
	
	public String getNexusUrl() {
		return nexusUrl;
	}
	public void setNexusUrl(String nexusUrl) {
		this.nexusUrl = nexusUrl;
	}
	public String getNexusPass() {
		return nexusPass;
	}
	public void setNexusPass(String nexusPass) {
		this.nexusPass = nexusPass;
	}
	

}
