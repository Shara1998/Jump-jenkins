package com.genx.base.cicd.assemblyline.extn.jenkins.service;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.genx.base.cicd.assemblyline.extn.jenkins.dto.PipelineDTO;
import com.genx.base.cicd.assemblyline.extn.jenkins.exception.DevOpsEnhancementException;

public interface IMultibranchService {

	JSONObject createWebhook(PipelineDTO pipelineDTO) throws DevOpsEnhancementException, ParseException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, IOException;

	JSONObject webhookForBranch(String event, String token, JSONObject jsonInput) throws DevOpsEnhancementException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, IOException;
}
