package com.genx.base.cicd.tools.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.GROOVYSCRIPT;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.QUALITYGATESCRIPT;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.STRINGPARAM;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.genx.core.repository.IJenkinsPipelineScriptsRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DbScriptUtility;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.ToolsDTO;




public abstract class JenkinsAbstractTool extends com.genx.base.cicd.assemblyline.tools.AbstractTool{

	@Autowired
	IJenkinsPipelineScriptsRepository iPipelineScriptsRepository;	

	@Autowired
	DbScriptUtility dbScriptUtility;
	
	@Override
	public String generateToolConfig() {
		ToolsDTO toolDto = getToolsDTO();
		JobDTO jobDto=getJobDTO();
		return dbScriptUtility.pipelineDetailsByTool(toolDto,jobDto, GROOVYSCRIPT);
	}

	@Override
	public String generateAdditionalJobConfig() {
		ToolsDTO toolDto = getToolsDTO();
		JobDTO jobDto=getJobDTO();
		return dbScriptUtility.pipelineDetailsByTool(toolDto,jobDto, STRINGPARAM);
	}
	
	@Override
	public String generateGateConfig() {
		ToolsDTO toolDto = getToolsDTO();
		JobDTO jobDto=getJobDTO();
		return dbScriptUtility.pipelineDetailsByTool(toolDto,jobDto, QUALITYGATESCRIPT);
	}
	/**
	 * public string updateToolConfig(String xml);
	 * 
	 * return "string";
	 */
}
