package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class ServiceDetailsDTO {

	private long serviceDetailsId;
	private String serviceType;
	private String servicePlan;
	private String seviceName;

	public long getServiceDetailsId() {
		return serviceDetailsId;
	}

	public void setServiceDetailsId(long serviceDetailsId) {
		this.serviceDetailsId = serviceDetailsId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(String servicePlan) {
		this.servicePlan = servicePlan;
	}

	public String getSeviceName() {
		return seviceName;
	}

	public void setSeviceName(String seviceName) {
		this.seviceName = seviceName;
	}

}
