package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class FileParsingUtilNew {
	
	private FileParsingUtilNew() {
		
	}
	
	public static Document fileParsing(File xmlFile) throws ParserConfigurationException, SAXException, IOException {
		
		DocumentBuilder dBuilder = docBuilder();
		return dBuilder.parse(xmlFile);
	}
	
	public static DocumentBuilder docBuilder() throws ParserConfigurationException {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();	
		
		dbFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
		
		return dbFactory.newDocumentBuilder();
	}
	
	public static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try  
        {  
            builder = factory.newDocumentBuilder();  
            
            return builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }


}
