package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class SVNCredentialsDTO {
	private String svnCredUserName;
	private long credentialId;
	private String svnPass;
	private String gitCredUserName;
	private String gitPass;
	public long getCredentialId() {
		return credentialId;
	}
	public void setCredentialId(long credentialId) {
		this.credentialId = credentialId;
	}
	public String getSvnCredUserName() {
		return svnCredUserName;
	}
	public void setSvnCredUserName(String svnCredUserName) {
		this.svnCredUserName = svnCredUserName;
	}
	public String getSvnPass() {
		return svnPass;
	}
	public void setSvnPass(String svnPass) {
		this.svnPass = svnPass;
	}
	public String getGitCredUserName() {
		return gitCredUserName;
	}
	public void setGitCredUserName(String gitCredUserName) {
		this.gitCredUserName = gitCredUserName;
	}
	public String getGitPass() {
		return gitPass;
	}
	public void setGitPass(String gitPass) {
		this.gitPass = gitPass;
	}
	
}
