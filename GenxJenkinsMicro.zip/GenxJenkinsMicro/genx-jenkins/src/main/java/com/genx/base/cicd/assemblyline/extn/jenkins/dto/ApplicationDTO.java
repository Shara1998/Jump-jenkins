package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.Date;
import java.util.List;

public class ApplicationDTO {
	
	private long applicationId;
	private String applicationName;	
	private Date releaseDateTo;
	private Date releaseDateFrom;
	private String applicationType;
	private String codeBase;
	private String groupId;
	private List<JobDTO> jobList;
	private List<GroupDTO> groupDTOs;
	private MessageDTO messageDTO;
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getCodeBase() {
		return codeBase;
	}

	public void setCodeBase(String codeBase) {
		this.codeBase = codeBase;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public Date getReleaseDateTo() {
		return releaseDateTo;
	}

	public void setReleaseDateTo(Date releaseDateTo) {
		this.releaseDateTo = releaseDateTo;
	}

	public Date getReleaseDateFrom() {
		return releaseDateFrom;
	}

	public void setReleaseDateFrom(Date releaseDateFrom) {
		this.releaseDateFrom = releaseDateFrom;
	}

	

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public List<JobDTO> getJobList() {
		return jobList;
	}

	public void setJobList(List<JobDTO> jobList) {
		this.jobList = jobList;
	}

	@Override
	public String toString() {
		return "ApplicationDTO [applicationId=" + applicationId + ", applicationName=" + applicationName
				+ ", releaseDateTo=" + releaseDateTo + ", releaseDateFrom=" + releaseDateFrom + ", jobList=" + jobList
				+ "]";
	}

	public List<GroupDTO> getGroupDTOs() {
		return groupDTOs;
	}

	public void setGroupDTOs(List<GroupDTO> groupDTOs) {
		this.groupDTOs = groupDTOs;
	}

	public MessageDTO getMessageDTO() {
		return messageDTO;
	}

	public void setMessageDTO(MessageDTO messageDTO) {
		this.messageDTO = messageDTO;
	}
	
	

}
