package com.genx.base.cicd.stages.extn.jenkins;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;
import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeQualityInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.CodeQualityStage;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.exception.GenxCICDException;

@Service("Codequality")
public class JenkinsCodeQualityStage extends CodeQualityStage {

	
	@Autowired
	IJenkinsCodeQualityInformationRepository iJenkinsCodeQualityInformationRepository;

	@Autowired
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;
	
	@Autowired
	ToolFactory toolFactory;
	
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;

	@Autowired
	EnvironmentServiceImplNew propertyUtil;
	
	@Autowired
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;
	@Autowired
	FetchBuldnumberByStage fetchBuldnumberByStage;

	@Override
	public Boolean buildStage() {
		

		com.genx.base.cicd.dto.JobDTO jobDto = getJobDTO();
		JobInformationEntity jobInformationEntity = iJenkinsJobInformationRepository.findByAppName(jobDto.getJobName());
		CodeQualityInformationEntity codeQualityInformationEntity = iJenkinsCodeQualityInformationRepository
				.getCodeQualEntityByJobId(jobInformationEntity.getJobId());

		if (Objects.isNull(codeQualityInformationEntity)) {
			codeQualityInformationEntity = new CodeQualityInformationEntity();
		}
		codeQualityInformationEntity.setJobInformationEntity(jobInformationEntity);
		FlagEntity defaultFlag = new FlagEntity();
		defaultFlag.setFlag(false);
		codeQualityInformationEntity.setSonarAvgHealth(0l);
		codeQualityInformationEntity.setFlagEntity(defaultFlag);
		codeQualityInformationEntity.setLastBuild(new Date());
		codeQualityInformationEntity.setCodeQualityBuildStatus("in progress");
		iJenkinsCodeQualityInformationRepository.save(codeQualityInformationEntity);
		return jenkinsBuildStageUtil.buildIndividualStage(jobDto, "Code%20Quality");
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean saveStageMetrics(JSONObject metrics, String jobNameBuildStatus, Long buildNum, Long platformTypeId,
			Long stageId, Long toolId, Long avgHelth) throws GenxCICDException {
		
		
		String[] jobNameBuildStatusarrCQ = jobNameBuildStatus.split(":");
		metrics.put("avgHelth", avgHelth);	
		metrics.put("jobName", jobNameBuildStatusarrCQ[0]);
		metrics.put("buildStatus", jobNameBuildStatusarrCQ[1]);
		metrics.put("buildNum", buildNum);				

		ITool iToolcq = toolFactory.create(platformTypeId, toolId);
		return iToolcq.saveMetrics(metrics,platformTypeId,toolId);

	
	}
	
	@Override
	public List<String> getStageLogs(long jobId, long stageId) {
		
		return fetchBuldnumberByStage.fetchStageLogs(jobId,"CodeQuality");
		
	}
	
	@Override
	public String generateJobConfig() throws GenxCICDException {

		String tempJobConfig = super.generateJobConfig();
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		
		jobConfigBuilder.append(tempJobConfig);
		jobConfigBuilder.append(NEWLINE);            
		jobConfigBuilder.append(ENDBRACE);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		return jobConfigBuilder.toString();
		
	}
	
	@Override
	public String generateStageConfig() {
		
		String tempJobConfig = super.generateStageConfig();
		
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		
				jobConfigBuilder.append(NEWLINE);
				jobConfigBuilder.append("stage('");
				jobConfigBuilder.append("Code Quality");
				jobConfigBuilder.append("'){\n");
				jobConfigBuilder.append(NEWLINE);
				
				
				jobConfigBuilder.append("steps{\n");
		
		
		return jobConfigBuilder.toString();
	}
	
	
}
