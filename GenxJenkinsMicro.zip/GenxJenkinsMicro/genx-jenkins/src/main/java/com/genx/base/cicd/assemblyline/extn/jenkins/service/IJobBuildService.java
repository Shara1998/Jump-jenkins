package com.genx.base.cicd.assemblyline.extn.jenkins.service;

import java.io.IOException;

import org.json.simple.JSONObject;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;
import com.genx.base.cicd.assemblyline.extn.jenkins.dto.BuildStatusDTO;
import com.genx.base.cicd.assemblyline.extn.jenkins.dto.MessageDTO;
import com.genx.base.cicd.assemblyline.extn.jenkins.dto.StageDTO;


public interface IJobBuildService {

    public MessageDTO buildJob(JSONObject jsonObject) throws InterruptedException;

	public MessageDTO buidAppJobs(String projectId);
	public BuildStatusDTO fetchSonarBuildStatus(long jobId);
	public BuildStatusDTO fetchYascaBuildStatus(long jobId);

	public BuildStatusDTO fetchBuildStatusByProjectId(String projectId);
	public BuildStatusDTO fetchBuildStatus(long jobId, String stage);
	public StageDTO fetchJobStages(String jobName);
	public String buildSVNJob(String jobName) throws InterruptedException, IOException;
	String buildJenkinsUser(String jobName, String userPassword) throws InterruptedException, IOException;
	public MessageDTO sonarHeapBuild() throws InterruptedException;
	public MessageDTO automaticBuildJob(JSONObject jsonObject)throws InterruptedException, IOException;
	public MessageDTO fetchJunitSonarReport(String jobName, CodeQualityInformationEntity codeQualityInformationEntity);
	public MessageDTO buildTerraFormJob(String jobName) throws IOException;
	public String buildContainerServiceJob(String string) throws IOException, InterruptedException;
}
