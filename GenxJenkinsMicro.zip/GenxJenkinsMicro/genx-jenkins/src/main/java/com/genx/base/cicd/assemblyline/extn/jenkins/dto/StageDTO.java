package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class StageDTO {
	
	/**dummy method variable to avoid sonar error*/
	
	private String dummyVar;

	public String getDummyVar() {
		return dummyVar;
	}

	public void setDummyVar(String dummyVar) {
		this.dummyVar = dummyVar;
	}

	
}
