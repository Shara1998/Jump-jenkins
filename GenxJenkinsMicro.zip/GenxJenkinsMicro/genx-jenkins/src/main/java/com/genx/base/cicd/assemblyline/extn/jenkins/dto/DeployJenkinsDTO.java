package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import com.genx.base.cicd.dto.ToolsDTO;

public class DeployJenkinsDTO extends ToolsDTO{

	private String normalServerType;
	private String tomcatUserName;
	private String tomcatPass;
	private String tomcatUrl;
	private String jBossUserName;
	private String jBossPass;
	private String jBossUrl;
	private String normalWAREARFiles;
	private String normalContextPath;
	
	private String jBossHostName;
	private String jBossPort;
	private String serverGroup;
	
	public String getjBossHostName() {
		return jBossHostName;
	}
	public void setjBossHostName(String jBossHostName) {
		this.jBossHostName = jBossHostName;
	}
	public String getjBossPort() {
		return jBossPort;
	}
	public void setjBossPort(String jBossPort) {
		this.jBossPort = jBossPort;
	}
	public String getServerGroup() {
		return serverGroup;
	}
	public void setServerGroup(String serverGroup) {
		this.serverGroup = serverGroup;
	}
	public String getTomcatUserName() {
		return tomcatUserName;
	}
	public void setTomcatUserName(String tomcatUserName) {
		this.tomcatUserName = tomcatUserName;
	}
	
	public String getTomcatUrl() {
		return tomcatUrl;
	}
	public void setTomcatUrl(String tomcatUrl) {
		this.tomcatUrl = tomcatUrl;
	}
	
	public String getNormalServerType() {
		return normalServerType;
	}
	public void setNormalServerType(String normalServerType) {
		this.normalServerType = normalServerType;
	}
	public String getjBossUserName() {
		return jBossUserName;
	}
	public void setjBossUserName(String jBossUserName) {
		this.jBossUserName = jBossUserName;
	}
	
	public String getjBossUrl() {
		return jBossUrl;
	}
	public void setjBossUrl(String jBossUrl) {
		this.jBossUrl = jBossUrl;
	}
	public String getNormalWAREARFiles() {
		return normalWAREARFiles;
	}
	public void setNormalWAREARFiles(String normalWAREARFiles) {
		this.normalWAREARFiles = normalWAREARFiles;
	}
	public String getNormalContextPath() {
		return normalContextPath;
	}
	public void setNormalContextPath(String normalContextPath) {
		this.normalContextPath = normalContextPath;
	}
	public String getTomcatPass() {
		return tomcatPass;
	}
	public void setTomcatPass(String tomcatPass) {
		this.tomcatPass = tomcatPass;
	}
	public String getjBossPass() {
		return jBossPass;
	}
	public void setjBossPass(String jBossPass) {
		this.jBossPass = jBossPass;
	}
}
