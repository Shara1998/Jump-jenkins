package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class DeployDTO {
	private DeployJenkinsDTO deployJenkinsDTO;
	private DeployChefDTO deployChefDTO;
	private DeployCloudFoundryDTO deployCloudFoundryDTO;
	private RepositoryDTO repositoryDTO;
	private SonarDTO sonarDTO;
    private JobDTO jobDTO;
    private AwsDeploymentDTO awsDeploymentDTO;
	private DockerInformationDTO dockerInformationDTO;
	private KubernetesDTO kubernetesDTO;
	private WebLogicDTO webLogicDTO;
	private NexusDetailsDTO nexusDetailsDTO;
	private DotNetDTO dotNetDTO;
	private JfrogDTO jfrogDTO;
	private String registryType;
	private String lambdaFunction;
	private FargateDTO fargateDTO;	
	
	public JfrogDTO getJfrogDTO() {
		return jfrogDTO;
	}
	public void setJfrogDTO(JfrogDTO jfrogDTO) {
		this.jfrogDTO = jfrogDTO;
	}
	public DotNetDTO getDotNetDTO() {
		return dotNetDTO;
	}
	public void setDotNetDTO(DotNetDTO dotNetDTO) {
		this.dotNetDTO = dotNetDTO;
	}
	public NexusDetailsDTO getNexusDetailsDTO() {
		return nexusDetailsDTO;
	}
	public void setNexusDetailsDTO(NexusDetailsDTO nexusDetailsDTO) {
		this.nexusDetailsDTO = nexusDetailsDTO;
	}
	public WebLogicDTO getWebLogicDTO() {
		return webLogicDTO;
	}
	public void setWebLogicDTO(WebLogicDTO webLogicDTO) {
		this.webLogicDTO = webLogicDTO;
	}
	public JobDTO getJobDTO() {
		return jobDTO;
	}
	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}
	
	
	public SonarDTO getSonarDTO() {
		return sonarDTO;
	}
	public void setSonarDTO(SonarDTO sonarDTO) {
		this.sonarDTO = sonarDTO;
	}
	public DeployJenkinsDTO getDeployJenkinsDTO() {
		return deployJenkinsDTO;
	}
	public void setDeployJenkinsDTO(DeployJenkinsDTO deployJenkinsDTO) {
		this.deployJenkinsDTO = deployJenkinsDTO;
	}
	public DeployChefDTO getDeployChefDTO() {
		return deployChefDTO;
	}
	public void setDeployChefDTO(DeployChefDTO deployChefDTO) {
		this.deployChefDTO = deployChefDTO;
	}
	
	public DeployCloudFoundryDTO getDeployCloudFoundryDTO() {
		return deployCloudFoundryDTO;
	}
	public void setDeployCloudFoundryDTO(DeployCloudFoundryDTO deployCloudFoundryDTO) {
		this.deployCloudFoundryDTO = deployCloudFoundryDTO;
	}
	public RepositoryDTO getRepositoryDTO() {
		return repositoryDTO;
	}
	public void setRepositoryDTO(RepositoryDTO repositoryDTO) {
		this.repositoryDTO = repositoryDTO;
	}
	public AwsDeploymentDTO getAwsDeploymentDTO() {
		return awsDeploymentDTO;
	}
	public void setAwsDeploymentDTO(AwsDeploymentDTO awsDeploymentDTO) {
		this.awsDeploymentDTO = awsDeploymentDTO;
	}
	public DockerInformationDTO getDockerInformationDTO() {
		return dockerInformationDTO;
	}
	public void setDockerInformationDTO(DockerInformationDTO dockerInformationDTO) {
		this.dockerInformationDTO = dockerInformationDTO;
	}
	public KubernetesDTO getKubernetesDTO() {
		return kubernetesDTO;
	}
	public void setKubernetesDTO(KubernetesDTO kubernetesDTO) {
		this.kubernetesDTO = kubernetesDTO;
	}
	public String getRegistryType() {
		return registryType;
	}
	public void setRegistryType(String registryType) {
		this.registryType = registryType;
	}
	public String getLambdaFunction() {
		return lambdaFunction;
	}
	
	public FargateDTO getFargateDTO() {
		return fargateDTO;
	}
	public void setFargateDTO(FargateDTO fargateDTO) {
		this.fargateDTO = fargateDTO;
	}
	public void setLambdaFunction(String lambdaFunction) {
		this.lambdaFunction = lambdaFunction;
	}
	
	
}
