package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import com.genx.base.cicd.dto.ToolsDTO;

public class IstanbulDTO extends ToolsDTO{

	
	private String statements;
	
	private String branches;
	
	private String functions;
	
	private String lines;
	
	private byte[] reportContent;
	
	private String reportContentType;


	public byte[] getReportContent() {
		return reportContent;
	}

	public void setReportContent(byte[] reportContent) {
		this.reportContent = reportContent;
	}


	public String getReportContentType() {
		return reportContentType;
	}

	public void setReportContentType(String reportContentType) {
		this.reportContentType = reportContentType;
	}

	public String getStatements() {
		return statements;
	}

	public void setStatements(String statements) {
		this.statements = statements;
	}

	public String getBranches() {
		return branches;
	}

	public void setBranches(String branches) {
		this.branches = branches;
	}

	public String getFunctions() {
		return functions;
	}

	public void setFunctions(String functions) {
		this.functions = functions;
	}

	public String getLines() {
		return lines;
	}

	public void setLines(String lines) {
		this.lines = lines;
	}
	
	
}
