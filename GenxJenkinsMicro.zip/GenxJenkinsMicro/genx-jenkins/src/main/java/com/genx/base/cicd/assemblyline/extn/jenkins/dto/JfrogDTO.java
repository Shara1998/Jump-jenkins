package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class JfrogDTO {
	private String jfrogUserName;
	private String jfrogPass;
	private String filestoArchive;
	
	private String artifactoryServerUrl;
	
	private String targetReleasesRepository;
	
	private String targetSnapshotRepository;

	private String sshSite;
	
	private String pathtoDownload;
	
	private String artifactorypath;
	
	
	

	public String getArtifactoryServerUrl() {
		return artifactoryServerUrl;
	}

	public void setArtifactoryServerUrl(String artifactoryServerUrl) {
		this.artifactoryServerUrl = artifactoryServerUrl;
	}

	public String getSshSite() {
		return sshSite;
	}

	public void setSshSite(String sshSite) {
		this.sshSite = sshSite;
	}

	public String getPathtoDownload() {
		return pathtoDownload;
	}

	public void setPathtoDownload(String pathtoDownload) {
		this.pathtoDownload = pathtoDownload;
	}

	public String getArtifactorypath() {
		return artifactorypath;
	}

	public void setArtifactorypath(String artifactorypath) {
		this.artifactorypath = artifactorypath;
	}

	public String getJfrogUserName() {
		return jfrogUserName;
	}

	public void setJfrogUserName(String jfrogUserName) {
		this.jfrogUserName = jfrogUserName;
	}

	
	public String getFilestoArchive() {
		return filestoArchive;
	}

	public void setFilestoArchive(String filestoArchive) {
		this.filestoArchive = filestoArchive;
	}

	

	public String getTargetReleasesRepository() {
		return targetReleasesRepository;
	}

	public void setTargetReleasesRepository(String targetReleasesRepository) {
		this.targetReleasesRepository = targetReleasesRepository;
	}

	public String getTargetSnapshotRepository() {
		return targetSnapshotRepository;
	}

	public void setTargetSnapshotRepository(String targetSnapshotRepository) {
		this.targetSnapshotRepository = targetSnapshotRepository;
	}

	public String getJfrogPass() {
		return jfrogPass;
	}

	public void setJfrogPass(String jfrogPass) {
		this.jfrogPass = jfrogPass;
	}
	
	
	

}
