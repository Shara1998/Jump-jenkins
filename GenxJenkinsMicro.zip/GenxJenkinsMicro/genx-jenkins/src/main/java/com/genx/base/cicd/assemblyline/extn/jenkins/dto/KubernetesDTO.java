package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import com.genx.base.cicd.dto.ToolsDTO;

public class KubernetesDTO extends ToolsDTO{
	private String env;
	private String imageName;
	private String bucketPath;
	private String buildPath;
	private long port;
	private String ecrAwsUrl;
	private String registryType;
	
	private String awsEcsTaskDefinition;
	private String awsEcsService;
	private String awsEcsCluster;
	
	
	
	public String getAwsEcsTaskDefinition() {
		return awsEcsTaskDefinition;
	}
	public void setAwsEcsTaskDefinition(String awsEcsTaskDefinition) {
		this.awsEcsTaskDefinition = awsEcsTaskDefinition;
	}
	public String getAwsEcsService() {
		return awsEcsService;
	}
	public void setAwsEcsService(String awsEcsService) {
		this.awsEcsService = awsEcsService;
	}
	public String getAwsEcsCluster() {
		return awsEcsCluster;
	}
	public void setAwsEcsCluster(String awsEcsCluster) {
		this.awsEcsCluster = awsEcsCluster;
	}
	public String getEnv() {
		return env;
	}
	public void setEnv(String env) {
		this.env = env;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getBucketPath() {
		return bucketPath;
	}
	public void setBucketPath(String bucketPath) {
		this.bucketPath = bucketPath;
	}
	public String getBuildPath() {
		return buildPath;
	}
	public void setBuildPath(String buildPath) {
		this.buildPath = buildPath;
	}
	public long getPort() {
		return port;
	}
	public void setPort(long port) {
		this.port = port;
	}
	public String getEcrAwsUrl() {
		return ecrAwsUrl;
	}
	public void setEcrAwsUrl(String ecrAwsUrl) {
		this.ecrAwsUrl = ecrAwsUrl;
	}
	public String getRegistryType() {
		return registryType;
	}
	public void setRegistryType(String registryType) {
		this.registryType = registryType;
	}
}
