package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class DockerInformationDTO {
	private String port;
	/** private boolean deployUserServer; */
	private String hostName;
	/**private String username;
	*/
	private String pathToDockerFile;
	/** private boolean uploadDockerFile;

	private String url;*/
	private String jarName;

	/** private String deployable; */

	private RepositoryDTO repositoryDTO;

	

	/**public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
*/
	public String getJarName() {
		return jarName;
	}

	public void setJarName(String jarName) {
		this.jarName = jarName;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public RepositoryDTO getRepositoryDTO() {
		return repositoryDTO;
	}

	public void setRepositoryDTO(RepositoryDTO repositoryDTO) {
		this.repositoryDTO = repositoryDTO;
	}

	/**
	 * public boolean isDeployUserServer() { return deployUserServer; }
	 * 
	 * public void setDeployUserServer(boolean deployUserServer) {
	 * this.deployUserServer = deployUserServer; }
	 */

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	
*/
	public String getPathToDockerFile() {
		return pathToDockerFile;
	}

	public void setPathToDockerFile(String pathToDockerFile) {
		this.pathToDockerFile = pathToDockerFile;
	}

	/**
	 * public boolean isUploadDockerFile() { return uploadDockerFile; }
	 * 
	 * public void setUploadDockerFile(boolean uploadDockerFile) {
	 * this.uploadDockerFile = uploadDockerFile; }
	 * 
	 * public String getDeployable() { return deployable; }
	 * 
	 * public void setDeployable(String deployable) { this.deployable =
	 * deployable; }
	 */

}
