package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class AwsDeploymentDTO {

	private long awsDeploymentId;
	private String awsApplicationName;
	private String awsApplicationGroupName;
	private String awsCodeDeploymentConfig;
	private String awsRegion;
	private String awsBucket;
	private String awsPrefix;
	private String awsUseAccesskey;
	private String accessKey;
	private String secretKey;
	private JobDTO jobDTO;
	private String awsRegistryURL;

	public long getAwsDeploymentId() {
		return awsDeploymentId;
	}

	public void setAwsDeploymentId(long awsDeploymentId) {
		this.awsDeploymentId = awsDeploymentId;
	}

	public String getAwsApplicationName() {
		return awsApplicationName;
	}

	public void setAwsApplicationName(String awsApplicationName) {
		this.awsApplicationName = awsApplicationName;
	}

	public String getAwsApplicationGroupName() {
		return awsApplicationGroupName;
	}

	public void setAwsApplicationGroupName(String awsApplicationGroupName) {
		this.awsApplicationGroupName = awsApplicationGroupName;
	}

	public String getAwsCodeDeploymentConfig() {
		return awsCodeDeploymentConfig;
	}

	public void setAwsCodeDeploymentConfig(String awsCodeDeploymentConfig) {
		this.awsCodeDeploymentConfig = awsCodeDeploymentConfig;
	}

	public String getAwsRegion() {
		return awsRegion;
	}

	public void setAwsRegion(String awsRegion) {
		this.awsRegion = awsRegion;
	}

	public String getAwsBucket() {
		return awsBucket;
	}

	public void setAwsBucket(String awsBucket) {
		this.awsBucket = awsBucket;
	}

	public String getAwsPrefix() {
		return awsPrefix;
	}

	public void setAwsPrefix(String awsPrefix) {
		this.awsPrefix = awsPrefix;
	}

	public String getAwsUseAccesskey() {
		return awsUseAccesskey;
	}

	public void setAwsUseAccesskey(String awsUseAccesskey) {
		this.awsUseAccesskey = awsUseAccesskey;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public JobDTO getJobDTO() {
		return jobDTO;
	}

	public void setJobDTO(JobDTO jobDTO) {
		this.jobDTO = jobDTO;
	}

	public String getAwsRegistryURL() {
		return awsRegistryURL;
	}

	public void setAwsRegistryURL(String awsRegistryURL) {
		this.awsRegistryURL = awsRegistryURL;
	}
}
