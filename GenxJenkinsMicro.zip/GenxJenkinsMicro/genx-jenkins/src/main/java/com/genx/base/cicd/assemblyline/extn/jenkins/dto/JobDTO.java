package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.Date;
import java.util.List;

public class JobDTO {

	private long jobId;
	private String jobName;
	private String jobType;
	private String jenkinsUserName;
	private String jenkinsPass;
	private String buildTools;
	private String comments;
	private String codeBaseVersion;
	private String userName;
	private String applicationType;
	private Date releaseDate;
	private String jobStatus;
	private String codeBase;
	private double overallStatus;
	private String groupId;
	private List<GroupDTO> groupDTOs;
	private List<AppDetails2DTO> appDetails2DTOs;
	private Long qualityGateId;	
	private String jobStyle;	
	private Boolean jobActive;

	public Long getQualityGateId() {
		return qualityGateId;
	}

	public void setQualityGateId(Long qualityGateId) {
		this.qualityGateId = qualityGateId;
	}

	public List<AppDetails2DTO> getAppDetails2DTOs() {
		return appDetails2DTOs;
	}

	public void setAppDetails2DTOs(List<AppDetails2DTO> appDetails2DTOs) {
		this.appDetails2DTOs = appDetails2DTOs;
	}

	public double getOverallStatus() {
		return overallStatus;
	}

	public void setOverallStatus(double overallStatus) {
		this.overallStatus = overallStatus;
	}

	public String getCodeBase() {
		return codeBase;
	}

	public void setCodeBase(String codeBase) {
		this.codeBase = codeBase;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCodeBaseVersion() {
		return codeBaseVersion;
	}

	public void setCodeBaseVersion(String codeBaseVersion) {
		this.codeBaseVersion = codeBaseVersion;
	}

	public String getBuildTools() {
		return buildTools;
	}

	public void setBuildTools(String buildTools) {
		this.buildTools = buildTools;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getJenkinsUserName() {
		return jenkinsUserName;
	}

	public String getJobStyle() {
		return jobStyle;
	}

	public void setJobStyle(String jobStyle) {
		this.jobStyle = jobStyle;
	}

	public void setJenkinsUserName(String jenkinsUserName) {
		this.jenkinsUserName = jenkinsUserName;
	}

	
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public List<GroupDTO> getGroupDTOs() {
		return groupDTOs;
	}

	public void setGroupDTOs(List<GroupDTO> groupDTOs) {
		this.groupDTOs = groupDTOs;
	}

	public Boolean getJobActive() {
		return jobActive;
	}

	public void setJobActive(Boolean jobActive) {
		this.jobActive = jobActive;
	}

	public String getJenkinsPass() {
		return jenkinsPass;
	}

	public void setJenkinsPass(String jenkinsPass) {
		this.jenkinsPass = jenkinsPass;
	}
}
