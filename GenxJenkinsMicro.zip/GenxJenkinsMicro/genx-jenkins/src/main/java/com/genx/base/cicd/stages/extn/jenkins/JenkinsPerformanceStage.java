package com.genx.base.cicd.stages.extn.jenkins;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.ENDBRACE;
import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.NEWLINE;
import java.util.List;
import java.util.Objects;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceThresholdEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJnkinsPerformanceThresholdRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.PerformanceStage;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;

@Service("Performance")
public class JenkinsPerformanceStage extends PerformanceStage {

	private static final Logger logger = LoggerFactory.getLogger(JenkinsPerformanceStage.class);

	@Autowired
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Autowired
	ToolFactory toolFactory;
	@Autowired
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	IJenkinsPerformanceInformationRepository iJenkinsPerformanceInformationRepository;

	@Autowired
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;
	@Autowired
	IJnkinsPerformanceThresholdRepository iJnkinsPerformanceThresholdRepository;

	@Autowired
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;
	@Autowired
	FetchBuldnumberByStage fetchBuldnumberByStage;

	@Override
	public Boolean buildStage() {

		JobDTO jobDto = getJobDTO();
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobDto.getJobName());
		PerformanceInformationEntity performanceInformationEntity = iJenkinsPerformanceInformationRepository
				.getPerformanceEntityByJobId(jobInformationEntity.getJobId());
		performanceInformationEntity.setJobInformationEntity(jobInformationEntity);
		performanceInformationEntity.setPerformanceBuildStatus("in progress");
		iJenkinsPerformanceInformationRepository.save(performanceInformationEntity);
		return jenkinsBuildStageUtil.buildIndividualStage(jobDto, "Performance");
	}

	@Override
	public Boolean compareMetricsWithThreshold(String jobName, Long buildNum, String buildStatus, Long platformTypeId,
			Long toolId) {

		JSONObject metrics = getJson(jobName, buildNum, buildStatus);

		try {
			saveStageMetrics(metrics, jobName, buildNum, platformTypeId, 5l, toolId, null);
		} catch (GenxCICDException e1) {
			logger.info("message--", e1.getMessage());
		}

		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobName);
		PerformanceInformationEntity performanceInformationEntity = iJenkinsPerformanceInformationRepository
				.getPerformanceEntityByJobId(jobInformationEntity.getJobId());
		ProfileGroupNameEntity profileGroupNameEntity = iJenkinsProfileGroupNameRepository
				.findByProfileName(jobInformationEntity.getGroupId());
		PerformanceThresholdEntity performanceThresholdEntity = iJnkinsPerformanceThresholdRepository
				.fetchPerThreshold(profileGroupNameEntity.getProfileGroupNameId(), toolId);
		Boolean statusFlag = false;
		try {
			if (Objects.nonNull(performanceInformationEntity)
					&& performanceInformationEntity.getResponseTime() != null) {

				long responseTime = Long.parseLong(performanceInformationEntity.getResponseTime());
				long resposeThreshold = performanceThresholdEntity.getResponseTime();
				long goodLevelPercentage = performanceThresholdEntity.getPerGoodLevelPercentage();
				long riskLevelPercentage = performanceThresholdEntity.getPerRiskLevelPercentage();
				if (responseTime <= resposeThreshold && responseTime > 0) {
					performanceInformationEntity.setPerformanceAvgHealth(goodLevelPercentage);
					statusFlag = true;
				} else {
					performanceInformationEntity.setPerformanceAvgHealth(riskLevelPercentage);

				}

			}

			iJenkinsPerformanceInformationRepository.save(performanceInformationEntity);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		return statusFlag;
	}

	@SuppressWarnings("unchecked")
	private JSONObject getJson(String jobName, Long buildNum, String buildStatus) {
		JSONObject metrics = new JSONObject();
		metrics.put("jobName", jobName);
		metrics.put("buildNum", buildNum);
		metrics.put("buildStatus", buildStatus);
		return metrics;
	}

	@Override
	public Boolean saveStageMetrics(JSONObject metrics, String jobNameBuildStatus, Long buildNum, Long platformTypeId,
			Long stageId, Long toolId, Long avgHelth) throws GenxCICDException {
		ITool iTool = toolFactory.create(platformTypeId, toolId);

		return iTool.saveMetrics(metrics, platformTypeId, toolId);

	}

	@Override
	public List<String> getStageLogs(long jobId, long stageId) {
		
		return fetchBuldnumberByStage.fetchStageLogs(jobId,"Performance");
	}
	
	@Override
	public String generateJobConfig() throws GenxCICDException {

		String tempJobConfig = super.generateJobConfig();
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		
		jobConfigBuilder.append(tempJobConfig);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append(ENDBRACE);
		return jobConfigBuilder.toString();
		
	}
	
	
	@Override
	public String generateStageConfig() {
		
		String tempJobConfig = super.generateStageConfig();
		
		StringBuilder jobConfigBuilder = new StringBuilder(); 
		jobConfigBuilder.append(NEWLINE);
		jobConfigBuilder.append("stage('");
		jobConfigBuilder.append("Performance");
		jobConfigBuilder.append("'){\n");
		jobConfigBuilder.append(NEWLINE);
		
		jobConfigBuilder.append("steps{\n");
		return jobConfigBuilder.toString();
	}
	

}
