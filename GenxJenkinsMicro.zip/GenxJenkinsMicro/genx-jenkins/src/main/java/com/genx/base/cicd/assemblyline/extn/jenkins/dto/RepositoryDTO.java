package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

public class RepositoryDTO {
	
    private long repoId;	
	private String repoType;
	private String svnURL;
	private String localModuleDirectory;
	private String svnUserName;
	private String svnPass;
	private String cvsRoot;
	private String cvsPass;
	private String remoteName;
	private String localName;
	private String cvsLocation;
    private String branchName;
    private String tagName;
    private String gitURL;
    private String gitBranch;
    private String gitUserName;
	private String gitPass;
    private String tfsUsername;
    private String tfsPass;
    private String collectionUrl;
    private String projectPath;
    private String componentName;
    private String featureBranchName;
    
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getTfsUsername() {
		return tfsUsername;
	}
	public void setTfsUsername(String tfsUsername) {
		this.tfsUsername = tfsUsername;
	}
	
	public String getCollectionUrl() {
		return collectionUrl;
	}
	public void setCollectionUrl(String collectionUrl) {
		this.collectionUrl = collectionUrl;
	}
	public String getLocalName() {
		return localName;
	}
	public void setLocalName(String localName) {
		this.localName = localName;
	}
	public long getRepoId() {
		return repoId;
	}
	public void setRepoId(long repoId) {
		this.repoId = repoId;
	}
	public String getRepoType() {
		return repoType;
	}
	public void setRepoType(String repoType) {
		this.repoType = repoType;
	}
	public String getSvnURL() {
		return svnURL;
	}
	public void setSvnURL(String svnURL) {
		this.svnURL = svnURL;
	}
	public String getLocalModuleDirectory() {
		return localModuleDirectory;
	}
	public void setLocalModuleDirectory(String localModuleDirectory) {
		this.localModuleDirectory = localModuleDirectory;
	}
	public String getCvsRoot() {
		return cvsRoot;
	}
	public void setCvsRoot(String cvsRoot) {
		this.cvsRoot = cvsRoot;
	}
	
	public String getRemoteName() {
		return remoteName;
	}
	public void setRemoteName(String remoteName) {
		this.remoteName = remoteName;
	}
	public String getCvsLocation() {
		return cvsLocation;
	}
	public void setCvsLocation(String cvsLocation) {
		this.cvsLocation = cvsLocation;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public String getGitURL() {
		return gitURL;
	}
	public void setGitURL(String gitURL) {
		this.gitURL = gitURL;
	}
	public String getGitBranch() {
		return gitBranch;
	}
	public void setGitBranch(String gitBranch) {
		this.gitBranch = gitBranch;
	}
	public String getProjectPath() {
		return projectPath;
	}
	public void setProjectPath(String projectPath) {
		this.projectPath = projectPath;
	}
	public String getSvnUserName() {
		return svnUserName;
	}
	public void setSvnUserName(String svnUserName) {
		this.svnUserName = svnUserName;
	}
	
	public String getGitUserName() {
		return gitUserName;
	}
	public void setGitUserName(String gitUserName) {
		this.gitUserName = gitUserName;
	}
	
	public String getFeatureBranchName() {
		return featureBranchName;
	}
	public void setFeatureBranchName(String featureBranchName) {
		this.featureBranchName = featureBranchName;
	}
	public String getSvnPass() {
		return svnPass;
	}
	public void setSvnPass(String svnPass) {
		this.svnPass = svnPass;
	}
	public String getCvsPass() {
		return cvsPass;
	}
	public void setCvsPass(String cvsPass) {
		this.cvsPass = cvsPass;
	}
	public String getGitPass() {
		return gitPass;
	}
	public void setGitPass(String gitPass) {
		this.gitPass = gitPass;
	}
	public String getTfsPass() {
		return tfsPass;
	}
	public void setTfsPass(String tfsPass) {
		this.tfsPass = tfsPass;
	}
	
	
}
