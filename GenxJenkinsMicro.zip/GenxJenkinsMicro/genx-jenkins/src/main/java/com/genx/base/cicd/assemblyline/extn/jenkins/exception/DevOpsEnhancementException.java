package com.genx.base.cicd.assemblyline.extn.jenkins.exception;

public class DevOpsEnhancementException extends Exception {
	private static final long serialVersionUID = 1L;
	public DevOpsEnhancementException() {
		super();
	}

	public DevOpsEnhancementException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public DevOpsEnhancementException(String message, Throwable cause) {
		super(message, cause);
	}

	public DevOpsEnhancementException(String message) {
		super(message);
	}

	public DevOpsEnhancementException(Throwable cause) {
		super(cause);
	}

}