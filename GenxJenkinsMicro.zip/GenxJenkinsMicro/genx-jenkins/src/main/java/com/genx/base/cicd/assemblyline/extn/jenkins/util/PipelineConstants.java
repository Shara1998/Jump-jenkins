package com.genx.base.cicd.assemblyline.extn.jenkins.util;

public class PipelineConstants {
	
	private PipelineConstants() {
		
	}
	
	public static final String XMLCONFIGBATCHPIPELINE="xmlConfigBatchPipeline";
	public static final String PARAMETERDEFINITIONS="<parameterDefinitions>";
	public static final String SCRIPTSTARTTAG="<script>";
	public static final String SCRIPTENDTAG="</script>";
	public static final String JENKINSUSERNAME="jenkinsUserName";
	public static final String JENKINSPASS="jenkinsPassword";
	public static final String JENKINSURL="jenkinsUrl";
	public static final String NEWLINE="\n";
	public static final String STAGE="stage('Code Quality') {";
	public static final String STEPS="steps {";
	public static final String SCRIPTTAGREPLACE="<script/>";
	public static final String ENDBRACE="}";
	public static final String BUILDRESPONSE ="Building response is null";
	public static final String JOBDOESNOTEXIST ="Job does not exists";
	public static final String ESTIMATIONDUR ="estimatedDuration";
	public static final String TIMESTAMP ="timestamp";
	public static final String JENKINS_BUILD_NUMBER = "number";
	public static final String PROJECTNAME = "[project_name]";
	public static final String PROGRESS= "Progress";
	public static final String FAILURE = "failure";
	public static final String RESULT="result";
	public static final String HTTP_FAILIURE_STATUS_CODE = "failureStatusCode";
	public static final String JENKINS_BUILD_STATUS = "building";
	public static final String SONARSUFFIX = "_CodeQuality";

	public static final String STRINGPARAM="StringParam";
	public static final String GROOVYSCRIPT="GroovyScript";
	public static final String QUALITYGATESCRIPT="QualityGateScript";
	public static final  String GOOD="Good";
	public static final  String RISK="Risk";
	public static final  String NEED_TO_BE_RESOLVED="Need to be Resolved";
	public static final String XMLCONFIGMULTIBRANCH="xmlConfigBatchMultiBranchPipeline";
	

}
