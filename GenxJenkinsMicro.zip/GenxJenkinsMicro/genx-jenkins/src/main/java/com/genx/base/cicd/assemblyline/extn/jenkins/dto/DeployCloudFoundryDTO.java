package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.List;

public class DeployCloudFoundryDTO {
	
	private String cfUserName;
	private String cfPass;
	private String cfTarget;
	private String cfOrganization;
	private String cfSpace;
	private String cfServiceName;
	private String cfServiceType;
	private String cfServicePlan;
	private String cfReadConfig;
	private String cfManifestFile;
	private String cfApplicationName;
	private String cfMemory;
	private String cfHostName;
	private String cfInstances;
	private String cfTimeout;
	private String cfCustomBuildPack;
	private String cfCustomStack;
	private List<ServiceDetailsDTO> serviceDetails;
	private boolean otpDeployed;
	public String getCfMemory() {
		return cfMemory;
	}
	public void setCfMemory(String cfMemory) {
		this.cfMemory = cfMemory;
	}
	public String getCfUserName() {
		return cfUserName;
	}
	public void setCfUserName(String cfUserName) {
		this.cfUserName = cfUserName;
	}
	
	public String getCfTarget() {
		return cfTarget;
	}
	public void setCfTarget(String cfTarget) {
		this.cfTarget = cfTarget;
	}
	public String getCfOrganization() {
		return cfOrganization;
	}
	public void setCfOrganization(String cfOrganization) {
		this.cfOrganization = cfOrganization;
	}
	public String getCfSpace() {
		return cfSpace;
	}
	public void setCfSpace(String cfSpace) {
		this.cfSpace = cfSpace;
	}
	public String getCfServiceName() {
		return cfServiceName;
	}
	public void setCfServiceName(String cfServiceName) {
		this.cfServiceName = cfServiceName;
	}
	public String getCfServiceType() {
		return cfServiceType;
	}
	public void setCfServiceType(String cfServiceType) {
		this.cfServiceType = cfServiceType;
	}
	public String getCfServicePlan() {
		return cfServicePlan;
	}
	public void setCfServicePlan(String cfServicePlan) {
		this.cfServicePlan = cfServicePlan;
	}
	public String getCfReadConfig() {
		return cfReadConfig;
	}
	public void setCfReadConfig(String cfReadConfig) {
		this.cfReadConfig = cfReadConfig;
	}
	public String getCfManifestFile() {
		return cfManifestFile;
	}
	public void setCfManifestFile(String cfManifestFile) {
		this.cfManifestFile = cfManifestFile;
	}
	public String getCfApplicationName() {
		return cfApplicationName;
	}
	public void setCfApplicationName(String cfApplicationName) {
		this.cfApplicationName = cfApplicationName;
	}
	public String getCfHostName() {
		return cfHostName;
	}
	public void setCfHostName(String cfHostName) {
		this.cfHostName = cfHostName;
	}
	public String getCfInstances() {
		return cfInstances;
	}
	public void setCfInstances(String cfInstances) {
		this.cfInstances = cfInstances;
	}
	public String getCfTimeout() {
		return cfTimeout;
	}
	public void setCfTimeout(String cfTimeout) {
		this.cfTimeout = cfTimeout;
	}
	public String getCfCustomBuildPack() {
		return cfCustomBuildPack;
	}
	public void setCfCustomBuildPack(String cfCustomBuildPack) {
		this.cfCustomBuildPack = cfCustomBuildPack;
	}
	public String getCfCustomStack() {
		return cfCustomStack;
	}
	public void setCfCustomStack(String cfCustomStack) {
		this.cfCustomStack = cfCustomStack;
	}

	public List<ServiceDetailsDTO> getServiceDetails() {
		return serviceDetails;
	}
	public void setServiceDetails(List<ServiceDetailsDTO> serviceDetails) {
		this.serviceDetails = serviceDetails;
	}
	public boolean isOtpDeployed() {
		return otpDeployed;
	}
	public void setOtpDeployed(boolean otpDeployed) {
		this.otpDeployed = otpDeployed;
	}
	public String getCfPass() {
		return cfPass;
	}
	public void setCfPass(String cfPass) {
		this.cfPass = cfPass;
	}
	
	
}
