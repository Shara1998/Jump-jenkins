package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import static com.genx.base.cicd.assemblyline.extn.jenkins.util.PipelineConstants.PROJECTNAME;

import java.io.IOException;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.dto.JobDTO;

@Service
public  class JenkinsBuildStageUtil{
	
	private static final Logger logger = LoggerFactory.getLogger(JenkinsBuildStageUtil.class);
	
	@Autowired
	IJenkinsJobInformationRepository iJobInformationRepository;

	
	@Autowired
	EnvironmentServiceImplNew propertyUtil;

	@Autowired
	DevOpsWorkFlowUtilNew workFlowUtil;
	
	
	public Boolean buildIndividualStage(JobDTO jobDto,String stageName) {
		
		String jobName = jobDto.getJobName();		
		
		String jenkinsUserName=propertyUtil.getEnvProperties("jenkinsUserName");
		String jenkinsPass=propertyUtil.getEnvProperties("jenkinsPass");
				
		workFlowUtil.setJenkinsPassword(jenkinsPass);
		workFlowUtil.setJenkinsUsername(jenkinsUserName);
		JobInformationEntity jobInformationEntity = iJobInformationRepository.findByAppName(jobName);
		if (Objects.nonNull(jobInformationEntity)) {
			
			String jenkinsUrlBuildWithParameters =propertyUtil.getEnvProperties("jenkinsUrlbuildPipelineJob");
			jenkinsUrlBuildWithParameters = jenkinsUrlBuildWithParameters.replace(PROJECTNAME, jobName);
			jenkinsUrlBuildWithParameters = jenkinsUrlBuildWithParameters.replace("[stage]", stageName);
			logger.info("jenkinsUrlBuildWithParameters {}", jenkinsUrlBuildWithParameters);

			String statusString = null;
			
					
						try {
							
								statusString = workFlowUtil.postURL(jenkinsUrlBuildWithParameters);
							
						} catch ( IOException e) {
							logger.info(e.getMessage());
						}
					
			
			logger.info(" Status : {}", statusString);
			
	}
		return true;
	}


}
