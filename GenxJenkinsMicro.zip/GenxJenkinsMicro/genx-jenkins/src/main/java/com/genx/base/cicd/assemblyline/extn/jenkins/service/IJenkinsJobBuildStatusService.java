package com.genx.base.cicd.assemblyline.extn.jenkins.service;

import java.io.IOException;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;

public interface IJenkinsJobBuildStatusService {

	public void getLatestCodeQualityBuildStatus(String codeQualityJobName, JobInformationEntity jobInformationEntity,
			DevOpsWorkFlowUtilNew workFlowUtil) throws IOException, InterruptedException;

	public void getLatestYascaBuildStatus(String yascaJobName, JobInformationEntity jobInformationEntity,
			DevOpsWorkFlowUtilNew workFlowUtil) throws IOException, InterruptedException;
	
	public void getLatestDeployBuildStatus(String deployJobName, JobInformationEntity jobInformationEntity,
			DevOpsWorkFlowUtilNew workFlowUtil) throws IOException, InterruptedException;
	
	public void getLatestRegressionBuildStatus(String deployJobName, JobInformationEntity jobInformationEntity,
			DevOpsWorkFlowUtilNew workFlowUtil) throws IOException, InterruptedException;
	
	public void getLatestPerformanceBuildStatus(String performanceJobName, JobInformationEntity jobInformationEntity,
			DevOpsWorkFlowUtilNew workFlowUtil) throws IOException, InterruptedException; 
}
