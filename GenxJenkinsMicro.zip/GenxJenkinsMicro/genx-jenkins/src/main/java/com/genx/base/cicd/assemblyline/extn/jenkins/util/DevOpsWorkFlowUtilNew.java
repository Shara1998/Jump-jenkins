package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;

@SuppressWarnings("deprecation")
@Component
public class DevOpsWorkFlowUtilNew {

	@Autowired
	EnvironmentServiceImplNew propertyUtil;
	
	private static final byte[] BUFFER = new byte[8192];


	private static org.slf4j.Logger log = LoggerFactory.getLogger(DevOpsWorkFlowUtilNew.class);

	private String jenkinsUsername;
	private static String jenkinsPassword;

	private static final String APPLICATIONXML = "application/xml";
	private static final String CONTENTTYPE = "Content-type";
	private static final String ERROR = "error";
	private static final String USASCII = "US-ASCII";
	private static final String HTTP_FAILIURE_STATUS_CODE = "failureStatusCode";

	private static final String APPJSON = "application/json";

	public static final String JENKINSNEW = "52.214.113.246";
	public static final String JENKINSNEWUSER = "admin";
	public static final String JENKINSNEWPASS = "automation@2016";

	public DevOpsWorkFlowUtilNew(String jenkinsUsername, String jenkinPassword) {
		super();
		this.jenkinsUsername = jenkinsUsername;
		DevOpsWorkFlowUtilNew.jenkinsPassword = jenkinPassword;
	}

	public String getJenkinsUsername() {
		return jenkinsUsername;
	}

	public void setJenkinsUsername(String jenkinsUsername) {
		this.jenkinsUsername = jenkinsUsername;
	}

	public String getJenkinsPassword() {
		return jenkinsPassword;
	}

	public void setJenkinsPassword(String jenkinsPassword) {
		DevOpsWorkFlowUtilNew.jenkinsPassword = jenkinsPassword;
	}

	private static String convertDocumentToString(Document doc) {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		StringWriter writer = new StringWriter();
		try {
			transformer = tf.newTransformer();

			transformer.transform(new DOMSource(doc), new StreamResult(writer));

			return writer.getBuffer().toString();
		} catch (TransformerException e) {
			log.info("error while convertDocumentToString");
			log.error(e.getMessage(), e);
			// return writer.getBuffer().toString(); // log.error(e.toString(), e);
		}

		return writer.getBuffer().toString();
	}

	// old jenkins create method
//	  @SuppressWarnings("resource") public boolean postXML(String jenkinsUrl,
//	  Document doc) throws FileNotFoundException {
//	  
//	  boolean status = false; String docString = null; String username =
//	  getJenkinsUsername(); String password = getJenkinsPassword();
//	  
//	  try { docString = convertDocumentToString(doc); String strURL = jenkinsUrl;
//	  DefaultHttpClient http = new DefaultHttpClient(); log.info("strUrl is :{}" ,
//	  strURL);
//	  
//	  HttpPost post = new HttpPost(strURL); UsernamePasswordCredentials creds = new
//	  UsernamePasswordCredentials(username, password);
//	  post.addHeader(BasicScheme.authenticate(creds, USASCII, false)); StringEntity
//	  entity = new StringEntity(docString); entity.setContentType("text/xml");
//	  post.setEntity(entity); org.apache.http.HttpResponse response =
//	  http.execute(post); log.info("response {} ",response); int result =
//	  response.getStatusLine().getStatusCode(); if (result == 200) { status = true;
//	  }
//	  
//	  } catch (Exception e) { log.error(e.toString(),e); } return status;
//	  
//	  }

	@SuppressWarnings("resource")
	public boolean postXML(String jenkinsUrl, String docString) {
		boolean status = false;
System.out.println("docString::"+docString);
		String username = "automation";
		String password = "automation@2016";
		try {

			String strURL = jenkinsUrl;
			DefaultHttpClient http = new DefaultHttpClient();
			log.info("strUrl is :{}", strURL);
			HttpPost post = new HttpPost(strURL);
			UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
			post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
			StringEntity entity = new StringEntity(docString);
			entity.setContentType("text/xml");
			post.setEntity(entity);
			org.apache.http.HttpResponse response = http.execute(post);
			log.info("response {} ", response);
			int result = response.getStatusLine().getStatusCode();
			if (result == 200) {
				status = true;
			}
		} catch (Exception e) {
			log.error(e.toString(), e);
		}
		return status;

	} // old jenkins build method

	public String postURL(String jenkinsUrl) throws IOException {
		log.info("url in post util " + jenkinsUrl);
		/*
		 * String username = getJenkinsUsername(); String password = getJenkinsPass();
		 */
		/*
		 * String username = propertyUtil.getEnvProperties("geJenkinsUsername"); String
		 * pass = propertyUtil.getEnvProperties("geJenkinsPass");
		 */
		String username = "";
		String pass = null;
		if (jenkinsUrl.contains("actlabinnovationjenkinsdev")) {
			username = propertyUtil.getEnvProperties("jenkinsUserName");
			pass = propertyUtil.getEnvProperties("jenkinsPass");
		}
		if (jenkinsUrl.contains("actlabinnovationsonardev")) {
			username = "genx";
			pass = "genx@123";
		}

		boolean basicAuth = true;
		if (jenkinsUrl.contains("https://genx-jenkins.power.cg.com/sonar")) {
			basicAuth = false;
		}

		try {

			HttpURLConnection httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			relaxHostChecking(httpClient);
			String encoded = Base64.getEncoder()
					.encodeToString((username + ":" + pass).getBytes(StandardCharsets.UTF_8)); // Java
			// add reuqest header
			httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty("Content-Type", "application/xml");
			httpClient.setRequestProperty("Accept", "application/xml");
			// httpClient.setRequestProperty("Authorization", "Basic " + encoded);

			if (basicAuth) {
				httpClient.setRequestProperty("Authorization", "Basic " + encoded);
			}
			httpClient.setDoOutput(true);

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
			log.info("Response Code : " + responseCode);
			try (BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()))) {
				String line;

				StringBuilder response = new StringBuilder();
				while ((line = in.readLine()) != null) {
					response.append(line);
				}
				return response.toString();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				log.info("error  while positng Url");
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.info("error  while positng Url");
		}
		return ERROR;
	}

	public JSONObject postURLJson(String jenkinsUrl) throws IOException {
		JSONObject newError = new JSONObject();

		/*
		 * String username = propertyUtil.getEnvProperties("jenkinsAdminUserName");
		 * String password = propertyUtil.getEnvProperties("jenkinsAdminPassword");
		 */
		String username = propertyUtil.getUserOnEnv("sonar");
		String pass = propertyUtil.getPwdOnEnv("sonar");
		log.error("username---{}", username);

		boolean basicAuth = true;
		if (jenkinsUrl.contains("https://genx-jenkins.power.cg.com/sonar")) {
			basicAuth = false;
		}

		try {

			HttpURLConnection httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			relaxHostChecking(httpClient);
			String encoded = Base64.getEncoder()
					.encodeToString((username + ":" + pass).getBytes(StandardCharsets.UTF_8)); // Java
			// add reuqest header
			httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty(CONTENTTYPE, APPJSON);
			httpClient.setRequestProperty("Accept", "application/json");
			// httpClient.setRequestProperty("Authorization", "Basic " + encoded);
			if (basicAuth) {
				httpClient.setRequestProperty("Authorization", "Basic " + encoded);
			}

			httpClient.setDoOutput(true);

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
			log.info("Response Code : " + responseCode);
			try (BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()))) {
				String line;
				StringBuilder response = new StringBuilder();
				while ((line = String.valueOf(in.read())) != null) {
					response.append(line);
				}
				JSONParser parser = new JSONParser();
				JSONObject json;
				try {
					json = (JSONObject) parser.parse(response.toString());
					return json;

				} catch (ParseException e) {
					log.error(e.getMessage(), e);
					log.info("error  while postURLJson");
					// e.printStackTrace();
				}

			} catch (Exception e) {
				log.error(e.getMessage(), e);
				log.info("error  while postURLJson");
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.info("error  while postURLJson");
		}

		return newError;
	}

	@SuppressWarnings("resource")
	public JSONObject postURLJsonBuild(String jenkinsUrl) throws IOException {

		JSONObject newError = new JSONObject();
		String username = propertyUtil.getEnvProperties("geJenkinsUsername");
		String password = propertyUtil.getEnvProperties("geJenkinsPassword");
		try {

			HttpURLConnection httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			relaxHostChecking(httpClient);
			String encoded = Base64.getEncoder()
					.encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8)); // Java
			// add reuqest header
			httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty(CONTENTTYPE, APPJSON);
			httpClient.setRequestProperty("Accept", "application/json");
			httpClient.setRequestProperty("Authorization", "Basic " + encoded);

			httpClient.setDoOutput(true);

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
			log.info("Response Code : " + responseCode);
			try (BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()))) {
				String line;
				StringBuilder response = new StringBuilder();
				while ((line = String.valueOf(in.read())) != null) {
					response.append(line);
				}
				JSONParser parser = new JSONParser();
				JSONObject json;
				try {
					json = (JSONObject) parser.parse(response.toString());
					return json;

				} catch (ParseException e) {
					log.error(e.getMessage(), e);
					log.info("error  while postURLJsonBuild");
					// e.printStackTrace();
				}

			} catch (Exception e) {
				log.error(e.getMessage(), e);
				log.info("error  while postURLJsonBuild");
			}
			return newError;

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.info("error  while postURLJsonBuild");
			// log.error(e.toString(), e);
		}

		return newError;
	}

	@SuppressWarnings({ "resource", "unchecked" })
	public JSONObject postBuildRequest(String jenkinsUrl) throws IOException {
		JSONObject newError = new JSONObject();

		try {
			String username = propertyUtil.getEnvProperties("geJenkinsUsername");
			String password = propertyUtil.getEnvProperties("geJenkinsPassword");
			HttpURLConnection httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			relaxHostChecking(httpClient);
			String encoded = Base64.getEncoder()
					.encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8)); // Java
			// add reuqest header
			httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty(CONTENTTYPE, APPJSON);
			httpClient.setRequestProperty("Accept", "application/json");
			httpClient.setRequestProperty("Authorization", "Basic " + encoded);

			httpClient.setDoOutput(true);

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
			log.info("Response Code : " + responseCode);
			if (responseCode == 200 || responseCode == 201) {

				try (BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()))) {
					String line;
					StringBuilder response = new StringBuilder();
					while ((line = String.valueOf(in.read())) != null) {
						response.append(line);
					}
					JSONParser parser = new JSONParser();
					JSONObject json;

					json = (JSONObject) parser.parse(response.toString());
					return json;

				} catch (Exception e) {
					log.info("error  while postBuildRequest");
					log.error(e.getMessage(), e);
				}
			} else if (responseCode == 404) { // Skip 404 error
				return newError;
			} else {
				newError.put(HTTP_FAILIURE_STATUS_CODE, responseCode);
				return newError;
			}

		} catch (Exception e) {
			log.info("error  while postBuildRequest");
			log.error(e.getMessage(), e);
		}
		return null;
	}

	/*
	 * @SuppressWarnings("resource") public JSONObject postURLJson(String
	 * jenkinsUrl) throws IOException { JSONObject newError = new JSONObject();
	 * 
	 * String username = propertyUtil.getEnvProperties("jenkinsAdminUserName");
	 * String password = propertyUtil.getEnvProperties("jenkinsAdminPassword");
	 * 
	 * String strURL = jenkinsUrl; DefaultHttpClient http = new DefaultHttpClient();
	 * HttpPost post = new HttpPost(strURL); UsernamePasswordCredentials creds = new
	 * UsernamePasswordCredentials(username, password);
	 * post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPJSON);
	 * 
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * 
	 * //TODO 504,401 errors needs to be handled.
	 * 
	 * int result = response.getStatusLine().getStatusCode(); if (result == 200 ||
	 * result == 201) { BufferedReader rd = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
	 * new StringBuffer(); String line = ""; while ((line=String.valueOf(in.read()))
	 * != null) { content.append(line); }
	 * 
	 * JSONParser parser = new JSONParser(); JSONObject json; try { json =
	 * (JSONObject) parser.parse(content.toString()); return json;
	 * 
	 * } catch (ParseException e) { e.printStackTrace(); } } else {
	 * 
	 * return newError; }
	 * 
	 * 
	 * return newError; }
	 * 
	 */
	/*
	 * @SuppressWarnings("resource") public JSONObject
	 * postURLJsonBuildFargate(String jenkinsUrl) throws IOException {
	 * 
	 * JSONObject newError = new JSONObject(); String username =
	 * propertyUtil.getEnvProperties("jenkinsUserName"); String password =
	 * propertyUtil.getEnvProperties("jenkinsPassword"); try { String strURL =
	 * jenkinsUrl; DefaultHttpClient http = new DefaultHttpClient(); HttpPost post =
	 * new HttpPost(strURL); UsernamePasswordCredentials creds = new
	 * UsernamePasswordCredentials(username, password);
	 * post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPJSON);
	 * 
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * 
	 * log.info("postURLJsonBuild  method {}", response);
	 * 
	 * int result = response.getStatusLine().getStatusCode(); JSONParser parser =
	 * new JSONParser(); JSONObject json; if (result == 200 || result == 201) {
	 * BufferedReader rd = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
	 * new StringBuffer(); String line = ""; while ((line=String.valueOf(in.read()))
	 * != null) { content.append(line); }
	 * 
	 * json = (JSONObject) parser.parse(content.toString());
	 * 
	 * return json;
	 * 
	 * } else {
	 * 
	 * return newError; }
	 * 
	 * } catch (Exception e) { log.error(e.toString(), e); }
	 * 
	 * return newError; }
	 */
	/*
	 * @SuppressWarnings({ "resource", "unchecked" }) public JSONObject
	 * postBuildRequest(String jenkinsUrl) throws IOException { JSONObject newError
	 * = new JSONObject();; try { String username =
	 * propertyUtil.getEnvProperties("jenkinsUserName"); String password =
	 * propertyUtil.getEnvProperties("jenkinsPassword");
	 * 
	 * String strURL = jenkinsUrl; DefaultHttpClient http = new DefaultHttpClient();
	 * HttpPost post = new HttpPost(strURL); UsernamePasswordCredentials creds = new
	 * UsernamePasswordCredentials(username, password);
	 * post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPJSON);
	 * 
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * 
	 * log.info("postBuildRequest response :{} " , response);
	 * 
	 * int result = response.getStatusLine().getStatusCode(); if (result == 200 ||
	 * result == 201) { BufferedReader rd = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
	 * new StringBuffer(); String line = ""; while ((line=String.valueOf(in.read()))
	 * != null) { content.append(line); }
	 * 
	 * JSONParser parser = new JSONParser(); JSONObject json;
	 * 
	 * json = (JSONObject) parser.parse(content.toString()); return json;
	 * 
	 * } else if(result == 404) { //Skip 404 error return newError; } else {
	 * newError.put(HTTP_FAILIURE_STATUS_CODE, result); return newError; }
	 * 
	 * } catch (Exception e) { log.error(e.getMessage(),e); }
	 * 
	 * return null; }
	 * 
	 */
	@SuppressWarnings("resource")
	public BufferedReader postURL3(String jenkinsUrl) throws IOException {

		String username = getJenkinsUsername();
		String password = getJenkinsPassword();
		BufferedReader rd = null;

		try {

			String strURL = jenkinsUrl;
			DefaultHttpClient http = new DefaultHttpClient();
			HttpPost post = new HttpPost(strURL);
			UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
			post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
			post.addHeader(CONTENTTYPE, APPLICATIONXML);
			org.apache.http.HttpResponse response = http.execute(post);

			int result = response.getStatusLine().getStatusCode();
			if (result == 200 || result == 201) {
				rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

				File file = new File("/Users/nt831459/Desktop/csvTest.txt");

				try (BufferedWriter output = new BufferedWriter(new FileWriter(file))) {

					while ((String.valueOf(rd.read())) != null) {
						output.write(rd.read());
					}
				} catch (IOException e) {
					log.info("error  while postURL3");
					log.error(e.getMessage(), e);
					// log.error(e.toString(), e);

				}

				return rd;

			}

		} catch (Exception e) {
			log.info("error  while postURL3");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);
		}
		return rd;

	}

	public boolean postXML2(String jenkinsUrl, String xmlConfig) throws FileNotFoundException {
		boolean status = false;
		String strURL = jenkinsUrl;

		String strXMLFilename = xmlConfig;
		File input = new File(strXMLFilename);

		PostMethod post = new PostMethod(strURL);

		post.setRequestEntity(new InputStreamRequestEntity(new FileInputStream(input), input.length()));

		post.setRequestHeader(CONTENTTYPE, "application/xml; charset=ISO-8859-1");

		HttpClient httpclient = new HttpClient();

		try {

			int result = httpclient.executeMethod(post);

			if (result == 200) {
				status = true;
			}

		} catch (Exception e) {
			log.info("error  while postXML2");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);
		} finally {

			post.releaseConnection();
		}
		return status;
	}

	public String postURL2(String jenkinsUrl) throws IOException {

		String strURL = jenkinsUrl;

		PostMethod post = new PostMethod(strURL);

		post.setRequestHeader(CONTENTTYPE, "application/xml; charset=ISO-8859-1");

		HttpClient httpclient = new HttpClient();
		int result = 0;

		try {

			result = httpclient.executeMethod(post);

		} catch (Exception e) {
			log.info("error  while postURL2");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);
		} finally {

			post.releaseConnection();
		}

		if (result == 200 || result == 201) {

			return post.getResponseBodyAsString();

		} else {
			return ERROR;
		}
	}

	@SuppressWarnings("resource")
	public boolean postJenkinsUrl(String jenkinsScriptUrl) {

		boolean status = false;
		String username = getJenkinsUsername();
		String password = getJenkinsPassword();

		try {
			String strURL = jenkinsScriptUrl;
			DefaultHttpClient http = new DefaultHttpClient();
			HttpPost post = new HttpPost(strURL);
			UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
			post.addHeader(BasicScheme.authenticate(creds, USASCII, false));

			org.apache.http.HttpResponse response = http.execute(post);

			int result = response.getStatusLine().getStatusCode();
			if (result == 200) {
				status = true;
			}

		} catch (Exception e) {
			log.info("error  while postJenkinsUrl");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);
		}
		return status;

	}

	public String impersonator() throws IOException {
		BufferedReader br = null;
		FileReader fr = null;
		String sCurrentLine = null;
		String empid = "";
		String impersonate = "";
		try {

			fr = new FileReader("/home/automation/tomcat_webapplications/devops/config/impersonator.properties");
			br = new BufferedReader(fr);

			int count = 0;

			while ((sCurrentLine = String.valueOf(br.read())) != null) {

				if (count == 2) {
					break;
				}
				if (count == 1) {
					impersonate = empid;
				}

				String words[] = sCurrentLine.split("=");
				for (int i = 0; i < words.length; i++) {
					empid = words[1];
				}

				count++;
			}

		} catch (IOException e) {
			log.info("error  while impersonator method");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);
		}

		return impersonate;
	}

	@SuppressWarnings("resource")
	public YascaInformationEntity postURL5(String jenkinsUrl, YascaInformationEntity yenti) throws IOException {

		String username = getJenkinsUsername();
		String password = getJenkinsPassword();

		try {

			HttpURLConnection httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			relaxHostChecking(httpClient);
			String encoded = Base64.getEncoder()
					.encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8)); // Java
			// add reuqest header
			httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty(CONTENTTYPE, APPJSON);
			httpClient.setRequestProperty("Accept", "application/json");
			httpClient.setRequestProperty("Authorization", "Basic " + encoded);

			httpClient.setDoOutput(true);

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
			log.info("Response Code : " + responseCode);

			if (responseCode == 200 || responseCode == 201)
				postURL5ConditionCoverity(yenti, httpClient);

		} catch (Exception e) {
			log.info("error  while postURL5 method");
			log.error(e.getMessage(), e);
			// log.error(e.toString(), e);

		}
		return yenti;
	}

	private void postURL5ConditionCoverity(YascaInformationEntity yenti, HttpURLConnection response)
			throws IOException {
		int warning1 = 0;
		int high1 = 0;
		int low1 = 0;
		int critical1 = 0;
		int informational1 = 0;

		int incrementedCritical = 0;
		int incrementedHigh = 0;
		int incrementedLow = 0;
		int incrementedWarning = 0;
		int incrementedInformational = 0;

		final String critical = "Medium";
		final String high = "High";
		final String low = "Low";
		final String warning = "Warning";
		final String informational = "Informational";

		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getInputStream()));

		String line = "";

		String lineToString;
		String string;
		String resultString;
		while ((line = String.valueOf(rd.read())) != null) {

			lineToString = line;
			string = lineToString.replace('"', ',');
			resultString = string.replace(",", " ");

			critical1 = StringUtils.countMatches(resultString, critical);
			if (critical1 == 1) {
				incrementedCritical++;
			}

			high1 = StringUtils.countMatches(resultString, high);
			if (high1 == 1) {
				incrementedHigh++;
			}
			low1 = StringUtils.countMatches(resultString, low);
			if (low1 == 1) {
				incrementedLow++;
			}
			warning1 = StringUtils.countMatches(resultString, warning);
			if (warning1 == 1) {
				incrementedWarning++;
			}
			informational1 = StringUtils.countMatches(resultString, informational);
			if (informational1 == 1) {
				incrementedInformational++;
			}

		}
		log.info("incrementedInformational ::" + incrementedInformational);
		String warningStr = Integer.toString(incrementedWarning);
		log.info("warningStr ::" + warningStr);
		yenti.setSeverityMedium(incrementedCritical);
		yenti.setSeverityHigh(incrementedHigh);
		yenti.setSeverityLow(incrementedLow);

	}

	/*
	 * private void postURL5Yasca(YascaInformationEntity yenti,
	 * org.apache.http.HttpResponse response) throws IOException {
	 * 
	 * int result = response.getStatusLine().getStatusCode(); if (result == 200 ||
	 * result == 201) {
	 * 
	 * postURL5Condition(yenti, response);
	 * 
	 * } }
	 */

	private void postURL5Condition(YascaInformationEntity yenti, BufferedReader rd) throws IOException {
		int warning1 = 0;
		int high1 = 0;
		int low1 = 0;
		int critical1 = 0;
		int informational1 = 0;

		int incrementedCritical = 0;
		int incrementedHigh = 0;
		int incrementedLow = 0;
		int incrementedWarning = 0;
		int incrementedInformational = 0;

		final String critical = "Critical";
		final String high = "High";
		final String low = "Low";
		final String warning = "Warning";
		final String informational = "Informational";

		// BufferedReader rd = new BufferedReader(new
		// InputStreamReader(response.getEntity().getContent()));

		String line = "";

		String lineToString;
		String string;
		String resultString;
		while ((line = String.valueOf(rd.read())) != null) {

			lineToString = line;
			string = lineToString.replace('"', ',');
			resultString = string.replace(",", " ");

			critical1 = StringUtils.countMatches(resultString, critical);
			if (critical1 == 1) {
				incrementedCritical++;
			}

			high1 = StringUtils.countMatches(resultString, high);
			if (high1 == 1) {
				incrementedHigh++;
			}
			low1 = StringUtils.countMatches(resultString, low);
			if (low1 == 1) {
				incrementedLow++;
			}
			warning1 = StringUtils.countMatches(resultString, warning);
			if (warning1 == 1) {
				incrementedWarning++;
			}
			informational1 = StringUtils.countMatches(resultString, informational);
			if (informational1 == 1) {
				incrementedInformational++;
			}

		}

		String warningStr = Integer.toString(incrementedWarning);
		yenti.setSeverityCritical(incrementedCritical);
		yenti.setSeverityHigh(incrementedHigh);
		yenti.setSeverityWarnings(warningStr);
		yenti.setSeverityLow(incrementedLow);
		yenti.setSeverityInformational(incrementedInformational);
	}

	/*
	 * @SuppressWarnings("resource") public boolean postXML(String jenkinsUrl,
	 * Document doc) throws FileNotFoundException { boolean status = false; String
	 * docString = null; String username = getJenkinsUsername(); String password =
	 * getJenkinsPassword();
	 * 
	 * try { docString = convertDocumentToString(doc); String strURL = jenkinsUrl;
	 * DefaultHttpClient http = new DefaultHttpClient(); log.info("strUrl is :{}",
	 * strURL); HttpPost post = new HttpPost(strURL); UsernamePasswordCredentials
	 * creds = new UsernamePasswordCredentials(username, password); String token="";
	 * 
	 * JSONObject obj=getCrumbToken(); token = (String) obj.get("token");
	 * System.out.println("token.... crumb "+token); post.addHeader("Jenkins-Crumb",
	 * token); post.addHeader("Cookie",(String) obj.get("cookie"));
	 * 
	 * post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPLICATIONXML); StringEntity entity = new
	 * StringEntity(docString); System.out.println("strung " + entity.toString());
	 * entity.setContentType("text/xml"); post.setEntity(entity);
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * log.info("response {} ", response); int result =
	 * response.getStatusLine().getStatusCode(); if (result == 200) { status = true;
	 * }
	 * 
	 * } catch (Exception e) { log.error(e.toString(), e); } return status; }
	 */
	/*
	 * @SuppressWarnings("resource") public String postURLBlueOcen(String
	 * jenkinsUrl) throws IOException {
	 * 
	 * //String username = getJenkinsUsername(); //String password =
	 * getJenkinsPassword();
	 * 
	 * String username = propertyUtil.getEnvProperties("blueOceanJenkinsUsername");
	 * String password = propertyUtil.getEnvProperties("blueOceanJenkinsPassword");
	 * 
	 * 
	 * try { String strURL = jenkinsUrl; DefaultHttpClient http = new
	 * DefaultHttpClient(); HttpPost post = new HttpPost(strURL); String token="";
	 * 
	 * JSONObject obj=getCrumbToken(); token = (String) obj.get("token");
	 * System.out.println("token.... crumb "+token); post.addHeader("Jenkins-Crumb",
	 * token); post.addHeader("Cookie",(String) obj.get("cookie"));
	 * 
	 * UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username,
	 * password); post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPLICATIONXML);
	 * 
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * log.info("postURL  response :{} " , response);
	 * 
	 * int result = response.getStatusLine().getStatusCode(); if (result == 200 ||
	 * result == 201) { BufferedReader rd = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
	 * new StringBuffer(); String line = "";
	 * 
	 * while ((line=String.valueOf(in.read())) != null) {
	 * 
	 * content.append(line); }
	 * 
	 * return content.toString();
	 * 
	 * } else {
	 * 
	 * return "FAILURE"; }
	 * 
	 * } catch (Exception e) { log.error(e.toString(),e); }
	 * 
	 * return ERROR; }
	 * 
	 * 
	 */ /*
		 * @SuppressWarnings("resource") public JSONObject postURLJsonBuild(String
		 * jenkinsUrl) throws IOException {
		 * 
		 * JSONObject newError = new JSONObject(); String username =
		 * propertyUtil.getEnvProperties("blueOceanJenkinsUsername"); String password =
		 * propertyUtil.getEnvProperties("blueOceanJenkinsPassword"); try { String
		 * strURL = jenkinsUrl; DefaultHttpClient http = new DefaultHttpClient();
		 * HttpPost post = new HttpPost(strURL);
		 * 
		 * String token="";
		 * 
		 * JSONObject obj=getCrumbToken(); token = (String) obj.get("token");
		 * System.out.println("token.... crumb "+token); post.addHeader("Jenkins-Crumb",
		 * token); post.addHeader("Cookie",(String) obj.get("cookie"));
		 * UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username,
		 * password); post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
		 * post.addHeader(CONTENTTYPE, APPJSON);
		 * 
		 * org.apache.http.HttpResponse response = http.execute(post);
		 * 
		 * log.info("postURLJsonBuild  method {}" , response);
		 * 
		 * int result = response.getStatusLine().getStatusCode(); JSONParser parser =
		 * new JSONParser(); JSONObject json ; if (result == 200 || result == 201) {
		 * BufferedReader rd = new BufferedReader(new
		 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
		 * new StringBuffer(); String line = ""; while ((line=String.valueOf(in.read()))
		 * != null) { content.append(line); }
		 * 
		 * json = (JSONObject) parser.parse(content.toString());
		 * 
		 * 
		 * return json;
		 * 
		 * } else {
		 * 
		 * return newError; }
		 * 
		 * } catch (Exception e) { log.error(e.toString(),e); }
		 * 
		 * 
		 * return newError; }
		 */
	/*
	 * @SuppressWarnings({ "resource", "unchecked" }) public JSONObject
	 * postBuildRequest(String jenkinsUrl) throws IOException { JSONObject newError
	 * = new JSONObject();; try { String username =
	 * propertyUtil.getEnvProperties("blueOceanJenkinsUsername"); String password =
	 * propertyUtil.getEnvProperties("blueOceanJenkinsPassword");
	 * 
	 * String strURL = jenkinsUrl; DefaultHttpClient http = new DefaultHttpClient();
	 * HttpPost post = new HttpPost(strURL); String token="";
	 * 
	 * JSONObject obj=getCrumbToken(); token = (String) obj.get("token");
	 * System.out.println("token.... crumb "+token); post.addHeader("Jenkins-Crumb",
	 * token); post.addHeader("Cookie",(String) obj.get("cookie"));
	 * 
	 * UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username,
	 * password); post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
	 * post.addHeader(CONTENTTYPE, APPJSON);
	 * 
	 * org.apache.http.HttpResponse response = http.execute(post);
	 * 
	 * log.info("postBuildRequest response :{} " , response);
	 * 
	 * int result = response.getStatusLine().getStatusCode(); if (result == 200 ||
	 * result == 201) { BufferedReader rd = new BufferedReader(new
	 * InputStreamReader(response.getEntity().getContent())); StringBuffer content =
	 * new StringBuffer(); String line = ""; while ((line=String.valueOf(in.read()))
	 * != null) { content.append(line); }
	 * 
	 * JSONParser parser = new JSONParser(); JSONObject json;
	 * 
	 * json = (JSONObject) parser.parse(content.toString()); return json;
	 * 
	 * } else if(result == 404) { //Skip 404 error return newError; } else {
	 * newError.put(HTTP_FAILIURE_STATUS_CODE, result); return newError; }
	 * 
	 * } catch (Exception e) { log.error(e.getMessage(),e); }
	 * 
	 * return null; }
	 * 
	 */

	@SuppressWarnings("resource")
	public JSONObject getCrumbToken() throws IOException {
		String token = "";
		String strURL = propertyUtil.getEnvProperties("blueOceanCrumb");
		DefaultHttpClient http = new DefaultHttpClient();
		HttpGet get = new HttpGet(strURL);
		String username = propertyUtil.getEnvProperties("blueOceanJenkinsUsername");
		String password = propertyUtil.getEnvProperties("blueOceanJenkinsPassword");
		UsernamePasswordCredentials creds = new UsernamePasswordCredentials(username, password);
		get.addHeader(BasicScheme.authenticate(creds, USASCII, false));

		org.apache.http.HttpResponse response = http.execute(get);

		int result = response.getStatusLine().getStatusCode();
		// String cookie = response.getFirstHeader("Cookie").getValue();
		log.info("ressss " + response.getAllHeaders().toString());
		Header[] headers = response.getAllHeaders();
		for (int i = 0; i < headers.length; i++) {
			log.info("header " + headers[i]);
		}
		log.info("cookie " + response.getFirstHeader("Set-Cookie").getValue());
		String cookie = response.getFirstHeader("Set-Cookie").getValue();
		if (result == 200 || result == 201) {
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuffer content = new StringBuffer();
			String line = "";
			while ((line = String.valueOf(rd.read())) != null) {
				content.append(line);
			}

			JSONParser parser = new JSONParser();
			JSONObject json;
			try {
				json = (JSONObject) parser.parse(content.toString());
				log.info("json token " + json);
				token = (String) json.get("crumb");

			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		JSONObject obj = new JSONObject();
		obj.put("token", token);
		obj.put("cookie", cookie);
		return obj;

	}

	private static final TrustingHostnameVerifier TRUSTING_HOSTNAME_VERIFIER = new TrustingHostnameVerifier();
	private static SSLSocketFactory factory;

	/**
	 * Call this with any HttpURLConnection, and it will modify the trust settings
	 * if it is an HTTPS connection.
	 */
	public static void relaxHostChecking(HttpURLConnection conn)
			throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

		if (conn instanceof HttpsURLConnection) {
			HttpsURLConnection httpsConnection = (HttpsURLConnection) conn;
			SSLSocketFactory factory = prepFactory(httpsConnection);
			httpsConnection.setSSLSocketFactory(factory);
			httpsConnection.setHostnameVerifier(TRUSTING_HOSTNAME_VERIFIER);
		}
	}

	static synchronized SSLSocketFactory prepFactory(HttpsURLConnection httpsConnection)
			throws NoSuchAlgorithmException, KeyManagementException {

		if (factory == null) {
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { new AlwaysTrustManager() }, null);
			factory = ctx.getSocketFactory();
		}
		return factory;
	}

	private static final class TrustingHostnameVerifier implements HostnameVerifier {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}

	private static class AlwaysTrustManager implements X509TrustManager {
		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}

	public DevOpsWorkFlowUtilNew() {
		super();
	}

	public CloseableHttpResponse postGit(String url, String json) throws IOException {
		CloseableHttpResponse response = null;
		try {
			String gitUsername = propertyUtil.getEnvProperties("geGithubUsername");
			String gitPass = propertyUtil.getEnvProperties("geGithubPassword");
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpPost post = new HttpPost(url);
			UsernamePasswordCredentials creds = new UsernamePasswordCredentials(gitUsername, gitPass);
			post.addHeader(BasicScheme.authenticate(creds, USASCII, false));
			StringEntity entity = new StringEntity(json);
			entity.setContentType("application/json");
			post.setEntity(entity);
			response = httpclient.execute(post);
			int result = response.getStatusLine().getStatusCode();
			response.getEntity().getContent();
			log.info("result " + result);
			log.info("response " + response);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return response;
	}

	public Boolean updatePipelineconfig(String updateXmlConfig,String jobName) throws IOException {   
		
		boolean status = false;
		try {
			String editUrl = propertyUtil.getEnvProperties("jenkinsUrlforEdit");
			editUrl = editUrl.replace("[project_name]", jobName);
			
			String user = propertyUtil.getEnvProperties("jenkinsUserName");
			String pass = propertyUtil.getEnvProperties("jenkinsPass");
	     
	      String authStr = user + ":" + pass;
	      String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));
	     // Path configPath = Paths.get(updateXmlConfig); // A path to the modified project configuration file.
	      HttpURLConnection httpClient = (HttpURLConnection) new URL(editUrl).openConnection();
			relaxHostChecking(httpClient);
	      httpClient.setRequestMethod("POST");
			httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
			httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			httpClient.setRequestProperty("Content-Type", "application/xml");
			httpClient.setRequestProperty("Accept", "application/xml");
			httpClient.setRequestProperty("Authorization", "Basic " + encoding);

			httpClient.setDoOutput(true);
			try (DataOutputStream wr = new DataOutputStream(httpClient.getOutputStream())) {
				wr.writeBytes(updateXmlConfig);
				wr.flush();
			}

			int responseCode = httpClient.getResponseCode();
			log.info("\nSending 'POST' request to URL : " + editUrl);
			log.info("Post parameters : " + updateXmlConfig);
			log.info("Response Code : " + responseCode);
			if (responseCode == 200) {
				status = true;
			}
			try (BufferedReader in = new BufferedReader(
					new InputStreamReader(httpClient.getInputStream()))) {
				String line;
				StringBuilder response = new StringBuilder();
				while ((line = in.readLine()) != null) {
					response.append(line);
				}
				log.info(response.toString());
			}

			catch (Exception e) {
				status = false;
				log.info("error while posting xml");
				log.error(e.getMessage(), e);
			}

		} catch (Exception e) {
			status = false;
			log.info("error  while positng xml");
			log.error(e.getMessage(), e);
		}

		return status;

	}

	public List<String> fetchPipelineConfig(String jobName) throws IOException {
		List<String> response = new ArrayList<>();
		String editUrl = propertyUtil.getEnvProperties("jenkinsUrlforEdit");
		editUrl = editUrl.replace("[project_name]", jobName);
		URL url = new URL(editUrl);
		String user = propertyUtil.getEnvProperties("jenkinsUserName");
		String pass = propertyUtil.getEnvProperties("jenkinsPass");
		String authStr = user + ":" + pass;
		String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", "Basic " + encoding);

		try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
			String line;

			
			while ((line = in.readLine()) != null) {
				response.add(line);				
			}
			return response;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.info("error  while positng Url");
		}

		return response;

	}
	
	public List<String> postURLConsole(String jenkinsUrl)
			 {
		HttpURLConnection httpClient = null;
		log.info("url in post util " + jenkinsUrl);

		String username = propertyUtil.getEnvProperties("jenkinsUserName");
		String password = propertyUtil.getEnvProperties("jenkinsPass");
		List<String> response = new ArrayList<>();

		boolean basicAuth = true;
		if (jenkinsUrl.contains("https://genx-jenkins.power.cg.com/sonar")) {
			basicAuth = false;
		}
		if (httpClient == null) {
			try {
				httpClient = (HttpURLConnection) new URL(jenkinsUrl).openConnection();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		try {
			relaxHostChecking(httpClient);
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// add reuqest header
		try {
			httpClient.setRequestMethod("POST");
		} catch (ProtocolException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
		httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		httpClient.setRequestProperty("Content-Type", "application/xml");
		httpClient.setRequestProperty("Accept", "application/xml");
		String auth = username + ":" + password;

		byte[] encodedAuth = org.apache.commons.codec.binary.Base64.encodeBase64(auth.getBytes(StandardCharsets.ISO_8859_1));
		String authHeader = "Basic " + new String(encodedAuth);

		if (basicAuth) {
			httpClient.setRequestProperty("Authorization", authHeader);
		}
		httpClient.setDoOutput(true);

		int responseCode = 0;
		try {
			responseCode = httpClient.getResponseCode();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log.info("\nSending 'POST' request to URL : " + jenkinsUrl);
		log.info("Response Code : " + responseCode);
		try (BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()))) {
			String line;

			while ((line = in.readLine()) != null) {
				response.add(line);
			}

		} catch (Exception e) {
			log.info("error  while positng xml");
		}
		return response;
	}


}