package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.SVNCredentialsEntity;

public interface IJenkinsSVNCredentialsRepository extends PagingAndSortingRepository<SVNCredentialsEntity, Long>{
	
	@Query("SELECT r FROM SVNCredentialsEntity r where r.svnUserName=?1")
  	public SVNCredentialsEntity fetchSvnCredentials(String userName);
	
//	@Query("SELECT r FROM SVNCredentialsEntity r where r.projectInformationEntity.projectId=?1")
//	public List<SVNCredentialsEntity> fetchSVNCredentialsByProjectId(String projectId);
	
	@Query("SELECT r FROM SVNCredentialsEntity r where r.svnCredentialsId=?1")
  	public SVNCredentialsEntity fetchSvnCredentialsById(long svnCredentialsId);
	
	@Query("SELECT r FROM SVNCredentialsEntity r where r.gitUserName=?1")
  	public SVNCredentialsEntity fetchGitCredentials(String uerName);
}
