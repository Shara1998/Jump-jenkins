package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.RegressionThresholdEntity;

@Repository
public interface IJenkinsRegressionThresholdRepository extends PagingAndSortingRepository<RegressionThresholdEntity, Long>{

	
	@Query("SELECT p FROM RegressionThresholdEntity p WHERE p.profileGroupNameEntity.profileGroupNameId=?1 and p.toolMasterEntity.toolId=?2")		
	public RegressionThresholdEntity fetchregthreshold(Long profileid, Long toolId);	
}
