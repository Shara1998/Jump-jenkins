package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.PerformanceThresholdEntity;

@Repository
public interface IJnkinsPerformanceThresholdRepository extends PagingAndSortingRepository<PerformanceThresholdEntity, Long>{

	
	@Query("SELECT p FROM PerformanceThresholdEntity p WHERE p.profileGroupNameEntity.profileGroupNameId=?1 and p.toolMasterEntity.toolId=?2")		
	public PerformanceThresholdEntity fetchPerThreshold(Long profileid, Long toolId);	
}
