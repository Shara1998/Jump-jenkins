package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;

public interface IJenkinsYascaJobRepository extends PagingAndSortingRepository<YascaInformationEntity, Integer> {

	 @Query("SELECT j FROM YascaInformationEntity j  WHERE j.jobInformationEntity.jobId=?1")
	 public YascaInformationEntity getYascaEntityByJobId(long jobId);
	 
	 @Query("SELECT j FROM YascaInformationEntity j  WHERE j.jobInformationEntity.jobName=?1")
	 public YascaInformationEntity getDetailsByAppName(String jobName);
}
