package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.EnvUrlStorageEntity;

@Repository
public interface IJenkinsEnvUrlRepository extends PagingAndSortingRepository<EnvUrlStorageEntity, Long>{

	@Query("SELECT r.url FROM EnvUrlStorageEntity r where r.envName=?1 and  r.urlType=?2")
  	public String getUrlOnEnvAndType(String env,String urltype);
	
	@Query("SELECT r.userName FROM EnvUrlStorageEntity r where r.envName=?1 and  r.urlType=?2")
  	public String getUserOnEnvAndType(String env,String urltype);

	@Query("SELECT r.pwd FROM EnvUrlStorageEntity r where r.envName=?1 and  r.urlType=?2")
  	public String getPwdOnEnvAndType(String env,String urltype);

}
