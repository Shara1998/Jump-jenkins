package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;

public interface IJenkinsCodeQualityInformationRepository extends PagingAndSortingRepository<CodeQualityInformationEntity, Long>{
	@Query("SELECT j FROM CodeQualityInformationEntity j WHERE j.jobInformationEntity.jobId=?1")
	  public CodeQualityInformationEntity getCodeQualEntityByJobId(long jobId);

	  @Query("SELECT j FROM CodeQualityInformationEntity j WHERE j.jobInformationEntity.jobName=?1")
	  public CodeQualityInformationEntity getDetailsByAppName(String jobName);

	@Query("SELECT j FROM CodeQualityInformationEntity j WHERE j.jobInformationEntity.jobId=?1")
	public CodeQualityInformationEntity getSonarAvgHealth(long jobId);
}
