package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.ApplicationTypeMasterEntity;
import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;

@Repository
public interface IJenkinsApplicationInformationRepository
		extends PagingAndSortingRepository<GroupHierarchyEntity, Long> {

//	@Query("SELECT j FROM ApplicationInformationEntity j WHERE j.projectInformationEntity.subAccountMasterEntity.accountMasterEntity.accountid=?1 AND j.projectInformationEntity.subAccountMasterEntity.subAccountid=?2 AND j.projectInformationEntity.projectId=?3")
//	List<GroupHierarchyEntity> fetchDistinctApplicationNames(long accountId, long subAccountId, String projectId);

	/*
	 * @Query("SELECT j FROM ApplicationInformationEntity j WHERE j.projectInformationEntity.projectId=?1"
	 * ) public List<GroupHierarchyEntity> fetchApplicationDetails(String
	 * projectId);
	 */

	/*
	 * @Query("SELECT e FROM GroupHierarchyEntity e WHERE e.applicationName LIKE ?1"
	 * ) public GroupHierarchyEntity fetchApplicationEntity(String applicationName);
	 */

	@Query("SELECT a FROM ApplicationTypeMasterEntity a")
	public List<ApplicationTypeMasterEntity> fetchApplicationType();

	/*
	 * @Query("SELECT DISTINCT e.applicationInformationEntity.applicationId FROM JobInformationEntity e WHERE e.applicationInformationEntity.projectInformationEntity.projectId=?1"
	 * ) public List<Long> fetchApplicationEntityByUserName(String projectId);
	 */

//	@Query("SELECT a FROM ApplicationInformationEntity a WHERE a.applicationId=?1")
//	public GroupHierarchyEntity fetchApplicationByJobId(long applicationId);

//	@Query("SELECT DISTINCT e.applicationInformationEntity FROM JobInformationEntity e WHERE e.employeeInformationEntity.username=?1 AND e.applicationInformationEntity.projectInformationEntity.projectId=?2")
//	public List<GroupHierarchyEntity> fetchApplicationEntityByUser(String userName, String projectId);

}
