package com.capgemini.genx.core.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.RegressionNewmanEntity;


@Repository
public interface IJenkinsRegressionNewmanRepository extends PagingAndSortingRepository<RegressionNewmanEntity, Long>{

}
