package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.dashboard.reusable.entity.KubernetesInformationEntity;

public interface IJenkinsKubernetesRepository extends JpaRepository<KubernetesInformationEntity, Long>{

	@Query("SELECT i FROM KubernetesInformationEntity i WHERE i.kubJobInformationEntity.jobId=?1 ")
	public KubernetesInformationEntity getDetailsByJobId(long jobId);
}
