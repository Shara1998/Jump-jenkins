package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.ProfileGroupEntity;

@Repository
public interface IJenkinsProfileGroupRepository extends PagingAndSortingRepository<ProfileGroupEntity, Long> {	

	@Query("SELECT p from ProfileGroupEntity p WHERE p.profileGroupNameEntity.profileGroupName=?1 and flag=true")
	public List<ProfileGroupEntity> fetchStageList(String profileGroupName);

	}
