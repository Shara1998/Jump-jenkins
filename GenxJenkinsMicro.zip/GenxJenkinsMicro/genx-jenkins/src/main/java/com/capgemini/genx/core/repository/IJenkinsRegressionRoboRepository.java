package com.capgemini.genx.core.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.RegressionRoboEntity;


@Repository
public interface IJenkinsRegressionRoboRepository extends PagingAndSortingRepository<RegressionRoboEntity, Long>{

}
