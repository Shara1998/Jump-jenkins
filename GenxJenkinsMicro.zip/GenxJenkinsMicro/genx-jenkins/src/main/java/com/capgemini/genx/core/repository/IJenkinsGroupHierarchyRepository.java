package com.capgemini.genx.core.repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;

@Repository
public interface IJenkinsGroupHierarchyRepository extends PagingAndSortingRepository<GroupHierarchyEntity, Long>{

	@Query("SELECT j FROM GroupHierarchyEntity j WHERE j.levelId=?1")
	public GroupHierarchyEntity getGrpHierarchy(long levelId);
	
	@Query("SELECT j FROM GroupHierarchyEntity j WHERE j.levelName=?1 and j.levelType=?2")
	public GroupHierarchyEntity getGrpHierarchyByLevelName(String levelName, String levelType);
	
	
}

