package com.capgemini.genx.core.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;

public interface IJenkinsJobInformationRepository extends PagingAndSortingRepository<JobInformationEntity, Long> {
	/*
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.applicationInformationEntity.projectInformationEntity.subAccountMasterEntity.accountMasterEntity.accountid=?1 AND j.applicationInformationEntity.projectInformationEntity.subAccountMasterEntity.subAccountid=?2 AND j.applicationInformationEntity.projectInformationEntity.projectId=?3 AND j.applicationInformationEntity.applicationId=?4 order by j.jobId desc"
	 * ) List<JobInformationEntity> fetchDistinctUiAndMicroservicesJobs(long
	 * accountId, long subAccountId, String projectId, long applicationId);
	 */
	@Query("SELECT j FROM JobInformationEntity j WHERE j.jobName=?1")
	public JobInformationEntity findByAppName(String jobName);
	@Query("SELECT j FROM JobInformationEntity j WHERE j.jobName=?1")
	public JobInformationEntity getJobEntityByJobName(String jobName);
	
	/*
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.releaseDate BETWEEN ?1 AND ?2"
	 * ) public List<JobInformationEntity> fetchJobsByDate(Date releaseFROM, Date
	 * releaseTo);
	 */	
	@Query("SELECT j FROM JobInformationEntity j WHERE j.jobId=?1")
	public JobInformationEntity getJobsByJobId(long jobId);
	
	/*
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.applicationInformationEntity.applicationId=?1"
	 * ) public List<JobInformationEntity> getchJobsByApplicationId(long
	 * applicationId);
	 * 
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.employeeInformationEntity.username=?1"
	 * ) public List<JobInformationEntity> getJobsByUserId(String userName);
	 * 
	 * @Query("SELECT j FROM JobInformationEntity j") public
	 * List<JobInformationEntity> fetchJobs();
	 * 
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.applicationInformationEntity.applicationId=?1 AND j.employeeInformationEntity.username=?2"
	 * ) public List<JobInformationEntity> getchJobsByApplicationId(long
	 * applicationId, String userId);
	 */
	
	/*
	 * @Query("SELECT j FROM JobInformationEntity j WHERE j.applicationInformationEntity.applicationId=?1"
	 * ) public List<JobInformationEntity> getJobsByApp(long applicationId);
	 */
	
	@Query("SELECT j FROM JobInformationEntity j WHERE j.jobName LIKE ?1")
    public JobInformationEntity findByAppNameLike(String jobName);
	
}
