package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.CodeBaseMasterEntity;
public interface IJenkinsCodeBaseMasterEntity extends PagingAndSortingRepository<CodeBaseMasterEntity, Long> {
	@Query("SELECT j FROM CodeBaseMasterEntity j WHERE j.applicationTypeMasterEntity.applicationTypeId=?1")
	public List<CodeBaseMasterEntity> fetchCodeBaseByAppType(long applicationId);
	
	@Query("SELECT j.codeBaseId FROM CodeBaseMasterEntity j WHERE j.codeBase=?1")
	public long getCodebaseId(String codebaseName);
}
