package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.ProfileMasterEntity;
@Repository
public interface IJenkinsProfileMasterRepository extends PagingAndSortingRepository<ProfileMasterEntity, Long> {
	
	@Query("SELECT p.profileId from ProfileMasterEntity p where p.profileName=?1")
	public long getProfileIdByProfileName(String profileName);	

	@Query("SELECT p from ProfileMasterEntity p where p.profileId=?1")
	public ProfileMasterEntity getProfileById(long profileId);
	
	@Query("SELECT p from ProfileMasterEntity p where p.profileName=?1")
	public ProfileMasterEntity getProfileIdByName(String profileName);
	

}
