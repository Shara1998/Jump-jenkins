package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;

public interface IJenkinsPerformanceInformationRepository extends PagingAndSortingRepository<PerformanceInformationEntity, Long>{
	@Query("SELECT p FROM PerformanceInformationEntity p WHERE p.jobInformationEntity.jobId=?1")
	public PerformanceInformationEntity getPerformanceEntityByJobId(long jobId);
	 
	@Query("SELECT p FROM PerformanceInformationEntity p WHERE p.jobInformationEntity.jobName=?1")
	  public PerformanceInformationEntity getDetailsByAppName(String jobName);
}
