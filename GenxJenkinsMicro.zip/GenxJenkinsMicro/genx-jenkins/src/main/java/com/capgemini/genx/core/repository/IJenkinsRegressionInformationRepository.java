package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.RegressionInformationEntity;

public interface IJenkinsRegressionInformationRepository extends PagingAndSortingRepository<RegressionInformationEntity, Long>  {
	@Query("SELECT r FROM RegressionInformationEntity r WHERE r.jobInformationEntity.jobId=?1")
	public RegressionInformationEntity getRegressionEntityByJobId(long jobId);
	
	@Query("SELECT r FROM RegressionInformationEntity r WHERE r.jobInformationEntity.jobName=?1")
	public RegressionInformationEntity getDetailsByAppName(String jobName);
}
