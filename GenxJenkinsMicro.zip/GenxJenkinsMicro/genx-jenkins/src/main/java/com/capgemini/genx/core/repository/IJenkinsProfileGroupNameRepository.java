package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;

public interface IJenkinsProfileGroupNameRepository extends PagingAndSortingRepository<ProfileGroupNameEntity, Long> {

	@Query("select p from ProfileGroupNameEntity p where p.profileGroupName=?1")
	ProfileGroupNameEntity findByProfileName(String profileGroupName);


	@Query("select p.agentRequire from ProfileGroupNameEntity p where p.profileGroupName=?1")
	Boolean findByAgentRequire(String profileGroupName);

}

