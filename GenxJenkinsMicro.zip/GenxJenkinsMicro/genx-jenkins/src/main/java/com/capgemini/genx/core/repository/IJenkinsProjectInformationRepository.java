package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;


public interface IJenkinsProjectInformationRepository extends JpaRepository<GroupHierarchyEntity, Long> {

//	@Query("SELECT j FROM ProjectInformationEntity j WHERE j.subAccountMasterEntity.accountMasterEntity.accountid=?1 AND j.subAccountMasterEntity.subAccountid=?2")
//  	public List<GroupHierarchyEntity> fetchDistinctProjectName(long accountId, long subAccountId);
	
//	@Query("SELECT r FROM ProjectInformationEntity r")
//  	public List<GroupHierarchyEntity> fetchProjectDetails();
	
//	@Query("SELECT e FROM ProjectInformationEntity e WHERE e.projectName LIKE ?1")
//    public GroupHierarchyEntity fetchProjectEntity(String projectName);
	
//	@Query("SELECT e FROM ProjectInformationEntity e WHERE e.projectName=?1")
//    public GroupHierarchyEntity fetchProjectEntityByProjName(String projectName);	
	
//	@Query("SELECT e FROM ProjectInformationEntity e WHERE e.subAccountMasterEntity.subAccountid= ?1")
//    public List<GroupHierarchyEntity> fetchProjectDetails(long subAccountId);
	
//	@Query("SELECT a FROM ProjectInformationEntity a WHERE a.projectId=?1")
//	public GroupHierarchyEntity fetchProjectByProjId(String projectId);

	
//	@Query("SELECT DISTINCT e.projectInformationEntity.projectId FROM EmployeeMasterEntity e WHERE e.employeeInformationEntity.username=?1 AND e.subAccountMasterEntity.subAccountid=?2")
//    public List<String> fetchProjectEntityByUserName(String userName);
	
//	@Query("SELECT DISTINCT e.projectInformationEntity.projectId FROM EmployeeMasterEntity e WHERE e.employeeInformationEntity.username=?1 AND e.subAccountMasterEntity.subAccountid=?2")
//    public List<String> fetchProjectEntityByUserName(String userName, long subAccountId);
	
//	@Query("SELECT DISTINCT e.projectInformationEntity.projectId FROM EmployeeMasterEntity e WHERE e.employeeInformationEntity.username=?1 AND e.accountMasterEntity.accountid=?2 AND e.subAccountMasterEntity.subAccountid=?3")
//    public List<String> fetchProjectEntityByUserName(String userName, long accountId, long subAccountId);
	
//	@Query("SELECT e FROM ProjectInformationEntity e WHERE e.projectId = ?1")
//    public GroupHierarchyEntity fetchProjectEntityById(String projectId);
	
	
//	@Query("SELECT DISTINCT e.projectInformationEntity FROM EmployeeMasterEntity e WHERE e.employeeInformationEntity.username=?1 AND e.subAccountMasterEntity.subAccountid=?2")
//    public List<GroupHierarchyEntity> fetchProjectEntityByUser(String userName, long subAccountId);
	
	
	
}
