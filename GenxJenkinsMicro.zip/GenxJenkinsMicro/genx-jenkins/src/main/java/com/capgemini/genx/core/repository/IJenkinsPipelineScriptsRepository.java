package com.capgemini.genx.core.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.dashboard.reusable.entity.TaskEntity;

public interface IJenkinsPipelineScriptsRepository extends JpaRepository<TaskEntity, String>{
	
	@Query("SELECT i FROM TaskEntity i WHERE i.toolMasterEntity.toolId=?1 and i.codeBaseMasterEntity.codeBaseId=?2 and i.jenkinsScriotType=?3  order by i.sequenceID")
	public List<TaskEntity> getDetailsByTool(long toolId,long profileid,String jenkinsScriptType);
	

}
