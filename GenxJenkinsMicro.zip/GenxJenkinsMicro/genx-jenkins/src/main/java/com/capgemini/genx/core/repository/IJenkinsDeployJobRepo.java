package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.DeployJobEntity;

public interface IJenkinsDeployJobRepo extends PagingAndSortingRepository<DeployJobEntity, Long>{

	@Query("SELECT d FROM DeployJobEntity d WHERE d.jobEntity.jobId=?1")
	public DeployJobEntity getDeployJobEntityByJobId(long jobId);
	
}
