package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.RepositoryDetailsEntity;

public interface IJenkinsRepositoryDetailsRepository extends PagingAndSortingRepository<RepositoryDetailsEntity, Long> {

	@Query("SELECT j FROM RepositoryDetailsEntity j WHERE j.jobInformationEntity.jobId=?1")
	public RepositoryDetailsEntity getRepoByJobId(long jobId);
}
