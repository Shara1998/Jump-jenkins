package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dashboard.reusable.entity.YascaThresholdEntity;

@Repository
public interface IJenkinsYascaThresholdRepository extends PagingAndSortingRepository<YascaThresholdEntity, Long>{
	
	@Query("SELECT p FROM YascaThresholdEntity p WHERE p.profileGroupNameEntity.profileGroupNameId=?1 and p.toolMasterEntity.toolId=?2")		
	public YascaThresholdEntity fetchThesholdValues(Long profileGroupid, Long toolId);	
}
