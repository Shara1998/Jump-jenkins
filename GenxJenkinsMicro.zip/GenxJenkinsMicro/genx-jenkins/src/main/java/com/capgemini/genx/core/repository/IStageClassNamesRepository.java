package com.capgemini.genx.core.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.dashboard.reusable.entity.StageClassNamesEntity;
public interface IStageClassNamesRepository extends PagingAndSortingRepository<StageClassNamesEntity, Long> {
	
	//@Query("SELECT j FROM CodeBaseMasterEntity j WHERE j.applicationTypeMasterEntity.applicationTypeId=?1")
	//public List<StageClassNamesEntity> fetchCodeBaseByAppType(long applicationId);
	
	@Query("SELECT j.agentRequire FROM StageClassNamesEntity j WHERE j.stageClassName=?1")
	public Boolean fetchAgentRequire(String stageClassName);
	
	@Query("SELECT j.attributes FROM StageClassNamesEntity j WHERE j.profileMasterEntity.profileId=?1 and j.devopsPlatformEntity.devopsPlatformId = 1")
	public String fetchAttributes(long id );
	
	@Query("SELECT j.stageClassName FROM StageClassNamesEntity j WHERE j.profileMasterEntity.profileId=?1")
	public String getStageName(long id);
	
	//@Query("SELECT j.attributes FROM StageClassNamesEntity j WHERE j.stageClassName=?1")
	//public String checkAttributes(String stageName);
	
}
