package com.capgemini.genx.core.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dashboard.reusable.entity.IstanbulEntity;

@Repository
@Transactional
public interface IJenkinsIstanbulRepository extends PagingAndSortingRepository<IstanbulEntity, Long>{

	@Query("SELECT r FROM IstanbulEntity r where r.jobInformationEntity.jobId=?1")
  	public IstanbulEntity fetchIstanbulReports(long jobId);
}
