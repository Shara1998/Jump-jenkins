package com.genx.base.cicd.assemblyline.extn.jenkins;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.genx.base.cicd.util.BeanFactoryDynamicAutowireService;

public class JenkinsFactoryTest {
	
	@InjectMocks
	JenkinsFactory jenkinsFactoryTest;
	
	@Mock
	BeanFactoryDynamicAutowireService beanFactoryDynamicAutowireService;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void createPipelineTest() throws IOException {
		jenkinsFactoryTest.createPipeline();
	}
}
