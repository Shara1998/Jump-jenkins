package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SeriesDTOTest {
	
	@InjectMocks
	SeriesDTO seriesDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getNameTest() {
		seriesDTOTest.getName();
	}
	@Test
	public void setNameTest() {
		seriesDTOTest.setName("setY");
	}
	@Test
	public void getYTest() {
		seriesDTOTest.getY();
	}
	@Test
	public void setYTest() {
		seriesDTOTest.setY(1l);
	}


}
