package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LoginDTOTest {
	@InjectMocks
	LoginDTO loginDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getUsernameTest() {
		loginDTOTest.getUsername();
	}
	@Test
	public void setUsernameTest() {
		loginDTOTest.setUsername("loginDTOTest.getUsername()");
	}
	@Test
	public void getPasswordTest() {
		loginDTOTest.getPass();
	}
	@Test
	public void setPasswordTest() {
		loginDTOTest.setPass("loginDTOTest.getUsername();");
	}
	@Test
	public void getValidationFlagTest() {
		loginDTOTest.getValidationFlag();
	}
	@Test
	public void setValidationFlagTest() {
		loginDTOTest.setValidationFlag("loginDTOTest.getUsername();");
	}


}
