package com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import com.capgemini.genx.core.repository.IJenkinsEnvUrlRepository;

public class EnvironmentServiceImplNewTest {

	@InjectMocks
	EnvironmentServiceImplNew environmentServiceImplNew;

	@Mock
	InputStream inputStream;

	@Mock
	Environment environment;

	@Mock
	IJenkinsEnvUrlRepository envUrlRepository;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = Exception.class)
	public void getPropValueTest() {

		environmentServiceImplNew.getPropValue("sendMailFlag");

	}

	@Test
	public void getProfileTest() {

		String[] s1 = { "1", "2", "3" };

		when(environment.getActiveProfiles()).thenReturn(s1);
		environmentServiceImplNew.getProfile();
	}

	@Test
	public void getUserOnEnvTest() {

		String[] s1 = { "1", "2", "3" };

		when(environment.getActiveProfiles()).thenReturn(s1);
		environmentServiceImplNew.getProfile();
		when(envUrlRepository.getUserOnEnvAndType("jenkins", "url")).thenReturn("url");
		environmentServiceImplNew.getUserOnEnv("url");
	}

	@Test
	public void appendUrlTest1() {

		environmentServiceImplNew.appendUrl("jenkinsUrlwindows", "Jenkins");
	}

	@Test
	public void appendUrlTest2() {

		environmentServiceImplNew.appendUrl("jenkinsUrl", "jenkins");
	}

	@Test
	public void appendUrlTest3() {

		environmentServiceImplNew.appendUrl("sonarUrl", "jenkins");
	}

	@Test
	public void appendUrlTest4() {

		environmentServiceImplNew.appendUrl("githubUrl", "jenkins");
	}

	@Test
	public void appendUrlTest5() {

		environmentServiceImplNew.appendUrl("key", "env");
	}

	@Test(expected = Exception.class)
	public void getEnvPropertiesTest()

	{

		environmentServiceImplNew.getEnvProperties("sendMailFlag");
	}

	@Test
	public void getPwdOnEnvTest() {
		String[] s1 = { "1", "2", "3" };

		when(environment.getActiveProfiles()).thenReturn(s1);
		environmentServiceImplNew.getProfile();
		when(envUrlRepository.getPwdOnEnvAndType("jenkins", "url")).thenReturn("url");
		environmentServiceImplNew.getPwdOnEnv("url");
	}

	@Test
	public void getUrlOnEnvTest() {
		String[] s1 = { "1", "2", "3" };

		when(environment.getActiveProfiles()).thenReturn(s1);
		environmentServiceImplNew.getProfile();
		when(envUrlRepository.getUrlOnEnvAndType("jenkins", "url")).thenReturn("url");
		environmentServiceImplNew.getUrlOnEnv("url");
	}
}
