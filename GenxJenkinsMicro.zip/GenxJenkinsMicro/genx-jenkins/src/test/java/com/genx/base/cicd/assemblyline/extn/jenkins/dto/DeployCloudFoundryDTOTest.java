package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DeployCloudFoundryDTOTest {
	@InjectMocks
	DeployCloudFoundryDTO deployCloudFoundryDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }	
	@Test
	public void getCfMemoryTest() {
		deployCloudFoundryDTO.getCfMemory();
	}
	@Test
	public void setCfMemoryTest() {
		deployCloudFoundryDTO.setCfMemory("cfMemory");
	}
	@Test
	public void getCfUserNameTest() {
		deployCloudFoundryDTO.getCfUserName();
	}
	@Test
	public void setCfUserNameTest() {
		deployCloudFoundryDTO.setCfUserName("setCfUserName");
	}
	@Test
	public void getCfPasswordTest() {
		deployCloudFoundryDTO.getCfPass();
	}
	@Test
	public void setCfPasswordTest() {
		deployCloudFoundryDTO.setCfPass("setCfUserName");
	}
	@Test
	public void getCfTargetTest() {
		deployCloudFoundryDTO.getCfTarget();
	}
	@Test
	public void setCfTargetTest() {
		deployCloudFoundryDTO.setCfTarget("setCfUserName");
	}
	@Test
	public void getCfOrganizationTest() {
		deployCloudFoundryDTO.getCfOrganization();
	}
	@Test
	public void setCfOrganizationTest() {
		deployCloudFoundryDTO.setCfOrganization("test");
	}
	@Test
	public void getCfSpaceTest() {
		deployCloudFoundryDTO.getCfSpace();
	}
	@Test
	public void setCfSpaceTest() {
		deployCloudFoundryDTO.setCfSpace("setCfSpace");
	}
	@Test
	public void getCfServiceNameTest() {
		deployCloudFoundryDTO.getCfServiceName();
	}
	@Test
	public void setCfServiceNameTest() {
		deployCloudFoundryDTO.setCfServiceName("setCfServiceName");
	}
	@Test
	public void getCfServiceTypeTest() {
		deployCloudFoundryDTO.getCfServiceType();
	}
	@Test
	public void setCfServiceTypeTest() {
		deployCloudFoundryDTO.setCfServiceType("type");
	}
	@Test
	public void getCfServicePlanTest() {
		deployCloudFoundryDTO.getCfServicePlan();
	}
	@Test
	public void setCfServicePlanTest() {
		deployCloudFoundryDTO.setCfServicePlan("plan");
	}
	@Test
	public void getCfReadConfigTest() {
		deployCloudFoundryDTO.getCfReadConfig();
	}
	@Test
	public void setCfReadConfigTest() {
		deployCloudFoundryDTO.setCfReadConfig("setCfReadConfig");
	}
	@Test
	public void getCfManifestFileTest() {
		deployCloudFoundryDTO.getCfManifestFile();
	}
	@Test
	public void setCfManifestFileTest() {
		deployCloudFoundryDTO.setCfManifestFile("setCfManifestFile");
	}
	@Test
	public void getCfApplicationNameTest() {
		deployCloudFoundryDTO.getCfApplicationName();
	}
	@Test
	public void setCfApplicationNameTest() {
		deployCloudFoundryDTO.setCfApplicationName("appname");
	}
	@Test
	public void getCfHostNameTest() {
		deployCloudFoundryDTO.getCfHostName();
	}
	@Test
	public void setCfHostNameTest() {
		deployCloudFoundryDTO.setCfHostName("test");
	}
	@Test
	public void getCfInstancesTest() {
		deployCloudFoundryDTO.getCfInstances();
	}
	@Test
	public void setCfInstancesTest() {
		deployCloudFoundryDTO.setCfInstances("setCfInstances");
	}
	@Test
	public void getCfTimeoutTest() {
		deployCloudFoundryDTO.getCfTimeout();
	}
	@Test
	public void setCfTimeoutTest() {
		deployCloudFoundryDTO.setCfTimeout("setCfTimeout");
	}
	@Test
	public void getCfCustomBuildPackTest() {
		deployCloudFoundryDTO.getCfCustomBuildPack();
	}
	@Test
	public void setCfCustomBuildPackTest() {
		deployCloudFoundryDTO.setCfCustomBuildPack("setCfCustomBuildPack");
	}
	@Test
	public void getCfCustomStackTest() {
		deployCloudFoundryDTO.getCfCustomStack();
	}
	@Test
	public void setCfCustomStackTest() {
		deployCloudFoundryDTO.setCfCustomStack("setCfCustomStack");
	}
	@Test
	public void getServiceDetailsTest() {
		deployCloudFoundryDTO.getServiceDetails();
	}
	@Test
	public void setServiceDetailsTest() {
		deployCloudFoundryDTO.setServiceDetails(new ArrayList<>());
	}
	@Test
	public void isOtpDeployedTest() {
		deployCloudFoundryDTO.isOtpDeployed();
	}
	@Test
	public void setOtpDeployedTest() {
		deployCloudFoundryDTO.setOtpDeployed(true);
	}


}
