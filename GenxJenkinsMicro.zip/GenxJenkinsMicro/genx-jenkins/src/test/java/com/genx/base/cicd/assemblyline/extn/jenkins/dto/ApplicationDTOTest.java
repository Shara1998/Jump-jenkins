package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ApplicationDTOTest {
	
	@InjectMocks
	ApplicationDTO applicationDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getGroupIdTest() {
		applicationDTO.getGroupId();
	}
	@Test
	public void setGroupIdTest() {
		applicationDTO.setGroupId("kuber_ui");
	}
	@Test
	public void getCodeBaseTest() {
		applicationDTO.getCodeBase();
	}
	@Test
	public void setCodeBaseTest() {
		applicationDTO.setCodeBase("micro");
	}
	@Test
	public void getApplicationTypeTest() {
		applicationDTO.getApplicationType();
	}
	@Test
	public void setApplicationTypeTest() {
		applicationDTO.setApplicationType("setApplicationType");
	}
	@Test
	public void getReleaseDateToTest() {
		applicationDTO.getReleaseDateTo();
	}
	@Test
	public void setReleaseDateToTest() {
		applicationDTO.setReleaseDateTo(new Date());
	}
	@Test
	public void getReleaseDateFromTest() {
		applicationDTO.getReleaseDateFrom();
	}
	@Test
	public void setReleaseDateFromTest() {
		applicationDTO.setReleaseDateFrom(new Date());
	}	
	@Test
	public void getApplicationIdTest() {
		applicationDTO.getApplicationId();
	}
	@Test
	public void setApplicationIdTest() {
		applicationDTO.setApplicationId(1l);
	}
	@Test
	public void getApplicationNameTest() {
		applicationDTO.getApplicationName();
	}
	@Test
	public void setApplicationNameTest() {
		applicationDTO.setApplicationName("setApplicationName");
	}
	@Test
	public void getJobListTest() {
		applicationDTO.getJobList();
	}
	@Test
	public void setJobListTest() {
		applicationDTO.setJobList(new ArrayList<>());
	}
	@Test
	public void toStringTest() {
		applicationDTO.toString();
	}
	@Test
	public void getGroupDTOsTest() {
		applicationDTO.getGroupDTOs();
	}
	@Test
	public void setGroupDTOsTest() {
		applicationDTO.setGroupDTOs(new ArrayList<>());
	}
	@Test
	public void getMessageDTOTest() {
		applicationDTO.getMessageDTO();
	}
	@Test
	public void setMessageDTO() {
		applicationDTO.setMessageDTO(new MessageDTO());
	}

	

}
