package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SearchJsonTest {
	
	@InjectMocks
	SearchJson searchJson;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void searchJsonTest() throws ParseException {
		
		String obj1="{\"component\":{\"measures\":[{\"metric\":\"blocker_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"minor_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"alert_status\",\"value\":\"OK\"},{\"metric\":\"major_violations\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"sqale_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"security_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"vulnerabilities\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"reliability_rating\",\"bestValue\":false,\"value\":\"3.0\"},{\"metric\":\"duplicated_lines\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"critical_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"coverage\",\"bestValue\":false,\"value\":\"0.0\"},{\"metric\":\"duplicated_blocks\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"code_smells\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"info_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"bugs\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"duplicated_lines_density\",\"bestValue\":true,\"value\":\"0.0\"}],\"qualifier\":\"TRK\",\"name\":\"groovytesting\",\"description\":\"Project For capturing the operation manager detail\",\"id\":\"AXbbyOJWbkY5GD5z7dd-\",\"key\":\"groovytesting\"}}";
		JSONParser parser = new JSONParser();

		Object obj = parser.parse(obj1);
        JSONObject metrics = (JSONObject)obj;
		searchJson.searchJson("dummy", metrics);
		
	}
	@Test
	public void searchJsonPositiveTest() throws ParseException {
		
		String obj1="{\"component\":{\"measures\":[{\"metric\":\"blocker_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"minor_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"alert_status\",\"value\":\"OK\"},{\"metric\":\"major_violations\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"sqale_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"security_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"vulnerabilities\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"reliability_rating\",\"bestValue\":false,\"value\":\"3.0\"},{\"metric\":\"duplicated_lines\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"critical_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"coverage\",\"bestValue\":false,\"value\":\"0.0\"},{\"metric\":\"duplicated_blocks\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"code_smells\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"info_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"bugs\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"duplicated_lines_density\",\"bestValue\":true,\"value\":\"0.0\"}],\"qualifier\":\"TRK\",\"name\":\"groovytesting\",\"description\":\"Project For capturing the operation manager detail\",\"id\":\"AXbbyOJWbkY5GD5z7dd-\",\"key\":\"groovytesting\"}}";
		JSONParser parser = new JSONParser();

		Object obj = parser.parse(obj1);
        JSONObject metrics = (JSONObject)obj;
		searchJson.searchJson("minor_violations", metrics);
		
	}
	
	@Test
	public void mainTest() {
		
		String [] args= {"hello world"};
		
		searchJson.main(args);
		
	}

}
