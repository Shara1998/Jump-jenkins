package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.dto.JobDTO;

public class JenkinsBuildStageUtilTest {
	
	@InjectMocks
	JenkinsBuildStageUtil jenkinsDTOMapUtil;
	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	
	@Mock
	DevOpsWorkFlowUtilNew workFlowUtil;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void buildIndividualStageTest() {
		
JobDTO jobDto=new JobDTO();
jobDto.setJobName("test");
String url="https://actlabinnovationjenkinsdev.digitalcloudplatform.com/job/[project_name]/buildWithParameters?userFlag=[stage]";
JobInformationEntity jobInformationEntity=new JobInformationEntity();
Mockito.when(iJobInformationRepository.findByAppName("test")).thenReturn(jobInformationEntity);
Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlbuildPipelineJob")).thenReturn(url);


jenkinsDTOMapUtil.buildIndividualStage(jobDto, "SAST");
		
	}

}
