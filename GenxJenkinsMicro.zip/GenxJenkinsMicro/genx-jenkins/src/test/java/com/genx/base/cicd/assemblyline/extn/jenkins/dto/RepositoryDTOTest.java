package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class RepositoryDTOTest {
	@InjectMocks
	RepositoryDTO repositoryDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getComponentNameTest() {
		repositoryDTOTest.getComponentName();
	}
	@Test
	public void setComponentNameTest() {
		repositoryDTOTest.setComponentName("setCollectionUrl");
	}
	@Test
	public void getTfsUsernameTest() {
		repositoryDTOTest.getTfsUsername();
	}
	@Test
	public void setTfsUsernameTest() {
		repositoryDTOTest.setTfsUsername("setCollectionUrl");
	}
	@Test
	public void getTfsPasswordTest() {
		repositoryDTOTest.getTfsPass();
	}
	@Test
	public void setTfsPasswordTest() {
		repositoryDTOTest.setTfsPass("setCollectionUrl");
	}
	@Test
	public void getCollectionUrlTest() {
		repositoryDTOTest.getCollectionUrl();
	}
	@Test
	public void setCollectionUrlTest() {
		repositoryDTOTest.setCollectionUrl("setCollectionUrl");
	}
	@Test
	public void getLocalNameTest() {
		repositoryDTOTest.getLocalName();
	}
	@Test
	public void setLocalNameTest() {
		repositoryDTOTest.setLocalName("setCvsRoot");
	}
	@Test
	public void getRepoIdTest() {
		repositoryDTOTest.getRepoId();
	}
	@Test
	public void setRepoIdTest() {
		repositoryDTOTest.setRepoId(1l);
	}
	@Test
	public void getRepoTypeTest() {
		repositoryDTOTest.getRepoType();
	}
	@Test
	public void setRepoTypeTest() {
		repositoryDTOTest.setRepoType("setCvsRoot");
	}
	@Test
	public void getSvnURLTest() {
		repositoryDTOTest.getSvnURL();
	}
	@Test
	public void setSvnURLTest() {
		repositoryDTOTest.setSvnURL("setCvsRoot");
	}
	@Test
	public void getLocalModuleDirectoryTest() {
		repositoryDTOTest.getLocalModuleDirectory();
	}
	@Test
	public void setLocalModuleDirectoryTest() {
		repositoryDTOTest.setLocalModuleDirectory("setCvsRoot");
	}
	@Test
	public void getCvsRootTest() {
		repositoryDTOTest.getCvsRoot();
	}
	@Test
	public void setCvsRootTest() {
		repositoryDTOTest.setCvsRoot("setCvsRoot");
	}
	@Test
	public void getCvsPasswordTest() {
		repositoryDTOTest.getCvsPass();
	}
	@Test
	public void setCvsPasswordTest() {
		repositoryDTOTest.setCvsPass("Test");
	}
	@Test
	public void getRemoteNameTest() {
		repositoryDTOTest.getRemoteName();
	}
	@Test
	public void setRemoteNameTest() {
		repositoryDTOTest.setRemoteName("Test");
	}
	@Test
	public void getCvsLocationTest() {
		repositoryDTOTest.getCvsLocation();
	}
	@Test
	public void setCvsLocationTest() {
		repositoryDTOTest.setCvsLocation("Test");
	}
	@Test
	public void getBranchNameTest() {
		repositoryDTOTest.getBranchName();
	}
	@Test
	public void setBranchNameTest() {
		repositoryDTOTest.setBranchName("Test");
	}
	@Test
	public void getTagNameTest() {
		repositoryDTOTest.getTagName();
	}
	@Test
	public void setTagNameTest() {
		repositoryDTOTest.setTagName("Test");
	}
	@Test
	public void getGitURLTest() {
		repositoryDTOTest.getGitURL();
	}
	@Test
	public void setGitURLTest() {
		repositoryDTOTest.setGitURL("Test");
	}
	@Test
	public void getGitBranchTest() {
		repositoryDTOTest.getGitBranch();
	}
	@Test
	public void setGitBranchTest() {
		repositoryDTOTest.setGitBranch("Test");
	}
	@Test
	public void getProjectPathTest() {
		repositoryDTOTest.getProjectPath();
	}
	@Test
	public void setProjectPathTest() {
		repositoryDTOTest.setProjectPath("Test");
	}
	@Test
	public void getSvnUserNameTest() {
		repositoryDTOTest.getSvnUserName();
	}
	@Test
	public void setSvnUserNameTest() {
		repositoryDTOTest.setSvnUserName("Test");
	}
	@Test
	public void getSvnPasswordTest() {
		repositoryDTOTest.getSvnPass();
	}
	@Test
	public void setSvnPasswordTest() {
		repositoryDTOTest.setSvnPass("Test");
	}
	@Test
	public void getGitUserNameTest() {
		repositoryDTOTest.getGitUserName();
	}
	@Test
	public void setGitUserNameTest() {
		repositoryDTOTest.setGitUserName("Test");
	}
	@Test
	public void getGitPasswordTest() {
		repositoryDTOTest.getGitPass();
	}
	@Test
	public void setGitPassword() {
		repositoryDTOTest.setGitPass("setFeatureBranchName");
	}
	@Test
	public void getFeatureBranchName() {
		repositoryDTOTest.getFeatureBranchName();
	}
	@Test
	public void setFeatureBranchName() {
		repositoryDTOTest.setFeatureBranchName("setFeatureBranchName");
	}


}
