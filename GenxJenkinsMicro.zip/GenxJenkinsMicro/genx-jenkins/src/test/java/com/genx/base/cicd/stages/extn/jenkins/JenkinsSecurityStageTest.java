package com.genx.base.cicd.stages.extn.jenkins;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.capgemini.dashboard.reusable.entity.YascaThresholdEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaJobRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaThresholdRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;
import com.genx.base.cicd.util.BeanFactoryDynamicAutowireService;



public class JenkinsSecurityStageTest {
	
	
	@InjectMocks
	JenkinsSecurityStage jenkinsSecurityStage;
	
	@Mock
	JobDTO jobDTO;
	
	@Mock
	ToolFactory toolFactory;
	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Mock
	ITool iTool;
	
	@Mock
	BeanFactoryDynamicAutowireService beanFactoryDynamicAutowireService;
	
	@Mock
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	@Mock
	IJenkinsYascaJobRepository iYascaInformationRepository;
	
	@Mock
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;
	
	@Mock
	IJenkinsYascaThresholdRepository iJenkinsYascaThresholdRepository;
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Mock
	FetchBuldnumberByStage fetchBuldnumberByStage;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void buildStageTest() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);
		
		
		Mockito.when(iJobInformationRepository.findByAppName(null)).thenReturn(jobInfo);
		
		jenkinsSecurityStage.buildStage();
		
	}
	
	@Test
	public void saveStageMetricsTest() throws GenxCICDException {
		
		JSONObject metrics= new JSONObject();
		metrics.put("jobName", "test");
		metrics.put("buildNum", "1");
		metrics.put("buildStatus", "SUCCESS");
		
		Mockito.when(toolFactory.create(1l, 2l)).thenReturn(iTool);
		
		jenkinsSecurityStage.saveStageMetrics(metrics,"test:SUCCESS",1l,1l,2l,2l,100l);
		
	}
	
	@Test
	public void compareMetricsWithThresholdTest() throws GenxCICDException {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setGroupId("kuber_ui");
		jobInfo.setJobId(1234l);
		
		YascaInformationEntity yascaInformationEntity = new YascaInformationEntity();
		yascaInformationEntity.setYascaBuildStatus("SUCCESS");
		ProfileGroupNameEntity profileGroupNameEntity=new ProfileGroupNameEntity();
		profileGroupNameEntity.setProfileGroupNameId(1234l);
		YascaThresholdEntity yascaThresholdEntity=new YascaThresholdEntity();
		yascaThresholdEntity.setHighThresold(10);
		yascaThresholdEntity.setLowThresold(50);
		yascaThresholdEntity.setYascaGoodLevelPercentage(95);
		yascaThresholdEntity.setYascaRiskLevelPercentage(30);
		Mockito.when(iJobInformationRepository.findByAppName("test")).thenReturn(jobInfo);
		Mockito.when(toolFactory.create(1l, 2l)).thenReturn(iTool);
		Mockito.when(iYascaInformationRepository.getYascaEntityByJobId(jobInfo.getJobId())).thenReturn(yascaInformationEntity);
		Mockito.when(iJenkinsProfileGroupNameRepository.findByProfileName(jobInfo.getGroupId())).thenReturn(profileGroupNameEntity);
		Mockito.when(iJenkinsYascaThresholdRepository.fetchThesholdValues(profileGroupNameEntity.getProfileGroupNameId(), 2l)).thenReturn(yascaThresholdEntity);
		jenkinsSecurityStage.compareMetricsWithThreshold("test", 1l, "SUCCESS", 1l, 2l);	

	}
	@Test
	public void getStageLogsTest() throws IOException, GenxCICDException {
		

		jenkinsSecurityStage.getStageLogs(123l, 1l);

	}
	

}
