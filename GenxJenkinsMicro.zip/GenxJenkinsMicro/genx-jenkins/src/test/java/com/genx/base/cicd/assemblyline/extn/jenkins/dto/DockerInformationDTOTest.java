package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DockerInformationDTOTest {
	@InjectMocks
	DockerInformationDTO dockerInformationDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getJarNameTest() {
		dockerInformationDTO.getJarName();
	}
	@Test
	public void setJarNameTest() {
		dockerInformationDTO.setJarName("setJarName");
	}
	@Test
	public void getPortTest() {
		dockerInformationDTO.getPort();
	}
	@Test
	public void setPortTest() {
		dockerInformationDTO.setPort("setPort");
	}
	@Test
	public void getRepositoryDTOTest() {
		dockerInformationDTO.getRepositoryDTO();
	}
	@Test
	public void setRepositoryDTOTest() {
		dockerInformationDTO.setRepositoryDTO(new RepositoryDTO());
	}
	@Test
	public void getHostNameTest() {
		dockerInformationDTO.getHostName();
	}
	@Test
	public void setHostNameTest() {
		dockerInformationDTO.setHostName("setHostName");
	}
	@Test
	public void getPathToDockerFileTest() {
		dockerInformationDTO.getPathToDockerFile();
	}
	@Test
	public void setPathToDockerFileTest() {
		dockerInformationDTO.setPathToDockerFile("setPathToDockerFile");
	}

}
