package com.genx.base.cicd.stages.extn.jenkins;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.DeployJobEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsDeployJobRepo;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;



public class JenkinsDeploymentStageTest {
	
	@InjectMocks
	JenkinsDeploymentStage jenkinsDeploymentStage;
	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Mock
	IJenkinsDeployJobRepo ijenkinsdeployJobRepo;
	
	@Mock
	ToolFactory toolFactory;
	
	@Mock
	ITool iTool;
	
	@Mock
	JobDTO jobDTO;
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Mock
	FetchBuldnumberByStage fetchBuldnumberByStage;
	
	@Mock
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void buildStageTest() {
		
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);
		
		
		Mockito.when(iJobInformationRepository.findByAppName(null)).thenReturn(jobInfo);
		Mockito.when(ijenkinsdeployJobRepo.getDeployJobEntityByJobId(jobInfo.getJobId())).thenReturn(new DeployJobEntity());
		
		jenkinsDeploymentStage.buildStage();
	}
	
	@Test
	public void saveStageMetricsTest() throws GenxCICDException {
		
		JSONObject metrics= new JSONObject();
		metrics.put("jobName", "test");
		metrics.put("buildNum", "1");
		metrics.put("buildStatus", "SUCCESS");
		
		Mockito.when(toolFactory.create(1l, 12l)).thenReturn(iTool);
		
		jenkinsDeploymentStage.saveStageMetrics(metrics,"test:SUCCESS",1l,1l,3l,12l,100l);
		
	}
	
	@Test
	public void compareMetricsWithThresholdTest() throws GenxCICDException {
		Mockito.when(toolFactory.create(1l, 12l)).thenReturn(iTool);
		jenkinsDeploymentStage.compareMetricsWithThreshold("test", 1l, "SUCCESS", 1l, 12l);
	}
	@Test
	public void getStageLogsTest() throws IOException, GenxCICDException {
		

		jenkinsDeploymentStage.getStageLogs(123l, 1l);

	}


}
