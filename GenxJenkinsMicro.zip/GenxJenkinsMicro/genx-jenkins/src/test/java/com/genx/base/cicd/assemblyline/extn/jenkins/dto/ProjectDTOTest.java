package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ProjectDTOTest {
	
	@InjectMocks
	ProjectDTO projectDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getGroupIdTest() {
		projectDTOTest.getGroupId();
	}
	@Test
	public void setGroupIdTest() {
		projectDTOTest.setGroupId("getStatus");
	}
	@Test
	public void getErrorCodeTest() {
		projectDTOTest.getErrorCode();
	}
	@Test
	public void setErrorCodeTest() {
		projectDTOTest.setErrorCode("getStatus");
	}
	@Test
	public void getStatusTest() {
		projectDTOTest.getStatus();
	}
	@Test
	public void setStatusTest() {
		projectDTOTest.setStatus("setApplicantList");
	}
	@Test
	public void getProjectIdTest() {
		projectDTOTest.getProjectId();
	}
	@Test
	public void setProjectIdTest() {
		projectDTOTest.setProjectId("setApplicantList");
	}
	@Test
	public void getProjectNameTest() {
		projectDTOTest.getProjectName();
	}
	@Test
	public void setProjectNameTest() {
		projectDTOTest.setProjectName("setApplicantList");
	}
	@Test
	public void getApplicantListTest() {
		projectDTOTest.getApplicantList();
	}
	@Test
	public void setApplicantListTest() {
		projectDTOTest.setApplicantList(new ArrayList<>());
	}
	@Test
	public void toStringTest() {
		projectDTOTest.toString();
	}
	@Test
	public void getGroupDTOsTest() {
		projectDTOTest.getGroupDTOs();
	}
	@Test
	public void setGroupDTOsTest() {
		projectDTOTest.setGroupDTOs(new ArrayList<>());
	}


}
