package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class GroupDTOTest {
	@InjectMocks
	GroupDTO groupDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getGroupIdTest() {
		groupDTO.getGroupId();
	}
	@Test
	public void setGroupIdTest() {
		groupDTO.setGroupId("groupDTO");
	}

}
