package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DeployChefDTOTest {
	@InjectMocks
	DeployChefDTO deployChefDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getChefUserNameTest() {
		deployChefDTO.getChefUserName();
	}
	@Test
	public void setChefUserNameTest() {
		deployChefDTO.setChefUserName("setChefUserName");
	}
	@Test
	public void getChefPasswordTest() {
		deployChefDTO.getChefPass();
	}
	@Test
	public void setChefPasswordTest() {
		deployChefDTO.setChefPass("setChefUserName");
	}
	@Test
	public void getChefWAREARFilesTest() {
		deployChefDTO.getChefWAREARFiles();
	}
	@Test
	public void setChefWAREARFilesTest() {
		deployChefDTO.setChefWAREARFiles("setChefUserName");
	}
	@Test
	public void getChefContextPathTest() {
		deployChefDTO.getChefContextPath();
	}
	@Test
	public void setChefContextPath() {
		deployChefDTO.setChefContextPath("setChefUserName");
	}


}
