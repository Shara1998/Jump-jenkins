package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PipelineDTOTest {
	

	@InjectMocks
	PipelineDTO pipelineDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getSonarDTOTest() {
		pipelineDTOTest.getSonarDTO();
	}
	@Test
	public void setSonarDTOTest() {
		pipelineDTOTest.setSonarDTO(new SonarDTO());
	}
	@Test
	public void getDeployDTOTest() {
		pipelineDTOTest.getDeployDTO();
	}
	@Test
	public void setDeployDTOTest() {
		pipelineDTOTest.setDeployDTO(new DeployDTO());
	}
	@Test
	public void getRegressionInformationDTOTest() {
		pipelineDTOTest.getRegressionInformationDTO();
	}
	@Test
	public void setRegressionInformationDTOTest() {
		pipelineDTOTest.setRegressionInformationDTO(new RegressionInformationDTO());
	}
	@Test
	public void getPerformanceInformationDTOTest() {
		pipelineDTOTest.getPerformanceInformationDTO();
	}
	@Test
	public void setPerformanceInformationDTOTest() {
		pipelineDTOTest.setPerformanceInformationDTO(new PerformanceInformationDTO());
	}
	@Test
	public void getStageNamesTest() {
		pipelineDTOTest.getStageNames();
	}
	@Test
	public void setStageNamesTest() {
		pipelineDTOTest.setStageNames(new String[0]);
	}
	@Test
	public void getProfileTypeTest() {
		pipelineDTOTest.getProfileType();
	}
	@Test
	public void setProfileTypeTest() {
		pipelineDTOTest.setProfileType("PerformanceInformationDTO");
	}


}
