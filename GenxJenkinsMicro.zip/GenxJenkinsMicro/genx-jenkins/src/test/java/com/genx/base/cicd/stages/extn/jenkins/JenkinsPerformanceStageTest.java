package com.genx.base.cicd.stages.extn.jenkins;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceThresholdEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJnkinsPerformanceThresholdRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;



public class JenkinsPerformanceStageTest {
	@InjectMocks
	JenkinsPerformanceStage jenkinsPerformanceStage;
	
	@Mock
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	@Mock
	ToolFactory toolFactory;
	
	@Mock
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;	
	
	@Mock
	IJenkinsPerformanceInformationRepository iJenkinsPerformanceInformationRepository;
	
	@Mock
	IJnkinsPerformanceThresholdRepository iJnkinsPerformanceThresholdRepository;
	
	@Mock
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;
	
	@Mock
	ITool iTool;
	
	@Mock
	JobDTO jobDTO;
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Mock
	FetchBuldnumberByStage fetchBuldnumberByStage;
	

	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void buildStageTest() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);
		
		
		Mockito.when(iJobInformationRepository.findByAppName(null)).thenReturn(jobInfo);
		Mockito.when(iJenkinsPerformanceInformationRepository.getPerformanceEntityByJobId(jobInfo.getJobId())).thenReturn(new PerformanceInformationEntity());
		jenkinsPerformanceStage.buildStage();
	}
	
	@Test
	public void saveStageMetricsTest() throws GenxCICDException {
		
		JSONObject metrics= new JSONObject();
		metrics.put("jobName", "test");
		metrics.put("buildNum", "1");
		metrics.put("buildStatus", "SUCCESS");
		
		Mockito.when(toolFactory.create(1l, 9l)).thenReturn(iTool);
		
		jenkinsPerformanceStage.saveStageMetrics(metrics,"test:SUCCESS",1l,1l,5l,9l,100l);
		
	}
	
	@Test(expected=NullPointerException.class)
	public void compareMetricsWithThresholdTest() throws GenxCICDException {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setGroupId("kuber_ui");
		jobInfo.setJobId(1234l);
		
		PerformanceInformationEntity performanceInformationEntity = new PerformanceInformationEntity();
		performanceInformationEntity.setResponseTime("6000");
		ProfileGroupNameEntity profileGroupNameEntity=new ProfileGroupNameEntity();
		profileGroupNameEntity.setProfileGroupNameId(1234l);
		PerformanceThresholdEntity performanceThresholdEntity=new PerformanceThresholdEntity();
		
		performanceThresholdEntity.setResponseTime(6000);
		performanceThresholdEntity.setPerGoodLevelPercentage(100);
		performanceThresholdEntity.setPerRiskLevelPercentage(0);
		
		Mockito.when(iJenkinsJobInformationRepository.findByAppName("test")).thenReturn(jobInfo);
		Mockito.when(toolFactory.create(1l, 9l)).thenReturn(iTool);
		Mockito.when(iJenkinsPerformanceInformationRepository
				.getPerformanceEntityByJobId(jobInfo.getJobId())).thenReturn(performanceInformationEntity);
		Mockito.when(iJenkinsProfileGroupNameRepository.findByProfileName(jobInfo.getGroupId())).thenReturn(profileGroupNameEntity);
		Mockito.when(iJnkinsPerformanceThresholdRepository.fetchPerThreshold(profileGroupNameEntity.getProfileGroupNameId(), 9l)).thenReturn(performanceThresholdEntity);
		Mockito.when(iJenkinsPerformanceInformationRepository.getPerformanceEntityByJobId(jobInfo.getJobId())).thenReturn(new PerformanceInformationEntity());

		jenkinsPerformanceStage.compareMetricsWithThreshold("test", 1l, "SUCCESS", 1l, 9l);	

	}
	@Test
	public void getStageLogsTest() throws IOException, GenxCICDException {
		

		jenkinsPerformanceStage.getStageLogs(123l, 1l);

	}
	
	

}
