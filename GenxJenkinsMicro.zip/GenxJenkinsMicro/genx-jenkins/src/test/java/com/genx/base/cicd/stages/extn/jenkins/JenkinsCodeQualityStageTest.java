package com.genx.base.cicd.stages.extn.jenkins;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;
import com.capgemini.dashboard.reusable.entity.DeployJobEntity;
import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeQualityInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.stages.BaseStageDecorator;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;

public class JenkinsCodeQualityStageTest {

	@InjectMocks
	JenkinsCodeQualityStage jenkinsCodeQualityStage;

	@Mock
	JobDTO jobDTO;

	@Mock
	ToolFactory toolFactory;
	@Mock
	ITool iTool;
	@Mock
	BaseStageDecorator codeQualityStage;

	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Mock
	IJenkinsCodeQualityInformationRepository iJenkinsCodeQualityInformationRepository;

	@Mock
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Mock
	FetchBuldnumberByStage fetchBuldnumberByStage;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void buildStageTest() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);

		Mockito.when(iJobInformationRepository.findByAppName(null)).thenReturn(jobInfo);
		Mockito.when(iJenkinsCodeQualityInformationRepository.getCodeQualEntityByJobId(jobInfo.getJobId()))
				.thenReturn(new CodeQualityInformationEntity());

		jenkinsCodeQualityStage.buildStage();
	}

	@Test
	public void saveStageMetricsTest() throws ParseException, GenxCICDException {
		String obj1 = "{\"component\":{\"measures\":[{\"metric\":\"blocker_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"minor_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"alert_status\",\"value\":\"OK\"},{\"metric\":\"major_violations\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"sqale_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"security_rating\",\"bestValue\":true,\"value\":\"1.0\"},{\"metric\":\"vulnerabilities\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"reliability_rating\",\"bestValue\":false,\"value\":\"3.0\"},{\"metric\":\"duplicated_lines\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"critical_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"coverage\",\"bestValue\":false,\"value\":\"0.0\"},{\"metric\":\"duplicated_blocks\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"code_smells\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"info_violations\",\"bestValue\":true,\"value\":\"0\"},{\"metric\":\"bugs\",\"bestValue\":false,\"value\":\"1\"},{\"metric\":\"duplicated_lines_density\",\"bestValue\":true,\"value\":\"0.0\"}],\"qualifier\":\"TRK\",\"name\":\"groovytesting\",\"description\":\"Project For capturing the operation manager detail\",\"id\":\"AXbbyOJWbkY5GD5z7dd-\",\"key\":\"groovytesting\"}}";
		JSONParser parser = new JSONParser();

		Object obj = parser.parse(obj1);
		JSONObject metrics = (JSONObject) obj;
		metrics.put("jobName", "test");
		metrics.put("avgHelth", 90l);
		metrics.put("buildStatus", "SUCCEtSS");
		metrics.put("buildNum", 123l);

		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);
		Mockito.when(iJobInformationRepository.findByAppName("test")).thenReturn(jobInfo);
		Mockito.when(toolFactory.create(1l, 1l)).thenReturn(iTool);
		jenkinsCodeQualityStage.saveStageMetrics(metrics, "test:SUCCESS", 1l, 1l, 1l, 1l, 100l);

	}

	@Test
	public void getStageLogsTest() throws IOException, GenxCICDException {
		

		jenkinsCodeQualityStage.getStageLogs(123l, 1l);

	}
}
