package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class NexusDetailsDTOTest {
	@InjectMocks
	NexusDetailsDTO nexusDetailsDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getNexusUsernameTest() {
		nexusDetailsDTOTest.getNexusUsername();
	}
	@Test
	public void setNexusUsernameTest() {
		nexusDetailsDTOTest.setNexusUsername("setNexusUrl");
	}
	@Test
	public void getNexusPasswordTest() {
		nexusDetailsDTOTest.getNexusPass();
	}
	@Test
	public void setNexusPasswordTest() {
		nexusDetailsDTOTest.setNexusPass("setNexusUrl");
	}
	@Test
	public void getNexusUrlTest() {
		nexusDetailsDTOTest.getNexusUrl();
	}
	@Test
	public void setNexusUrlTest() {
		nexusDetailsDTOTest.setNexusUrl("setNexusUrl");
	}


}
