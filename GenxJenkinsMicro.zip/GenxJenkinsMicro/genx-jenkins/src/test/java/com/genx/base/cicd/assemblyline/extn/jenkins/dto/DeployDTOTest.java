package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DeployDTOTest {
	
	@InjectMocks
	DeployDTO deployDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getJfrogDTOTest() {
		deployDTO.getJfrogDTO();
	}
	@Test
	public void setJfrogDTOTest() {
		deployDTO.setJfrogDTO(new JfrogDTO());
	}
	@Test
	public void getDotNetDTOTest() {
		deployDTO.getDotNetDTO();
	}
	@Test
	public void setDotNetDTOTest() {
		deployDTO.setDotNetDTO(new DotNetDTO());
	}
	@Test
	public void getNexusDetailsDTOTest() {
		deployDTO.getNexusDetailsDTO();
	}
	@Test
	public void setNexusDetailsDTOTest() {
		deployDTO.setNexusDetailsDTO(new NexusDetailsDTO() );
	}
	@Test
	public void getWebLogicDTOTest() {
		deployDTO.getWebLogicDTO();
	}
	@Test
	public void setWebLogicDTOTest() {
		deployDTO.setWebLogicDTO(new WebLogicDTO() );
	}
	@Test
	public void getJobDTOTest() {
		deployDTO.getJobDTO();
	}
	@Test
	public void setJobDTOTest() {
		deployDTO.setJobDTO(new JobDTO() );
	}
	@Test
	public void getSonarDTOTest() {
		deployDTO.getSonarDTO();
	}
	@Test
	public void setSonarDTOTest() {
		deployDTO.setSonarDTO(new SonarDTO() );
	}
	@Test
	public void getDeployJenkinsDTOTest() {
		deployDTO.getDeployJenkinsDTO();
	}
	@Test
	public void setDeployJenkinsDTOTest() {
		deployDTO.setDeployJenkinsDTO(new DeployJenkinsDTO() );
	}
	@Test
	public void getDeployChefDTOTest() {
		deployDTO.getDeployChefDTO();
	}
	@Test
	public void setDeployChefDTOTest() {
		deployDTO.setDeployChefDTO(new DeployChefDTO() );
	}
	@Test
	public void getDeployCloudFoundryDTOTest() {
		deployDTO.getDeployCloudFoundryDTO();
	}
	@Test
	public void setDeployCloudFoundryDTOTest() {
		deployDTO.setDeployCloudFoundryDTO(new DeployCloudFoundryDTO() );
	}
	@Test
	public void getRepositoryDTOTest() {
		deployDTO.getRepositoryDTO();
	}
	@Test
	public void setRepositoryDTOTest() {
		deployDTO.setRepositoryDTO(new RepositoryDTO() );
	}
	@Test
	public void getAwsDeploymentDTOTest() {
		deployDTO.getAwsDeploymentDTO();
	}
	@Test
	public void setAwsDeploymentDTOTest() {
		deployDTO.setAwsDeploymentDTO(new AwsDeploymentDTO() );
	}
	@Test
	public void getDockerInformationDTOTest() {
		deployDTO.getDockerInformationDTO();
	}
	@Test
	public void setDockerInformationDTOTest() {
		deployDTO.setDockerInformationDTO(new DockerInformationDTO() );
	}
	@Test
	public void getKubernetesDTOTest() {
		deployDTO.getKubernetesDTO();
	}
	@Test
	public void setKubernetesDTOTest() {
		deployDTO.setKubernetesDTO(new KubernetesDTO() );
	}
	@Test
	public void getRegistryTypeTest() {
		deployDTO.getRegistryType();
	}
	@Test
	public void setRegistryTypeTest() {
		deployDTO.setRegistryType("setRegistryType");
	}
	@Test
	public void getLambdaFunctionTest() {
		deployDTO.getLambdaFunction();
	}
	@Test
	
	public void getFargateDTOTest() {
		deployDTO.getFargateDTO();
	}
	@Test
	public void setFargateDTOTest() {
		deployDTO.setFargateDTO(new FargateDTO());
	}
	@Test
	public void setLambdaFunctionTest() {
		deployDTO.setLambdaFunction("setLambdaFunction");
	}


}
