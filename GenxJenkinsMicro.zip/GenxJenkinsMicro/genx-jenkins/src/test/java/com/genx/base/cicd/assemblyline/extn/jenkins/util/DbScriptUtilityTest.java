package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.TaskEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeBaseMasterEntity;
import com.capgemini.genx.core.repository.IJenkinsPipelineScriptsRepository;
import com.genx.base.cicd.dto.ApplicationDTO;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.ToolsDTO;

public class DbScriptUtilityTest {
	
	@InjectMocks
	DbScriptUtility dbScriptUtility;
	
	@Mock
	IJenkinsPipelineScriptsRepository iPipelineScriptsRepository;
	
	@Mock
	JenkinsDTOMapUtil jenkinsDtoMapUtil;
	
	@Mock
	IJenkinsCodeBaseMasterEntity iJenkinsCodeBaseMasterEntity;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void pipelineDetailsByToolTest() {
		
		ToolsDTO toolsDto=new ToolsDTO();
		toolsDto.setToolId(7l);
		
		ApplicationDTO appDto=new ApplicationDTO();	
		appDto.setCodeBase("Spring Boot");
		
		JobDTO jobDTO=new JobDTO();
		jobDTO.setApplicationDTO(appDto);
		dbScriptUtility.pipelineDetailsByTool(toolsDto, jobDTO, "StringParam");
	}
	
	@Test
	public void formScriptStringTest() {
		ToolsDTO toolsDto=new ToolsDTO();
		toolsDto.setToolId(7l);
		
		ApplicationDTO appDto=new ApplicationDTO();	
		appDto.setCodeBase("Spring Boot");
		
		JobDTO jobDTO=new JobDTO();
		jobDTO.setApplicationDTO(appDto);
		TaskEntity taskEntity=new TaskEntity();
		taskEntity.setTaskName("stage1");
		taskEntity.setInputs("hello world");
		taskEntity.setJenkinsScriotType("StringParam");
		
		dbScriptUtility.formScriptString(taskEntity, toolsDto, jobDTO);
	}
	
	@Test
	public void getCommonScriptTest() {
		
		dbScriptUtility.getCommonScript();
	}

}
