package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class KubernetesDTOTest {
	@InjectMocks
	KubernetesDTO kubernetesDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getEnvTest() {
		kubernetesDTO.getEnv();
	}
	@Test
	public void setEnvTest() {
		kubernetesDTO.setEnv("getBuildPath");
	}
	@Test
	public void getImageNameTest() {
		kubernetesDTO.getImageName();
	}
	@Test
	public void setImageNameTest() {
		kubernetesDTO.setImageName("getBuildPath");
	}
	@Test
	public void getBucketPathTest() {
		kubernetesDTO.getBucketPath();
	}
	@Test
	public void setBucketPathTest() {
		kubernetesDTO.setBucketPath("getBuildPath");
	}
	@Test
	public void getBuildPathTest() {
		kubernetesDTO.getBuildPath();
	}
	@Test
	public void setBuildPathTest() {
		kubernetesDTO.setBuildPath("setPort");
	}
	@Test
	public void getPortTest() {
		kubernetesDTO.getPort();
	}
	@Test
	public void setPortTest() {
		kubernetesDTO.setPort(80l);
	}


}
