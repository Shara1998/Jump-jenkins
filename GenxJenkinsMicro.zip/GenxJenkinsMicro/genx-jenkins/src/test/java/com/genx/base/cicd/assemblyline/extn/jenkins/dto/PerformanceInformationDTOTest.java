package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PerformanceInformationDTOTest {
	@InjectMocks
	PerformanceInformationDTO performanceInformationDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getJobDTOTest() {
		performanceInformationDTOTest.getJobDTO();
	}
	@Test
	public void setJobDTOTest() {
		performanceInformationDTOTest.setJobDTO(new JobDTO());
	}
	@Test
	public void getJmxFileTest() {
		performanceInformationDTOTest.getJmxFile();
	}
	@Test
	public void setJmxFileTest() {
		performanceInformationDTOTest.setJmxFile("JobDTO");
	}
	@Test
	public void getRepositoryDTOTest() {
		performanceInformationDTOTest.getRepositoryDTO();
	}
	@Test
	public void setRepositoryDTOTest() {
		performanceInformationDTOTest.setRepositoryDTO(new RepositoryDTO());
	}


}
