package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class JfrogDTOTest {
	@InjectMocks
	JfrogDTO jfrogDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getArtifactoryServerUrlTest() {
		jfrogDTO.getArtifactoryServerUrl();
	}
	@Test
	public void setArtifactoryServerUrlTest() {
		jfrogDTO.setArtifactoryServerUrl("setArtifactoryServerUrl");
	}
	@Test
	public void getSshSiteTest() {
		jfrogDTO.getSshSite();
	}
	@Test
	public void setSshSiteTest() {
		jfrogDTO.setSshSite("getPathtoDownload");
	}
	@Test
	public void getPathtoDownloadTest() {
		jfrogDTO.getPathtoDownload();
	}
	@Test
	public void setPathtoDownloadTest() {
		jfrogDTO.setPathtoDownload("getFilestoArchive");
	}
	@Test
	public void getArtifactorypathTest() {
		jfrogDTO.getArtifactorypath();
	}
	@Test
	public void setArtifactorypathTest() {
		jfrogDTO.setArtifactorypath("getFilestoArchive");
	}
	@Test
	public void getJfrogUserNameTest() {
		jfrogDTO.getJfrogUserName();
	}
	@Test
	public void setJfrogUserNameTest() {
		jfrogDTO.setJfrogUserName("getFilestoArchive");
	}
	@Test
	public void getJfrogPasswordTest() {
		jfrogDTO.getJfrogPass();
	}
	@Test
	public void setJfrogPasswordTest() {
		jfrogDTO.setJfrogPass("getFilestoArchive");
	}
	@Test
	public void getFilestoArchiveTest() {
		jfrogDTO.getFilestoArchive();
	}
	@Test
	public void setFilestoArchiveTest() {
		jfrogDTO.setFilestoArchive("setFilestoArchive");
	}

	
	@Test
	public void getTargetReleasesRepositoryTest() {
		jfrogDTO.getTargetReleasesRepository();
	}
	@Test
	public void setTargetReleasesRepositoryTest() {
		jfrogDTO.setTargetReleasesRepository("setTargetSnapshotRepository");
	}
	@Test
	public void getTargetSnapshotRepositoryTest() {
		jfrogDTO.getTargetSnapshotRepository();
	}
	@Test
	public void setTargetSnapshotRepositoryTest() {
		jfrogDTO.setTargetSnapshotRepository("setTargetSnapshotRepository");
	}


}
