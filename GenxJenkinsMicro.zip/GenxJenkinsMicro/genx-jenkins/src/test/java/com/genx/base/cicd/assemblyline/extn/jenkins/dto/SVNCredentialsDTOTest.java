package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SVNCredentialsDTOTest {
	
	@InjectMocks
	SVNCredentialsDTO sVNCredentialsDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getCredentialIdTest() {
		sVNCredentialsDTOTest.getCredentialId();
	}
	@Test
	public void setCredentialIdTest() {
		sVNCredentialsDTOTest.setCredentialId(1l);
	}
	@Test
	public void getSvnCredUserNameTest() {
		sVNCredentialsDTOTest.getSvnCredUserName();
	}
	@Test
	public void setSvnCredUserNameTest() {
		sVNCredentialsDTOTest.setSvnCredUserName("Test");
	}
	@Test
	public void getSvnPassTest() {
		sVNCredentialsDTOTest.getSvnPass();
	}
	@Test
	public void setSvnPassTest() {
		sVNCredentialsDTOTest.setSvnPass("Test");
	}
	@Test
	public void getGitCredUserNameTest() {
		sVNCredentialsDTOTest.getGitCredUserName();
	}
	@Test
	public void setGitCredUserNameTest() {
		sVNCredentialsDTOTest.setGitCredUserName("Test");
	}
	@Test
	public void getGitPassTest() {
		sVNCredentialsDTOTest.getGitPass();
	}
	@Test
	public void setGitPassTest() {
		sVNCredentialsDTOTest.setGitPass("Test");
	}


}
