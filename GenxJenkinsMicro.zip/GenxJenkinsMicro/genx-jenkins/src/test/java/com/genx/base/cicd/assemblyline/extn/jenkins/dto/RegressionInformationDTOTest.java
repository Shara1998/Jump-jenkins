package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class RegressionInformationDTOTest {
	@InjectMocks
	RegressionInformationDTO RegressionInformationDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getRepositoryDTOTest() {
		RegressionInformationDTOTest.getRepositoryDTO();
	}
	@Test
	public void setRepositoryDTOTest() {
		RegressionInformationDTOTest.setRepositoryDTO(new RepositoryDTO());
	}
	@Test
	public void getJobDTOTest() {
		RegressionInformationDTOTest.getJobDTO();
	}
	@Test
	public void setJobDTOTest() {
		RegressionInformationDTOTest.setJobDTO(new JobDTO());
	}
	@Test
	public void getRegressionTypeTest() {
		RegressionInformationDTOTest.getRegressionType();
	}
	@Test
	public void setRegressionTypeTest() {
		RegressionInformationDTOTest.setRegressionType("Test");
	}
	@Test
	public void getTestCasesXmlPathTest() {
		RegressionInformationDTOTest.getTestCasesXmlPath();
	}
	@Test
	public void setTestCasesXmlPath() {
		RegressionInformationDTOTest.setTestCasesXmlPath("setTestCasesXmlPath");
	}
}
