package com.genx.base.cicd.assemblyline.extn.jenkins.exception;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DevOpsEnhancementExceptionTest {
	
	@InjectMocks
	DevOpsEnhancementException devOpsEnhancementException;
	
	
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void devOpsEnhancementExceptionTest1() {
		devOpsEnhancementException=new DevOpsEnhancementException();
	}
	
	@Test
	public void devOpsEnhancementExceptionTest2() {
		devOpsEnhancementException=new DevOpsEnhancementException("error message",new Throwable(),true,true);
	}
	
	@Test
	public void devOpsEnhancementExceptionTest3() {
		devOpsEnhancementException=new DevOpsEnhancementException("error message",new Throwable());
	}
	
	@Test
	public void devOpsEnhancementExceptionTest4() {
		devOpsEnhancementException=new DevOpsEnhancementException("error message");
	}
	@Test
	public void devOpsEnhancementExceptionTest5() {
		devOpsEnhancementException=new DevOpsEnhancementException(new Throwable());
	}

}
