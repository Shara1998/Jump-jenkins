package com.genx.base.cicd.assemblyline.extn.jenkins;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.dashboard.reusable.entity.FlagEntity;
import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsApplicationInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.stages.IStage;
import com.genx.base.cicd.dto.ApplicationDTO;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.ToolsDTO;
import com.genx.base.cicd.exception.GenxCICDException;


public class JenkinsPipelineTest {
	
	@InjectMocks
	JenkinsPipeline jenkinsPipelineTest;
	
	@Mock
	IJenkinsApplicationInformationRepository iApplicationInformationRepository;
	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Mock
	FlagEntity flagEntity;
	
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	
	@Mock
	IStage stagesPipeline;

	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void getBuildLogsTest() throws IOException {
		jenkinsPipelineTest.getBuildLogs(1l);
	}
	
	@Test
	public void generateAdditionalJobConfigTest() {
		jenkinsPipelineTest.generateAdditionalJobConfig();
		
	}
	
	@Test
	public void createToolsTest() throws GenxCICDException {
		
		List<ToolsDTO> toolsDTOs=new ArrayList<>();
		jenkinsPipelineTest.createTools(toolsDTOs, "Jenkins");
	}
	
	@Test
	public void saveTest() throws GenxCICDException {
		
		ApplicationDTO applicationDTO=new ApplicationDTO();
		applicationDTO.setCodeBase("Spring Boot");
		//applicationDTO.setCodeBaseVersion("8");
		applicationDTO.setApplicationType("Microservice");
		//applicationDTO.setReleaseDate(new Date());	
		applicationDTO.setApplicationName("test_application_job");
		
		JobDTO jobDto=new JobDTO();
		jobDto.setApplicationDTO(applicationDTO);
		jobDto.setJobName("test_application");
		jobDto.setJobStyle("Pipeline Jenkins");
		jobDto.setDevopsUserName("automation");
		jobDto.setDevopsPassword("automation@2016");
		jobDto.setComments("hello world");
		jobDto.setBuildTools("MAVEN");
		jobDto.setProfileName("KUBER_UI");
		jobDto.setQualityGateId(1l);
		jobDto.setProfileID(1234l);
		
		GroupHierarchyEntity applicationInformationEntity=new GroupHierarchyEntity();
		JobInformationEntity jobInformationEntity=new JobInformationEntity();
		/*
		 * Mockito.when(iApplicationInformationRepository
		 * .fetchApplicationEntity(jobDto.getApplicationDTO().getApplicationName())).
		 * thenReturn(applicationInformationEntity);
		 */
		Mockito.when(iJobInformationRepository.save(jobInformationEntity)).thenReturn(jobInformationEntity);
		jenkinsPipelineTest.save(jobDto);
		
	}
	
	@Test
	public void createJobTest() {
		JobDTO jobDTO=new JobDTO();
		jobDTO.setJobName("test");
		jobDTO.setProfileType("NON-Multi");
		when(propertyUtil.getEnvProperties("xmlConfigBatchPipeline")).thenReturn("config/CreatePipelineJob.xml");
		when(propertyUtil.getEnvProperties("jenkinsUrl")).thenReturn("url");
		jenkinsPipelineTest.createJob("hello world", jobDTO);
		
	}
	
	@Test
	public void runTest() throws IOException {
		JobDTO jobDTO=new JobDTO();
		jobDTO.setJobName("test");
		JobInformationEntity jobInformationEntity=new JobInformationEntity();
		when(propertyUtil.getEnvProperties("jenkinsUserName")).thenReturn("automation");
		when(propertyUtil.getEnvProperties("jenkinsPassword")).thenReturn("automation@2016");
		when(iJobInformationRepository.findByAppName("test")).thenReturn(jobInformationEntity);
		when(propertyUtil.getEnvProperties("jenkinsUrlbuildPipelineJob")).thenReturn("url");
		jenkinsPipelineTest.run(jobDTO);
	}
	

}
