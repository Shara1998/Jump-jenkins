package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class FargateDTOTest {
	@InjectMocks
	FargateDTO fargateDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getTaskDefListTest() {
		fargateDTO.getTaskDefList();
	}
	@Test
	public void setTaskDefListTest() {
		fargateDTO.setTaskDefList(new ArrayList<>());
	}
	@Test
	public void getMessageDTOTest() {
		fargateDTO.getMessageDTO();
	}
	@Test
	public void setMessageDTOTest() {
		fargateDTO.setMessageDTO(new MessageDTO());
	}	
	@Test
	public void getNameTest() {
		fargateDTO.getName();
	}
@Test
	public void setNameTest() {
		fargateDTO.setName("setName");
	}
@Test
	public void getImageTest() {
		fargateDTO.getImage();
	}
@Test
	public void setImageTest() {
		fargateDTO.setImage("setImage");
	}
@Test
	public void getContainerPortTest() {
		fargateDTO.getContainerPort();
	}
@Test
	public void setContainerPortTest() {
		fargateDTO.setContainerPort("setContainerPort");
	}
@Test
	public void getHostPortTest() {
		fargateDTO.getHostPort();
	}
@Test
	public void setHostPortTest() {
		fargateDTO.setHostPort("setCpu");
	}
@Test
	public void getCpuTest() {
		fargateDTO.getCpu();
	}
@Test
	public void setCpuTest() {
		fargateDTO.setCpu("setCpu");
	}
	@Test
	public void getMemoryTest() {
		fargateDTO.getMemory();
	}
	@Test
	public void setMemoryTest() {
		fargateDTO.setMemory("getTaskVersion");
	}
	@Test
	public void getClusterListTest() {
		fargateDTO.getClusterList();
	}
	@Test
	public void setClusterListTest() {
		fargateDTO.setClusterList(new HashMap<>());
	}
	@Test
	public void getServiceListTest() {
		fargateDTO.getServiceList();
	}
	@Test
	public void setServiceListTest() {
		fargateDTO.setServiceList(new HashMap<>());
	}
	@Test
	public void getTaskNameTest() {
		fargateDTO.getTaskName();
	}
	@Test
	public void setTaskNameTest() {
		fargateDTO.setTaskName("getTaskVersion");
	}
	@Test
	public void getTaskVersionTest() {
		fargateDTO.getTaskVersion();
	}
	@Test
	public void getBaseImageTest() {
		fargateDTO.getBaseImage();
	}
	@Test
	public void setBaseImageTest() {
		fargateDTO.setBaseImage("Test");
	}
	@Test
	public void getTargetTest() {
		fargateDTO.getTarget();
	}
	@Test
	public void setTargetTest() {
		fargateDTO.setTarget("Test");
	}
	@Test
	public void setTaskVersionTest() {
		fargateDTO.setTaskVersion("Test");
	}
	@Test
	public void getClusterNameTest() {
		fargateDTO.getClusterName();
	}
	@Test
	public void setClusterNameTest() {
		fargateDTO.setClusterName("Test");
	}
	@Test
	public void getServiceNameTest() {
		fargateDTO.getServiceName();
	}
	@Test
	public void setServiceNameTest() {
		fargateDTO.setServiceName("setServiceName");
	}


}
