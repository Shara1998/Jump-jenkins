package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StageDTOTest {
	
	@InjectMocks
	StageDTO stageDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getDummyVarTest() {
		stageDTOTest.getDummyVar();
	}
	@Test
	public void setDummyVarTest() {
		stageDTOTest.setDummyVar("setDummyVar");
	}

}
