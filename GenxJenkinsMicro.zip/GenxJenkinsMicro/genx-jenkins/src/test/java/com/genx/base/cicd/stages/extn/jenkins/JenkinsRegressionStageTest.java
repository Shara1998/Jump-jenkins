package com.genx.base.cicd.stages.extn.jenkins;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.ProfileGroupNameEntity;
import com.capgemini.dashboard.reusable.entity.RegressionInformationEntity;
import com.capgemini.dashboard.reusable.entity.RegressionThresholdEntity;
import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.capgemini.dashboard.reusable.entity.YascaThresholdEntity;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupNameRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionThresholdRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.DevOpsWorkFlowUtilNew;
import com.genx.base.cicd.assemblyline.extn.jenkins.util.FetchBuldnumberByStage;
import com.genx.base.cicd.assemblyline.factory.ToolFactory;
import com.genx.base.cicd.assemblyline.tools.ITool;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.exception.GenxCICDException;



public class JenkinsRegressionStageTest {
	
	@InjectMocks
	JenkinsRegressionStage jenkinsRegressionStage;
	
	@Mock
	JobDTO jobDTO;
	
	@Mock
	ToolFactory toolFactory;
	
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;
	
	@Mock
	IJenkinsRegressionInformationRepository iJenkinsRegressionInformationRepository;
	
	@Mock
	IJenkinsRegressionThresholdRepository iJenkinsRegressionThresholdRepository;
	
	@Mock
	IJenkinsProfileGroupNameRepository iJenkinsProfileGroupNameRepository;
	
	@Mock
	ITool iTool;
	@Mock
	EnvironmentServiceImplNew propertyUtil;
	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;
	@Mock
	FetchBuldnumberByStage fetchBuldnumberByStage;
	
		@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Mock
	com.genx.base.cicd.assemblyline.extn.jenkins.util.JenkinsBuildStageUtil jenkinsBuildStageUtil;

	
	@Test
	public void buildStageTest() {
		
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);
		
		
		Mockito.when(iJobInformationRepository.findByAppName(null)).thenReturn(jobInfo);
		jenkinsRegressionStage.buildStage();
	}
	
	@Test
	public void saveStageMetricsTest() throws GenxCICDException {
		
		JSONObject metrics= new JSONObject();
		metrics.put("jobName", "test");
		metrics.put("buildNum", "1");
		metrics.put("buildStatus", "SUCCESS");
		
		Mockito.when(toolFactory.create(1l, 7l)).thenReturn(iTool);
		
		jenkinsRegressionStage.saveStageMetrics(metrics,"test:SUCCESS",1l,1l,4l,7l,100l);
		
	}
	
	@Test
	public void compareMetricsWithThresholdTest() throws GenxCICDException {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setGroupId("kuber_ui");
		jobInfo.setJobId(1234l);
		
		RegressionInformationEntity regressionInformationEntity = new RegressionInformationEntity();
		regressionInformationEntity.setRegressionBuildStatus("SUCCESS");
		regressionInformationEntity.setTotalTestcases(10);
		regressionInformationEntity.setRegressionPassCount(10);
		ProfileGroupNameEntity profileGroupNameEntity=new ProfileGroupNameEntity();
		profileGroupNameEntity.setProfileGroupNameId(1234l);
		RegressionThresholdEntity regressionThresholdEntity=new RegressionThresholdEntity();
		
		regressionThresholdEntity.setRegGoodLevelPercentage(80);
		regressionThresholdEntity.setRegRiskLevelPercentage(30);
		Mockito.when(iJobInformationRepository.findByAppName("test")).thenReturn(jobInfo);
		Mockito.when(toolFactory.create(1l, 7l)).thenReturn(iTool);
		Mockito.when(iJenkinsRegressionInformationRepository
				.getRegressionEntityByJobId(jobInfo.getJobId())).thenReturn(regressionInformationEntity);
		Mockito.when(iJenkinsProfileGroupNameRepository.findByProfileName(jobInfo.getGroupId())).thenReturn(profileGroupNameEntity);
		Mockito.when(iJenkinsRegressionThresholdRepository.fetchregthreshold(profileGroupNameEntity.getProfileGroupNameId(), 7l)).thenReturn(regressionThresholdEntity);
		jenkinsRegressionStage.compareMetricsWithThreshold("test", 1l, "SUCCESS", 1l, 7l);	

	}

	@Test
	public void getStageLogsTest() throws IOException, GenxCICDException {
		

		jenkinsRegressionStage.getStageLogs(123l, 1l);

	}
	

}
