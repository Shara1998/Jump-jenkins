package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class AwsDeploymentDTOTest {
	@InjectMocks
	AwsDeploymentDTO awsDeploymentDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getAwsDeploymentIdTest() {
		awsDeploymentDTO.getAwsDeploymentId();
	}
	@Test
	public void setAwsDeploymentIdTest() {
		awsDeploymentDTO.setAwsDeploymentId(1l);
	}
	@Test
	public void getAwsApplicationNameTest() {
		awsDeploymentDTO.getAwsApplicationName();
	}
	@Test
	public void setAwsApplicationName() {
		awsDeploymentDTO.getAwsApplicationName();
	}
	@Test
	public void getAwsApplicationGroupNameTest() {
		awsDeploymentDTO.getAwsApplicationGroupName();
	}
	@Test
	public void setAwsApplicationGroupNameTest() {
		awsDeploymentDTO.setAwsApplicationGroupName("setAwsApplicationGroupName");
	}
	@Test
	public void getAwsCodeDeploymentConfigTest() {
		awsDeploymentDTO.getAwsCodeDeploymentConfig();
	}
	@Test
	public void setAwsCodeDeploymentConfigTest() {
		awsDeploymentDTO.setAwsCodeDeploymentConfig("setAwsCodeDeploymentConfig");
	}
	@Test
	public void getAwsRegionTest() {
		awsDeploymentDTO.getAwsRegion();
	}
	@Test
	public void setAwsRegion() {
		awsDeploymentDTO.getAwsRegion();
	}
	@Test
	public void getAwsBucketTest() {
		awsDeploymentDTO.getAwsBucket();
	}
	@Test
	public void setAwsBucketTest() {
		awsDeploymentDTO.setAwsBucket("setAwsBucket");
	}
	@Test
	public void getAwsPrefixTest() {
		awsDeploymentDTO.getAwsPrefix();
	}
	@Test
	public void setAwsPrefixTest() {
		awsDeploymentDTO.setAwsPrefix("setAwsPrefix");
	}
	@Test
	public void getAwsUseAccesskeyTest() {
		awsDeploymentDTO.getAwsUseAccesskey();
	}
	@Test
	public void setAwsUseAccesskeyTest() {
		awsDeploymentDTO.getAwsUseAccesskey();
	}
	@Test
	public void getAccessKeyTest() {
		awsDeploymentDTO.getAccessKey();
	}
	@Test
	public void setAccessKeyTest() {
		awsDeploymentDTO.setAccessKey("setAccessKey");
	}
	@Test
	public void getSecretKeyTest() {
		awsDeploymentDTO.getSecretKey();
	}
	@Test
	public void setSecretKeyTest() {
		awsDeploymentDTO.setSecretKey("setSecretKey");
	}
	@Test
	public void getJobDTOTest() {
		awsDeploymentDTO.getJobDTO();
	}
	@Test
	public void setJobDTOTest() {
		awsDeploymentDTO.setJobDTO(new JobDTO());
	}
	@Test
	public void getAwsRegistryURLTest() {
		awsDeploymentDTO.getAwsRegistryURL();
	}
	@Test
	public void setAwsRegistryURLTest() {
		awsDeploymentDTO.setAwsRegistryURL("setAwsRegistryURL");
	}


}
