package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class MessageDTOTest {
	
	@InjectMocks
	MessageDTO messageDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getSvnUserNameTest() {
		messageDTOTest.getSvnUserName();
	}
	@Test
	public void setSvnUserNameTest() {
		messageDTOTest.setSvnUserName("messageDTOTest");
	}
	@Test
	public void getSvnPasswordTest() {
		messageDTOTest.getSvnPass();
	}
	@Test
	public void setSvnPasswordTest() {
		messageDTOTest.setSvnPass("messageDTOTest");
	}
	@Test
	public void getJobNameTest() {
		messageDTOTest.getJobName();
	}
	@Test
	public void setJobNameTest() {
		messageDTOTest.setJobName("setJobId");
	}
	@Test
	public void getPreviousStageTest() {
		messageDTOTest.getPreviousStage();
	}
	@Test
	public void setPreviousStageTest() {
		messageDTOTest.setPreviousStage("setJobId");
	}
	@Test
	public void getCurrentStageTest() {
		messageDTOTest.getCurrentStage();
	}
	@Test
	public void setCurrentStageTest() {
		messageDTOTest.setCurrentStage("setJobId");
	}
	@Test
	public void getNextStageTest() {
		messageDTOTest.getNextStage();
	}
	@Test
	public void setNextStageTest() {
		messageDTOTest.setNextStage("setJobId");
	}
	@Test
	public void getJobIdTest() {
		messageDTOTest.getJobId();
	}
	@Test
	public void setJobIdTest() {
		messageDTOTest.setJobId(1l);
	}
	@Test
	public void getSourceCodeTest() {
		messageDTOTest.getSourceCode();
	}
	@Test
	public void setSourceCodeTest() {
		messageDTOTest.setSourceCode("getMessage");
	}
	@Test
	public void getProjectIdTest() {
		messageDTOTest.getProjectId();
	}
	@Test
	public void setProjectIdTest() {
		messageDTOTest.setProjectId("getMessage");
	}
	@Test
	public void getIdTest() {
		messageDTOTest.getId();
	}
	@Test
	public void setIdTest() {
		messageDTOTest.setId(1);
	}
	@Test
	public void getStatusTest() {
		messageDTOTest.getStatus();
	}
	@Test
	public void setStatusTest() {
		messageDTOTest.setStatus(1);
	}
	@Test
	public void getMessageTest() {
		messageDTOTest.getMessage();
	}
	@Test
	public void setMessage() {
		messageDTOTest.setMessage("setMessage");
	}
	@Test
	public void getGitUserName() {
		messageDTOTest.getGitUserName();
	}
	@Test
	public void setGitUserName() {
		messageDTOTest.setGitUserName("setAppType");
	}
	@Test
	public void getGitPassword() {
		messageDTOTest.getGitPass();
	}
	@Test
	public void setGitPassword() {
		messageDTOTest.setGitPass("setAppType");
	}
	@Test
	public void getAppType() {
		messageDTOTest.getAppType();
	}
	@Test
	public void setAppType() {
		messageDTOTest.setAppType("setAppType");
	}

}
