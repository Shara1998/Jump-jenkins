package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class IstanbulDTOTest {
	@InjectMocks
	IstanbulDTO istanbulDTO;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetReportContent() {
		istanbulDTO.getReportContent();
	}


	@Test
	public void testGetReportContentType() {
		istanbulDTO.getReportContentType();

	}

	@Test
	public void testSetReportContentType() {
		istanbulDTO.setReportContentType("SetReportContentType");
	}

	@Test
	public void testGetStatements() {
		istanbulDTO.getStatements();
	}

	@Test
	public void testSetStatements() {
		istanbulDTO.setStatements("SetStatements");
	}

	@Test
	public void testGetBranches() {
		istanbulDTO.getBranches();
	}

	@Test
	public void testSetBranches() {
		istanbulDTO.setBranches("SetBranches");
	}

	@Test
	public void testGetFunctions() {
		istanbulDTO.getFunctions();
	}

	@Test
	public void testSetFunctions() {
		istanbulDTO.setFunctions("SetFunctions");
	}

	@Test
	public void testGetLines() {
		istanbulDTO.getLines();
	}

	@Test
	public void testSetLines() {
		istanbulDTO.setLines("SetLines");
	}

}
