package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DeployJenkinsDTOTest {
	@InjectMocks
	DeployJenkinsDTO deployJenkinsDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getjBossHostNameTest() {
		deployJenkinsDTO.getjBossHostName();
	}
	@Test
	public void setjBossHostNameTest() {
		deployJenkinsDTO.setjBossHostName("setjBossHostName");
	}
	@Test
	public void getjBossPortTest() {
		deployJenkinsDTO.getjBossPort();
	}
	@Test
	public void setjBossPortTest() {
		deployJenkinsDTO.setjBossPort("setjBossPort");
	}
	@Test
	public void getServerGroupTest() {
		deployJenkinsDTO.getServerGroup();
	}
	@Test
	public void setServerGroupTest() {
		deployJenkinsDTO.setServerGroup("getTomcatUserName");
	}
	@Test
	public void getTomcatUserNameTest() {
		deployJenkinsDTO.getTomcatUserName();
	}
	@Test
	public void setTomcatUserNameTest() {
		deployJenkinsDTO.setTomcatUserName("getTomcatPassword");
	}
	@Test
	public void getTomcatPasswordTest() {
		deployJenkinsDTO.getTomcatPass();
	}
	@Test
	public void setTomcatPasswordTest() {
		deployJenkinsDTO.setTomcatPass("tomcatPassword");
	}
	@Test
	public void getTomcatUrlTest() {
		deployJenkinsDTO.getTomcatUrl();
	}
	@Test
	public void setTomcatUrlTest() {
		deployJenkinsDTO.setTomcatUrl("setTomcatUrl");
	}
	@Test
	public void getNormalServerTypeTest() {
		deployJenkinsDTO.getNormalServerType();
	}
	@Test
	public void setNormalServerTypeTest() {
		deployJenkinsDTO.setNormalServerType("setTomcatUrl");
	}
	@Test
	public void getjBossUserNameTest() {
		deployJenkinsDTO.getjBossUserName();
	}
	@Test
	public void setjBossUserNameTest() {
		deployJenkinsDTO.setjBossUserName("setTomcatUrl");
	}
	@Test
	public void getjBossPasswordTest() {
		deployJenkinsDTO.getjBossPass();
	}
	@Test
	public void setjBossPasswordTest() {
		deployJenkinsDTO.setjBossPass("setTomcatUrl");
	}
	@Test
	public void getjBossUrlTest() {
		deployJenkinsDTO.getjBossUrl();
	}
	@Test
	public void setjBossUrlTest() {
		deployJenkinsDTO.setjBossUrl("setTomcatUrl");
	}
	@Test
	public void getNormalWAREARFilesTest() {
		deployJenkinsDTO.getNormalWAREARFiles();
	}
	@Test
	public void setNormalWAREARFilesTest() {
		deployJenkinsDTO.setNormalWAREARFiles("setTomcatUrl");
	}
	@Test
	public void getNormalContextPathTest() {
		deployJenkinsDTO.getNormalContextPath();
	}
	@Test
	public void setNormalContextPathTest() {
		deployJenkinsDTO.setNormalContextPath("setNormalContextPath");
	}


}
