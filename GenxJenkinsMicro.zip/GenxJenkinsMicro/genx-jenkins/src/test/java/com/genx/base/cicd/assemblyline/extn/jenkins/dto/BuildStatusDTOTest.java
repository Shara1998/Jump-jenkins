package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BuildStatusDTOTest {
	
	@InjectMocks
	BuildStatusDTO buildStatusDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getBuildStatusTest() {
		buildStatusDTO.getBuildStatus();
	}
	@Test
	public void setBuildStatusTest() {
		buildStatusDTO.setBuildStatus("buildStatus");
	}
	

}
