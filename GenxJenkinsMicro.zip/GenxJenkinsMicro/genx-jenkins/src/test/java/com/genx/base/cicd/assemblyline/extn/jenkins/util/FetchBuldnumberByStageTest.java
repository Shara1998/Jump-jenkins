package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.dashboard.reusable.entity.CodeQualityInformationEntity;
import com.capgemini.dashboard.reusable.entity.DeployJobEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;
import com.capgemini.dashboard.reusable.entity.PerformanceInformationEntity;
import com.capgemini.dashboard.reusable.entity.RegressionInformationEntity;
import com.capgemini.dashboard.reusable.entity.YascaInformationEntity;
import com.capgemini.genx.core.repository.IJenkinsCodeQualityInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsDeployJobRepo;
import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRegressionInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsYascaJobRepository;
import com.genx.base.cicd.assemblyline.extn.jenkins.serviceimpl.EnvironmentServiceImplNew;

public class FetchBuldnumberByStageTest {
	@InjectMocks
	FetchBuldnumberByStage buldnumberByStage;

	@Mock
	IJenkinsCodeQualityInformationRepository iCodeQualityInformationRepository;

	@Mock
	IJenkinsYascaJobRepository iYascaInformationRepository;

	@Mock
	IJenkinsPerformanceInformationRepository iPerformanceInformationRepository;

	@Mock
	IJenkinsRegressionInformationRepository iRegressionInformationRepository;

	@Mock
	IJenkinsDeployJobRepo deployJobRepo;
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Mock
	EnvironmentServiceImplNew propertyUtil;

	@Mock
	DevOpsWorkFlowUtilNew devOpsWorkFlowUtil;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetLatestBuildNumber() {

		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);

		Mockito.when(iJobInformationRepository.getJobsByJobId(1234l)).thenReturn(jobInfo);

		CodeQualityInformationEntity codeQualityInformationEntity = new CodeQualityInformationEntity();
		Mockito.when(iCodeQualityInformationRepository.getCodeQualEntityByJobId(1234l))
				.thenReturn(codeQualityInformationEntity);
		Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole")).thenReturn("stringurl");
		codeQualityInformationEntity.setBuildNumber(123l);
		buldnumberByStage.fetchStageLogs(1234l, "CodeQuality");
	}

	@Test
	public void testGetLatestBuildNumber2() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(126l);

		Mockito.when(iJobInformationRepository.getJobsByJobId(126l)).thenReturn(jobInfo);
		YascaInformationEntity yascaInformationEntity = new YascaInformationEntity();
		Mockito.when(iYascaInformationRepository.getYascaEntityByJobId(126l)).thenReturn(yascaInformationEntity);
		Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole")).thenReturn("stringurl");
		yascaInformationEntity.setBuildNumberYasca(1261l);
		buldnumberByStage.fetchStageLogs(126l, "SAST");
	}

	@Test
	public void testGetLatestBuildNumbeiPerformanceInformationRepositoryr3() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);

		Mockito.when(iJobInformationRepository.getJobsByJobId(127l)).thenReturn(jobInfo);

		PerformanceInformationEntity performanceInformationEntity = new PerformanceInformationEntity();
		Mockito.when(iPerformanceInformationRepository.getPerformanceEntityByJobId(127l))
				.thenReturn(performanceInformationEntity);
		Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole")).thenReturn("stringurl");
		performanceInformationEntity.setBuildNumber(127l);
		buldnumberByStage.fetchStageLogs(127l, "Performance");
	}

	@Test
	public void testGetLatestBuildNumber4() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);

		Mockito.when(iJobInformationRepository.getJobsByJobId(129l)).thenReturn(jobInfo);

		RegressionInformationEntity regressionInformationEntity = new RegressionInformationEntity();
		Mockito.when(iRegressionInformationRepository.getRegressionEntityByJobId(129l))
				.thenReturn(regressionInformationEntity);
		Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole")).thenReturn("stringurl");
		regressionInformationEntity.setBuildNumberRegression(129l);
		buldnumberByStage.fetchStageLogs(129l, "Regression");

	}

	@Test
	public void testGetLatestBuildNumber5() {
		JobInformationEntity jobInfo = new JobInformationEntity();
		jobInfo.setJenkinsUsername("automation");
		jobInfo.setJenkinsPass("automation@2016");
		jobInfo.setJobName("test_cases_job1");
		jobInfo.setJobId(1234l);

		Mockito.when(iJobInformationRepository.getJobsByJobId(1235l)).thenReturn(jobInfo);

		DeployJobEntity deployJobEntity = new DeployJobEntity();
		Mockito.when(deployJobRepo.getDeployJobEntityByJobId(1235l)).thenReturn(deployJobEntity);
		Mockito.when(propertyUtil.getEnvProperties("jenkinsUrlpipelineConsole")).thenReturn("stringurl");
		deployJobEntity.setBuildNumberDeploy(1235l);
		buldnumberByStage.fetchStageLogs(1235l, "Deployment");
	}

}
