package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.genx.base.cicd.dto.ToolsDTO;



public class JenkinsDTOMapUtilTest {
	
	@InjectMocks
	JenkinsDTOMapUtil jenkinsDTOMapUtil;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test(expected = NoClassDefFoundError.class)
	public void dtoMapConversionTest() {
		
		ToolsDTO toolsDto=new ToolsDTO();
		
		toolsDto.setCodeBaseName("springboot");
		
		jenkinsDTOMapUtil.dtoMapConversion(toolsDto);
		
	}

}
