package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class AppDetails2DTOTest {
	
	@InjectMocks
	AppDetails2DTO appDetails2DTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void isExceptionFlagTest() {
		appDetails2DTO.isExceptionFlag();
	}
	@Test
	public void setExceptionFlagTest() {
		appDetails2DTO.setExceptionFlag(true);
	}
	@Test
	public void isProfileFlagTest() {
		appDetails2DTO.isProfileFlag();
	}
	@Test
	public void setProfileFlagTest() {
		appDetails2DTO.setProfileFlag(true);
	}
	@Test
	public void isFirstTimeTest() {
		appDetails2DTO.isFirstTime();
	}
	@Test
	public void setFirstTimeTest() {
		appDetails2DTO.setFirstTime(true);
	}
	@Test
	public void getLastBuildDateTest() {
		appDetails2DTO.getLastBuildDate();
	}
	@Test
	public void setLastBuildDateTest() {
		appDetails2DTO.setLastBuildDate(new Date());
	}
	@Test
	public void getSeriesDTOsTest() {
		appDetails2DTO.getSeriesDTOs();
	}
	@Test
	public void setSeriesDTOsTest() {
		appDetails2DTO.setSeriesDTOs(new ArrayList<>());
	}
	@Test
	public void getJobNameTest() {
		appDetails2DTO.getJobName();
	}
	@Test
	public void setJobNameTest() {
		appDetails2DTO.setJobName("test");
	}
	@Test
	public void getJobIdTest() {
		appDetails2DTO.getJobId();
	}
	@Test
	public void setJobIdTest() {
		appDetails2DTO.setJobId(1234l);
	}	
	@Test
	public void getCountTest() {
		appDetails2DTO.getCount();
	}
	@Test
	public void setCountTest() {
		appDetails2DTO.setCount(1l);
	}
	@Test
	public void getTitleTest() {
		appDetails2DTO.getTitle();
	}
	@Test
	public void setTitleTest() {
		appDetails2DTO.setTitle("title");
	}
	@Test
	public void getTypeTest() {
		appDetails2DTO.getType();
	}
	@Test
	public void setTypeTest() {
		appDetails2DTO.setType("type");
	}
	@Test
	public void isFlagTest() {
		appDetails2DTO.isFlag();
	}
	@Test
	public void setFlagTest() {
		appDetails2DTO.setFlag(false);
	}
	@Test
	public void getBuildStatus() {
		appDetails2DTO.getBuildStatus();
	}
	@Test
	public void setBuildStatus() {
		appDetails2DTO.setBuildStatus("buildStatus");
	}
	@Test
	public void isOtpDeployedTest() {
		appDetails2DTO.isOtpDeployed();
	}
	@Test
	public void setOtpDeployedTest() {
		appDetails2DTO.setOtpDeployed(true);
	}
	@Test
	public void getProfileIdTest() {
		appDetails2DTO.getProfileId();
	}	
	@Test
	public void setProfileIdTest() {
		appDetails2DTO.setProfileId(1l);
	}
	@Test
	public void getJobStyleTest() {
		appDetails2DTO.getJobStyle();
	}
	@Test
	public void setJobStyleTest() {
		appDetails2DTO.setJobStyle("setJobStyle");
	}
	@Test
	public void getBenchMarkTest() {
		appDetails2DTO.getBenchMark();
	}
	@Test
	public void setBenchMarkTest() {
		appDetails2DTO.setBenchMark("setBenchMark");
	}


}
