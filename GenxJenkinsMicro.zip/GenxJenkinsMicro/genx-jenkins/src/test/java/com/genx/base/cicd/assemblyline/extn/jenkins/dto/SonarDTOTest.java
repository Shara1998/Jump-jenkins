package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SonarDTOTest {
	@InjectMocks
	SonarDTO sonarDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getScriptTypeTest() {
		sonarDTOTest.getScriptType();
	}
	@Test
	public void setScriptTypeTest() {
		sonarDTOTest.setScriptType("setDeployType");
	}
	@Test
	public void getLoginDTOTest() {
		sonarDTOTest.getLoginDTO();
	}
	@Test
	public void setLoginDTOTest() {
		sonarDTOTest.setLoginDTO(new LoginDTO());
	}
	@Test
	public void getDeployTypeTest() {
		sonarDTOTest.getDeployType();
	}
	@Test
	public void setDeployTypeTest() {
		sonarDTOTest.setDeployType("LoginDTO");
	}
	@Test
	public void getProjectDTOTest() {
		sonarDTOTest.getProjectDTO();
	}
	@Test
	public void setProjectDTOTest() {
		sonarDTOTest.setProjectDTO(new ProjectDTO());
	}
	@Test
	public void getJobDTOTest() {
		sonarDTOTest.getJobDTO();
	}
	@Test
	public void setJobDTOTest() {
		sonarDTOTest.setJobDTO(new JobDTO());
	}
	@Test
	public void getApplicationDTOTest() {
		sonarDTOTest.getApplicationDTO();
	}
	@Test
	public void setApplicationDTOTest() {
		sonarDTOTest.setApplicationDTO(new ApplicationDTO());
	}
	@Test
	public void getRepositoryDTOTest() {
		sonarDTOTest.getRepositoryDTO();
	}
	@Test
	public void setRepositoryDTOTest() {
		sonarDTOTest.setRepositoryDTO(new RepositoryDTO());
	}
	@Test
	public void getSvnCredentialsDTOTest() {
		sonarDTOTest.getSvnCredentialsDTO();
	}
	@Test
	public void setSvnCredentialsDTOTest() {
		sonarDTOTest.setSvnCredentialsDTO(new SVNCredentialsDTO());
	}
	@Test
	public void getProfileNameTest() {
		sonarDTOTest.getProfileName();
	}
	@Test
	public void setProfileNameTest() {
		sonarDTOTest.setProfileName("setProfileName");
	}
	@Test
	public void getArtifactIDTest() {
		sonarDTOTest.getArtifactID();
	}
	@Test
	public void setArtifactIDTest() {
		sonarDTOTest.setArtifactID("setStreamName");
	}
	@Test
	public void getGroupIDTest() {
		sonarDTOTest.getGroupID();
	}
	@Test
	public void setGroupIDTest() {
		sonarDTOTest.setGroupID("setStreamName");
	}
	@Test
	public void getStreamNameTest() {
		sonarDTOTest.getStreamName();
	}
	@Test
	public void setStreamNameTest() {
		sonarDTOTest.setStreamName("setStreamName");
	}


}
