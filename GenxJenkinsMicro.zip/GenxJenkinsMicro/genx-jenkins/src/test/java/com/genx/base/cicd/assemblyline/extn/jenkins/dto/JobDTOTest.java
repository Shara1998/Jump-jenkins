package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class JobDTOTest {
	@InjectMocks
	JobDTO jobDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getQualityGateIdTest() {
		jobDTO.getQualityGateId();
	}
	@Test
	public void setQualityGateIdTest() {
		jobDTO.setQualityGateId(1l);
	}
	@Test
	public void getAppDetails2DTOsTest() {
		jobDTO.getAppDetails2DTOs();
	}
	@Test
	public void setAppDetails2DTOsTest() {
		jobDTO.setAppDetails2DTOs(new ArrayList<>());
	}
	@Test
	public void getOverallStatusTest() {
		jobDTO.getOverallStatus();
	}
	@Test
	public void setOverallStatusTest() {
		jobDTO.setOverallStatus(40d);
	}
	@Test
	public void getCodeBaseTest() {
		jobDTO.getCodeBase();
	}
	@Test
	public void setCodeBaseTest() {
		jobDTO.setCodeBase("setApplicationType");
	}
	@Test
	public void getJobStatusTest() {
		jobDTO.getJobStatus();
	}
	@Test
	public void setJobStatusTest() {
		jobDTO.setJobStatus("setApplicationType");
	}
	@Test
	public void getApplicationTypeTest() {
		jobDTO.getApplicationType();
	}
	@Test
	public void setApplicationTypeTest() {
		jobDTO.setApplicationType("setApplicationType");
	}
	@Test
	public void getReleaseDateTest() {
		jobDTO.getReleaseDate();
	}
	@Test
	public void setReleaseDateTest() {
		jobDTO.setReleaseDate(new Date());
	}
	@Test
	public void getUserNameTest() {
		jobDTO.getUserName();
	}
	@Test
	public void setUserNameTest() {
		jobDTO.setUserName("Test");
	}
	@Test
	public void getCodeBaseVersionTest() {
		jobDTO.getCodeBaseVersion();
	}
	@Test
	public void setCodeBaseVersionTest() {
		jobDTO.setCodeBaseVersion("Test");
	}
	@Test
	public void getBuildToolsTest() {
		jobDTO.getBuildTools();
	}
	@Test
	public void setBuildToolsTest() {
		jobDTO.setBuildTools("Test");
	}
	@Test
	public void getCommentsTest() {
		jobDTO.getComments();
	}
	@Test
	public void setCommentsTest() {
		jobDTO.setComments("Test");
	}
	@Test
	public void getJobIdTest() {
		jobDTO.getJobId();
	}
	@Test
	public void setJobIdTest() {
		jobDTO.setJobId(1l);
	}
	@Test
	public void getJobNameTest() {
		jobDTO.getJobName();
	}
	@Test
	public void setJobNameTest() {
		jobDTO.setJobName("Test");
	}
	@Test
	public void getJobTypeTest() {
		jobDTO.getJobType();
	}
	@Test
	public void setJobTypeTest() {
		jobDTO.setJobType("Test");
	}
	@Test
	public void getJenkinsUserNameTest() {
		jobDTO.getJenkinsUserName();
	}
	@Test
	public void getJobStyleTest() {
		jobDTO.getJobStyle();
	}
	@Test
	public void setJobStyleTest() {
		jobDTO.setJobStyle("Test");
	}
	@Test
	public void setJenkinsUserNameTest() {
		jobDTO.setJenkinsUserName("Test");
	}
	@Test
	public void getJenkinsPasswordTest() {
		jobDTO.getJenkinsPass();
	}
	@Test
	public void setJenkinsPasswordTest() {
		jobDTO.setJenkinsPass("Test");
	}
	@Test
	public void getGroupIdTest() {
		jobDTO.getGroupId();
	}
	@Test
	public void setGroupIdTest() {
		jobDTO.setGroupId("kuber_ui");
	}
	@Test
	public void getGroupDTOsTest() {
		jobDTO.getGroupDTOs();
	}
	@Test
	public void setGroupDTOsTest() {
		jobDTO.setGroupDTOs(new ArrayList<>());
	}
	@Test
	public void getJobActiveTest() {
		jobDTO.getJobActive();
	}
	@Test
	public void setJobActiveTest() {
		jobDTO.setJobActive(true);
	}


}
