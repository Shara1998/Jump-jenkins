package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class WebLogicDTOTest {
	
	@InjectMocks
	WebLogicDTO webLogicDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getServerUrlTest() {
		webLogicDTOTest.getServerUrl();
	}
	@Test
	public void setServerUrlTest() {
		webLogicDTOTest.setServerUrl("setWebLogicId");
	}
	@Test
	public void getWeblogicPasswordTest() {
		webLogicDTOTest.getWeblogicPass();
	}
	@Test
	public void setWeblogicPasswordTest() {
		webLogicDTOTest.setWeblogicPass("setWebLogicId");
	}
	@Test
	public void getWeblogicUserNameTest() {
		webLogicDTOTest.getWeblogicUserName();
	}
	@Test
	public void setWeblogicUserNameTest() {
		webLogicDTOTest.setWeblogicUserName("setWebLogicId");
	}
	@Test
	public void getWebLogicIdTest() {
		webLogicDTOTest.getWebLogicId();
	}
	@Test
	public void getWarFileNameTest() {
		webLogicDTOTest.getWarFileName();
	}
	@Test
	public void setWarFileNameTest() {
		webLogicDTOTest.setWarFileName("setWebLogicId");
	}
	@Test
	public void setWebLogicIdTest() {
		webLogicDTOTest.setWebLogicId(1l);
	}

}
