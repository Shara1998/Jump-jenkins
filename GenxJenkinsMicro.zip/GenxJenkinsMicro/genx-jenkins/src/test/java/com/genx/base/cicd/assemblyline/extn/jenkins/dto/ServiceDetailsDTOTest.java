package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ServiceDetailsDTOTest {
	
	@InjectMocks
	ServiceDetailsDTO serviceDetailsDTOTest;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getServiceDetailsIdTest() {
		serviceDetailsDTOTest.getServiceDetailsId();
	}
	@Test
	public void setServiceDetailsIdTest() {
		serviceDetailsDTOTest.setServiceDetailsId(1l);
	}
	@Test
	public void getServiceTypeTest() {
		serviceDetailsDTOTest.getServiceType();
	}
	@Test
	public void setServiceTypeTest() {
		serviceDetailsDTOTest.setServiceType("setServicePlan");
	}
	@Test
	public void getServicePlanTest() {
		serviceDetailsDTOTest.getServicePlan();
	}
	@Test
	public void setServicePlanTest() {
		serviceDetailsDTOTest.setServicePlan("setServicePlan");
	}
	@Test
	public void getSeviceName() {
		serviceDetailsDTOTest.getSeviceName();
	}
	@Test
	public void setSeviceName() {
		serviceDetailsDTOTest.setSeviceName("setSeviceName");
	}


}
