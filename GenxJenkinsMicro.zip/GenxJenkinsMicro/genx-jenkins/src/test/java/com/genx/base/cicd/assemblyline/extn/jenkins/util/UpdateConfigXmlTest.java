package com.genx.base.cicd.assemblyline.extn.jenkins.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPathExpressionException;

import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.capgemini.dashboard.reusable.entity.GroupHierarchyEntity;
import com.capgemini.dashboard.reusable.entity.JobInformationEntity;

import com.capgemini.genx.core.repository.IJenkinsJobInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsKubernetesRepository;
import com.capgemini.genx.core.repository.IJenkinsPerformanceInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsProfileGroupRepository;
import com.capgemini.genx.core.repository.IJenkinsProjectInformationRepository;
import com.capgemini.genx.core.repository.IJenkinsRepositoryDetailsRepository;
import com.genx.base.cicd.dto.ApplicationDTO;
import com.genx.base.cicd.dto.IPipelineDTO;
import com.genx.base.cicd.dto.JobDTO;
import com.genx.base.cicd.dto.PipelineDTO;
import com.genx.base.cicd.dto.StageDTO;

public class UpdateConfigXmlTest {

	@InjectMocks
	UpdateConfigXml configXml;
	@Mock
	IJenkinsJobInformationRepository iJobInformationRepository;

	@Mock
	IJenkinsPerformanceInformationRepository iJenkinsPerformanceInformationRepository;

	@Mock
	IJenkinsRepositoryDetailsRepository iJenkinsRepositoryDetailsRepository;

	@Mock
	IJenkinsProfileGroupRepository iJenkinsProfileGroupRepository;

	@Mock
	IJenkinsProjectInformationRepository jenkinsProjectInformationRepository;

	@Mock
	IJenkinsKubernetesRepository iJenkinsKubernetesRepository;

	@Mock
	IJenkinsJobInformationRepository iJenkinsJobInformationRepository;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetUpdatedXmlString() {
		String jobConfig = "<flow-definition plugin=\"workflow-job@2.32\">\r\n" + "<actions>\r\n"
				+ "<org.jenkinsci.plugins.pipeline.modeldefinition.actions.DeclarativeJobAction plugin=\"pipeline-model-definition@1.3.8\"/>\r\n"
				+ "<org.jenkinsci.plugins.pipeline.modeldefinition.actions.DeclarativeJobPropertyTrackerAction plugin=\"pipeline-model-definition@1.3.8\">\r\n"
				+ "<jobProperties/>\r\n" + "<triggers/>\r\n" + "<parameters/>\r\n" + "<options/>\r\n"
				+ "</org.jenkinsci.plugins.pipeline.modeldefinition.actions.DeclarativeJobPropertyTrackerAction>\r\n"
				+ "</actions>\r\n" + "<description/>\r\n" + "<keepDependencies>false</keepDependencies>\r\n"
				+ "<properties>\r\n" + "<hudson.model.ParametersDefinitionProperty>\r\n" + "<parameterDefinitions>\r\n"
				+ "<hudson.model.StringParameterDefinition>\r\n" + "<name>SoapUI_Filepath</name>\r\n"
				+ "<description/>\r\n" + "<defaultValue>SOAPUI/loc_regression.xml</defaultValue>\r\n"
				+ "<trim>false</trim>\r\n" + "</hudson.model.StringParameterDefinition>\r\n"
				+ "</parameterDefinitions>\r\n" + "</hudson.model.ParametersDefinitionProperty>\r\n"
				+ "<hudson.plugins.jira.JiraProjectProperty plugin=\"jira@3.0.9\">\r\n"
				+ "<siteName>https://jirabring.atlassian.net/</siteName>\r\n"
				+ "</hudson.plugins.jira.JiraProjectProperty>\r\n"
				+ "<com.dabsquared.gitlabjenkins.connection.GitLabConnectionProperty plugin=\"gitlab-plugin@1.5.13\">\r\n"
				+ "<gitLabConnection>Gitlab</gitLabConnection>\r\n"
				+ "</com.dabsquared.gitlabjenkins.connection.GitLabConnectionProperty>\r\n" + "</properties>\r\n"
				+ "<definition class=\"org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition\" plugin=\"workflow-cps@2.68\">\r\n"
				+ "<script></script>\r\n" + "<sandbox>true</sandbox>\r\n" + "</definition>\r\n" + "<triggers/>\r\n"
				+ "<disabled>false</disabled>\r\n" + "</flow-definition>";
		IPipelineDTO pipelineDTO = null;
		Document doc = FileParsingUtilNew.convertStringToDocument(jobConfig.toString());

		NodeList nodeList = doc.getElementsByTagName("hudson.model.StringParameterDefinition");

		configXml.getUpdatedXmlString(pipelineDTO, doc);
	}

	@Test
	public void testConvertDocumentToString() {
		configXml.convertDocumentToString(null);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateMapper() throws XPathExpressionException {
		JobDTO jobDTO = new JobDTO();
		Document doc = null;
		GroupHierarchyEntity proj = new GroupHierarchyEntity();
		JobInformationEntity jobInformationEntity = new JobInformationEntity();
		configXml.updateMapper(jobDTO, doc);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateJobInformation() {

		JobDTO jobDTO = new JobDTO();

		configXml.updateJobInformation(jobDTO);
	}

}
