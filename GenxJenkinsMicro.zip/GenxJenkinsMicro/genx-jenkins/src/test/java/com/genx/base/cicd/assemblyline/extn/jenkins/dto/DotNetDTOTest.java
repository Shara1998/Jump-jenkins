package com.genx.base.cicd.assemblyline.extn.jenkins.dto;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DotNetDTOTest {
	@InjectMocks
	DotNetDTO dotNetDTO;
	
	@Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void getDeploymentTypeTest() {
		dotNetDTO.getDeploymentType();
	}
	@Test
	public void setDeploymentTypeTest() {
		dotNetDTO.setDeploymentType("setDeploymentType");
	}
	@Test
	public void getServerNameTest() {
		dotNetDTO.getServerName();
	}
	@Test
	public void setServerNameTest() {
		dotNetDTO.setServerName("setServerName");
	}
	@Test
	public void getPortTest() {
		dotNetDTO.getPort();
	}
	@Test
	public void setPortTest() {
		dotNetDTO.setPort("setSolutionFileName");
	}
	@Test
	public void getSolutionFileNameTest() {
		dotNetDTO.getSolutionFileName();
	}
	@Test
	public void setSolutionFileNameTest() {
		dotNetDTO.setSolutionFileName("setSolutionFileName");
	}
	@Test
	public void getHostNameTest() {
		dotNetDTO.getHostName();
	}
	@Test
	public void setHostNameTest() {
		dotNetDTO.setHostName("setHostName");
	}
	@Test
	public void getUserNameTest() {
		dotNetDTO.getUserName();
	}
	@Test
	public void setUserNameTest() {
		dotNetDTO.setUserName("setUserName");
	}
	@Test
	public void getPasswordTest() {
		dotNetDTO.getPass();
	}
	@Test
	public void setPasswordTest() {
		dotNetDTO.setPass("setPassword");
	}
	@Test
	public void getDeployableTest() {
		dotNetDTO.getDeployable();
	}
	@Test
	public void setDeployableTest() {
		dotNetDTO.setDeployable("setDeployable");
	}


}
